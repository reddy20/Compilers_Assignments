# include <stdio.h>
# include "myl.h"
int main(){
  printf("Enter a stream of characters\n");
  char str[100];
  char ch;
  int i = 0;
  while((ch=getchar())!='\n'){
    str[i++] = ch;
  }
  str[i] = '\0';
  printf("The stream you entered is : \n");
  int n_c = prints(str);                                      // stores no of characters
  printf("\nThe no of characters is : %d\n",n_c);             // prints no of characters
  printf("\nEnter the number \n");
  int n;
  int t;
  n = readi(&t);                                            // reads the integer value if it is integer it gives ok else return error

  if(t)
     printf("Invalid Input\n");
  else{
      printf("The number you entered : \n");
      n_c = printi(n);
      printf("\nThe number of characters : %d\n",n_c);          // it prints the characters in the number you entered
  }
  printf("\nEnter a floating point number\n");
  float num;
  t=readf(&num);
  if(t)
     printf("Invalid Input\n");
  else{
      printf("\nThe number you entered : \n");
      n_c = printd(num);
      printf("\nThe number of characters : \n");
      printf("%d\n",n_c);
  }

  return 0;
}
