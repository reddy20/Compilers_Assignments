#include "myl.h"
#include <stdio.h>

int prints(char *s)
{
     int l = 0;// intially the length of the string is 0
     while(*(s+l) ){             // here it checks whether the string is null or not 
        
          l++;
      
}
     __asm__ __volatile__ (
          "movl $1, %%eax \n\t"
          "movq $1, %%rdi \n\t"
          "syscall \n\t"
          :
          :"S"(s), "d"(l)
          ); 
  return  l;                                         // returns the length of the string 

}

int printi(int n)
{
   char buff[100];
   int i = 0; 
   int j,k;
if(n==0){

         buff[i] = '-';
              i++;

}
  if(n<0){                                            // making if n to positive when n is negative
          buff[i] = '-';
           n = -n;
           i++;
}
   while(n){
             int dig = n%10;
              buff[i] = (char)( dig + '0');              // digits are stored from right to left 
                i++;
              n = n/10 ;
             }
 
    if(buff[0] == '-'){ 
                            j=1;
              }
           else{
                j = 0;
          }
            k = i-1;
         while(j<k){
                         char p = buff[j];             // digits stored are reversed i.e left to right 
                         buff[j] = buff[k];
                         buff[k] = p;
                          j++;
                          k--;
                    }

       __asm__ __volatile__ (
          "movl $1, %%eax \n\t"
          "movq $1, %%rdi \n\t"
          "syscall \n\t"
          :
          :"S"(buff), "d"(i)
          );
  return i;
}


int readi(int *ep){
  char buff[100];
  int i,size,k, result=0;
  __asm__ __volatile__(
          "movl $0, %%eax \n\t"
          "movq $1, %%rdi \n\t"
          "syscall \n\t"
          :"=rax"(size)
          :"S"(buff),"d"(100)
          );

  size--;
  if (size <=0){                // if size of number is 0 or negative error occurs
    *ep = 1;
    return 0;
  }
  if (buff[0]=='-'){                      // Checking whether the number is negtive or not
    i=1;
  }
  else{
    i=0;
  }
  k=size;
  while(i<k){
    if (buff[i]>='0' && buff[i]<='9'){
      result = result*10 + (buff[i]-'0');     //Calculating the result
      i++;
    }
    else{
      *ep = 1;        //ERR
      return 0;
    }
  }
  if (buff[0]=='-'){
    result = -result;
  }
  *ep = 0;          //OK
  return result;
}



int readf(float *fp)
{

   char buff[100];
   int i,j,size,k,d =0;
   float res = 0.0;
  __asm__ __volatile__(
          "movl $0, %%eax \n\t"
          "movq $1, %%rdi \n\t"
          "syscall \n\t"
          :"=rax"(size)
          :"S"(buff),"d"(100)
          );
 size--;
  
    if(size<=0)
{
   (*fp) = 0;
   return 1;
}
if (buff[0]=='-'){              // Checking whether the number is negative
    i=1;
  }
  else{
    i=0;
  }
  k=size;
  while(i<k){
    if (buff[i]=='.'){                              // Checking whther decimal point is encountered or not
      d=1;
      i++;
      j=10;
      continue;
    }
    if (d==0 && buff[i]>='0' && buff[i]<='9'){
      res = res*10 + (buff[i]-'0');   
      i++;
    }
    else{
      if (d==1 && buff[i]>='0' && buff[i]<='9'){
        res += (1.0*(buff[i] - '0'))/(j);              // Calculating the decimal value of each decimal place
        j = j*10;
        i++;
      }
      else{
        *fp = 0;
        return 1;      
      }
    }
  }
  if (buff[0]=='-'){
    res = res*(-1);
  }
  *fp = res;
  return 0;          
}


int printd(float f)
{
    char s[100];
    int i = 0,first = 0;              
    if(f == 0.0)
    {
        s[i++] = '0';                 
    }
    else if(f<0)
    {
        s[i++] = '-';                                     
        f = (-1)*f;
        first = 1;
    }
    int int_part = (int)f;                          //integer part of  the float f
    float float_part = f - int_part;
    while(int_part)
    {
        s[i++] = (char)((int_part%10)+'0');                // getting the interger digits from right to left 
        int_part/=10;
    }
    int last = i-1;
    while(first<last)
    {
        int temp = s[first];
        s[first++] = s[last];
        s[last--] = temp;                                 // reversing the digits to normal one 
    }
    s[i++] = '.';
    first = i;
    if(float_part == 0.0)
    {
        s[i++] = '0';
    }
    else
    {
        int n = 0;  // precision value 
        int r = 0;
        while(n<4)
        {
            r = (int)(float_part*10);
            s[i++] = (char)(r + '0');                  // getting decimal digits in order 
            float_part*=10;
            float_part = float_part - r;
            n++;
        }
    }
  __asm__ __volatile__ (
          "movl $1, %%eax \n\t"
          "movq $1, %%rdi \n\t"
          "syscall \n\t"
          :
          :"S"(s), "d"(i)
          );
  return i;


}

