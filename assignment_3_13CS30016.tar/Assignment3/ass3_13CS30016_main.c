#include "y.tab.h"
#include <stdio.h>
extern int yylex();
extern char* yytext;


  int main()
{

   int t = 1;
  while(t)
  {
      t = yylex();
      switch(t)
       {
         case KEYWORD: printf("< KEYWORD , %d,%s >\n" , t ,yytext); break;
         case IDENTIFIER:printf("< IDENTIFIER , %d,%s >\n" , t ,yytext); break;
         case PUNCTUATOR:printf("< PUNCTUATOR , %d,%s >\n" , t ,yytext); break;
         case STRING_LITERAL:printf("< STRING_LITERAL , %d,%s >\n" , t ,yytext); break;
         case CONSTANT:printf("< CONSTANT , %d,%s >\n" , t ,yytext); break;
       }
  }
   return 0;
}
