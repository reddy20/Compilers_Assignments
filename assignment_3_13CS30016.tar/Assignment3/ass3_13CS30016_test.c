'lkvsvfsmv
dslmvsdmvmsv
sdlvsdmvsdmv
sdlvlsdmvdmvsdmvdsmmmwrovwopfmamgqmg'
(){}[].' ':;\|++==

"%d",

#include <iostream>
#include <stdio.h>


struct node{
    float x;
    float y;
};

enum Day{
    Monday,
    Tuesday,
    Wednesday
}

int main(){
    /***********/
        This program is written to test the lexcial analyser created by 
        /** Author: Kannapu Rajasekhar Reddy
        Date: 14/8/15
    *******Helofdmpd dmfpmdf *******/

   int x, y;
    double z;
    scanf("%d",&x);
    scanf("%d",&y);
    z = (x*y)+((++x)&(--y))+(x!=y)+(x>>2); // Don't know what it does
    struct node * p;
    p = (struct node*)malloc(sizeof(struct node)*1);
    p->x = 4.56;
    p->y = 0.00;
    int a[45];
    a[Monday] = 2e-12.4555;
    return 0;
}

"Hello My name is K Rajasekhar Reddy"
