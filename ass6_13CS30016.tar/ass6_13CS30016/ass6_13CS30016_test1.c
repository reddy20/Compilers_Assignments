/*
	Name : ass6_13CS30016_test1.c
	Author : Rajasekhar Reddy
	Roll No. : 13CS30016
	Description : Test File for testing the made TinyC Compiler
*/

// Code for triangular pattern generation with numbers

/*
	- 	All 3 types of loops
	- 	Expression Handling
	- 	Array Handling
*/

int main()
{
	int a[10], n, i, j;

	prints("===================================================================\n");
	prints("Generating a triangular pattern with numbers :\n\n");

	i = 0;
	do
	{
		a[i] = i;
		++i;
	}
	while (i < 10);

	i = 0;
	while(i < 10)
	{
		for(j = 0 ; j <= i ; j++)
			printi(j);
		++i;
		prints("\n");
	}

	prints("===================================================================\n");
	
	return 0;

}
