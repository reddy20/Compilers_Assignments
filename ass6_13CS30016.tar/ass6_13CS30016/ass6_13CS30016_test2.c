/*
	Name : ass6_13CS30016_test2.c
	Author : Rajasekhar Reddy
	Roll No. : 13CS30016
	Description : Test File for testing the made TinyC Compiler
*/

// Factorial Computation by recursive function

/*
	-	Handling of recursive functions with parameters
	-	Control constructs
	- 	Expressions Handling
	-	Basic I/O
*/

int fact(int num)
{
	int prod;
	
	if(num == 0)
	{
		prod = 1;
	}
	else
	{
		prod = fact(num - 1) * num;
	}

	return prod;
}

int main()
{
	int n, *err, factn;

	prints("\nEnter a positive number (not very big) to compute its factorial :\n");

	n = readi(err);

	factn = fact(n);

	prints("The factorial of ");
	printi(n);
	prints(" is : ");
	printi(factn);
	prints("\n");

	return 0;
}
