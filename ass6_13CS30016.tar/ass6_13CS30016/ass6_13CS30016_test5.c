/*
        Name : ass6_13CS30016_test1.c
	Author : Rajasekhar Reddy
	Roll No. : 13CS30016
	Description : Test File for testing the made TinyC Compiler
*/


/*
	-	Handling global variables
	- 	Expressions Handling
	- 	Handling characters
	-	Handling control statements and Looping
	-	Basic I/O
*/

int g1 = 55, g2;

char g3, g4 = 'a';

int main()
{
	int turns = 5, guess, dif, status, *err;

	prints("\nLets play a small game :\n");
	prints("\nThere is a global integer variable declared in the code. Enter a number and guess that global variable 'g1' :\n");

	while(turns > 0)
	{
		prints("\nYou have ");
		printi(turns);
		prints(" turns left :\n");
		prints("\nEnter guess : ");
		guess = readi(err);

		dif = g1 - guess;
		if(dif < 0)
			dif = dif * (-1);

		status = 0;

		if(dif > 1000)
		{
			prints("\nYou are far away from the global. Change your thinking strategy!\n");
		}
		else if(dif > 100)
		{
			prints("\nYou are going in the right direction. Keep Going!\n");
		}
		else if(dif > 10)
		{
			prints("\nWow! you are close!\n");
		}
		else if(dif > 0)
		{
			prints("\nOmg! You are too close to guessing the global right!!!\n");
		}
		else
		{
			prints("\nHurray!!! You guessed it! Keep it up!\n\n");
			status = 1;
			turns = 0;
		}

		turns--;
	}

	if(status == 0)
	{
		prints("\nSorry, turns over...you missed out this time! Better luck next time!\n\n");
	}

	return 0;
}
