#include "ass6_13CS30016_translator.h"
#include <bits/stdc++.h>
#include "y.tab.h"
using namespace std;

ofstream asmcode;
map < int, string > labelmap;

string makeStrConstants()
{
	map < string, string > :: iterator it;
	string str = "\t.section\t.rodata\n";
	for(it = strmap.begin() ; it != strmap.end() ; it++)
	{
		str += it->second + ":\n\t.string " + it->first + "\n";
	}
	return str;
}

void makeLabels()
{
	int cnt = 0;
	for(int i = 0 ; i < qa.array.size() ; i++)
	{
		if((qa.array[i].op >= OPER_GOTO) && (qa.array[i].op <= OPER_IF_NOT_EXPRESSION))
		{
			stringstream ss;
			int lindex;
			ss << qa.array[i].result;
			ss >> lindex;
			if(labelmap.find(lindex) == labelmap.end())
			{
				stringstream lss;
				string ls;
				lss << ".L" << cnt;
				lss >> ls;
				++cnt;
				labelmap[lindex] = ls;
			}
		}
	}
	map < int, string > :: iterator it;
}

string findReg(int paramnum, primtype code, bool iscall)
{
	string s;
	switch(paramnum)
	{
		case 1: if(code == INT || (code != PTR && iscall)) s = "%edi"; else if(code == PTR || code == ARRAY) s = "%rdi"; else s = "dil"; return s; break;
		case 2: if(code == INT || (code != PTR && iscall)) s = "%esi"; else if(code == PTR || code == ARRAY) s = "%rsi"; else s = "sil"; return s; break;
		case 3:	if(code == INT || (code != PTR && iscall)) s = "%edx"; else if(code == PTR || code == ARRAY) s = "%rdi"; else s = "dl"; return s; break;
		case 4:	if(code == INT || (code != PTR && iscall)) s = "%ecx"; else if(code == PTR || code == ARRAY) s = "%rcx"; else s = "al"; return s; break;
		case 5:	if(code == INT || (code != PTR && iscall)) s = "%r8d"; else if(code == PTR || code == ARRAY) s = "%r8"; else s = "r8b"; return s; break;
		case 6:	if(code == INT || (code != PTR && iscall)) s = "%r9d"; else if(code == PTR || code == ARRAY) s = "%r9"; else s = "r9b"; return s; break;
	}
	int sz = paramnum * 8;
	stringstream ss;
	string szs;

	if(!iscall)
	{
		// sz = 8 + sz;
	}

	ss << sz;
	ss >> szs;
	
	s = szs + "(%rbp)";
	return s;
}


string getCmd(string cmdd, primtype pt, int argcode)
{
	string s = cmdd;
	switch(pt)
	{
		case INT : 
			s += "l"; 
			break;

		case CHAR :
			if(argcode == 1) 
				s += "zbl"; 
			else if(argcode == 0)
				s += "b";
			else if(argcode == 2)
				s += "l";
			else if(argcode == 3)
				s += "sbl";
			break;
		
		case PTR : 
			s += "q"; 
			break;
		case ARRAY :
			s += "q"; 
	}
	return s;
}


string makePrologue(string fname, symtab *fsym, int space)
{
	int k = space / 16;			
	space = (k+1) * 16;
	
	stringstream ss;
	string s, s1, s2;
	
	ss << space;
	ss >> s;

	string str = "";
	str += "\t.text\n";
	str += "\t.globl\t" + fname + "\n";
	str += "\t.type\t" + fname+ ", @function\n";
	str += fname + ":\n";
	str += "\tpushq\t%rbp\n";
	str += "\tmovq\t%rsp, %rbp\n";
	str += "\taddq\t$-" + s + ", %rsp\n";

	for(int i = 0 ; i < fsym->ord_sym.size() ; i++)
	{
		if(fsym->ord_sym[i]->name == "retVal")
			break;
		s1 = findReg(i+1, fsym->ord_sym[i]->type.p_type, false);
		ss.str(""); ss.clear();
		ss << fsym->ord_sym[i]->offset << "(%rbp)";
		ss >> s2;
		str += "\t" + getCmd("mov", fsym->ord_sym[i]->type.p_type, 0) + "\t" + s1 + ", " + s2 + "\n";
	}

	return str;
}

string makeEpilogue(string fname)
{
	string str = "";
	// if(fname != "main")
	// 	str += "\tpopq\t%rbp\n";
	str += "\tleave\n";
	str += "\tret\n";
	str += "\t.size\t" + fname + ", .-" + fname + "\n";
	return str;
}

string makeGlobals()
{
	string str = "";
	for(int i = 0 ; i < gst.ord_sym.size() ; i++)
	{
		if(gst.ord_sym[i]->name[0] == 't')
		{
			// NOTE : any user defined variable must not start with a 't' followed by a numberal (else it will be treated as a temporary)
			if(gst.ord_sym[i]->name[1] >= '0' && gst.ord_sym[i]->name[1] <= '9')
				continue;
		}
		if(gst.ord_sym[i]->init_val != NULL)
		{
			if(gst.ord_sym[i]->type.p_type == INT)
			{
				stringstream ss;
				string s;
				ss << gst.ord_sym[i]->init_val->intval;
				ss >> s;

				str += "\t.globl\t" + gst.ord_sym[i]->name + "\n";
	        	str += "\t.data\n";
	        	str += "\t.align 4\n";
	        	str += "\t.type\t" + gst.ord_sym[i]->name + ", @object\n";
	        	str += "\t.size\t" + gst.ord_sym[i]->name + ", 4\n";
	        	str += gst.ord_sym[i]->name + ":\n";
	        	str += "\t.long\t" + s + "\n";	
			}
			else if(gst.ord_sym[i]->type.p_type == CHAR)
			{
				int ascii = gst.ord_sym[i]->init_val->charval;
				stringstream ss;
				string s;
				ss << ascii;
				ss >> s;

				str += "\t.globl\t" + gst.ord_sym[i]->name + "\n";
	        	str += "\t.type\t" + gst.ord_sym[i]->name + ", @object\n";
	        	str += "\t.size\t" + gst.ord_sym[i]->name + ", 1\n";
	        	str += gst.ord_sym[i]->name + ":\n";
	        	str += "\t.byte\t" + s + "\n";	
			}
			// NOTE : in the tinyC compiler created : global pointers are not given initial values. Their initial values are given to them through generated temporaries and is handled in the main code.
		}
		else
		{
			if(gst.ord_sym[i]->type.p_type == INT)
				str += "\t.comm\t" + gst.ord_sym[i]->name + ",4,4\n";
			else if(gst.ord_sym[i]->type.p_type == CHAR)
				str += "\t.comm\t" + gst.ord_sym[i]->name + ",1,1\n";
			else if(gst.ord_sym[i]->type.p_type == PTR) 
				str += "\t.comm\t" + gst.ord_sym[i]->name + ",8,8\n";
		}
	}
	return str;
}

int generate_offset(symtab *cst)
{
	bool isparam = true;
	int stacksize = 0;
	int paramnum = 0;
	int sz;
	for(int i = 0 ; i < cst->ord_sym.size() ; i++)
	{
		if(cst->ord_sym[i]->name == "retVal")
		{
			cst->ord_sym[i]->offset = 0;
			isparam = false;
			continue;
		}
		if(isparam)
		{
			paramnum++;
			switch(cst->ord_sym[i]->type.p_type)
			{
				case INT : sz = 4; break;
				case CHAR : sz = 4; break;
				case PTR : sz = 8; break;
				case ARRAY : sz = 8; break;
			}
			cst->ord_sym[i]->offset = -sz * paramnum;
			cst->ord_sym[i]->size = sz;
			stacksize = sz * paramnum;
		}
		else
		{
			primtype pt = cst->ord_sym[i]->type.p_type;
			if(pt == ARRAY)
				pt = cst->ord_sym[i]->type.base_t;
			switch(pt)
			{
				case INT : sz = 4; break;
				case CHAR : sz = 1; break;
				case PTR : sz = 8; break;
				case ARRAY : sz = 8; break;
			}
			if(cst->ord_sym[i]->type.p_type == ARRAY)		// note base ptr of array has smallest offset
			{
				int szp = 1;
				for(int j = 0 ; j < cst->ord_sym[i]->type.alist.size() ; j++)
				{
					szp *= cst->ord_sym[i]->type.alist[j];
				}
				sz = sz * szp;
			}
			stacksize += sz;
			cst->ord_sym[i]->offset = -stacksize;
			cst->ord_sym[i]->size = sz;
		}
	}
	return stacksize;
}

symtab_entry* getEntry(symtab *st, string s)
{
	if(s[0] >= '0' && s[0] <= '9')
		return NULL;
	if(st->_symtab.count(s))
		return st->_symtab[s];
	else
	{
		if(gst._symtab.count(s))
			return gst._symtab[s];
		else
			return NULL;
	}
}

string formTerm(symtab_entry *se, string s)
{
	string str;
	stringstream ss;

	if(se == NULL)
	{
		if(s[0] == '\"')
		{
			str = "$" + strmap[s];	
		}
		else if(s[0] >= '0' && s[0] <= '9')
			str = "$" + s;
		else if(s.length() == 1)
		{
			char ch = s[0];
			ss.str(); ss.clear();
			ss << "$";
			ss << (int)ch;
			ss >> str;	
		}
		return str;		
	}

	ss.str(""); ss.clear();
	if(gst._symtab.count(se->name))
		ss << se->name;
	else
		ss << se->offset << "(%rbp)";
	ss >> str;

	return str;
}

primtype getType(symtab_entry *se)
{
	if(se != NULL)
	{
		if(se->type.p_type == ARRAY)
			return se->type.base_t;
		else
			return se->type.p_type;
	}
	else
		return none;
}

bool isintconst(string s)
{
	if(s[0] >= '0' && s[0] <= '9')
		return true;
	return false;
}

string getReg(string regstr, primtype pt, int interrupt = 0)
{
	switch(pt)
	{
		case INT : 
			regstr[1] = 'e'; 
			break;
		case CHAR : 
			regstr[1] = 'e'; 
			if(interrupt == 1)
				return "%al";
			if(interrupt == 2)
				return "%dl";
			break;
		case PTR : 
			regstr[1] = 'r'; 
			break;
		case ARRAY : 
			regstr[1] = 'r';
			break;
	}
	return regstr;
}

void makeQaudCodes(string filename)
{
	asmcode << "\t.file\t\"" << filename << "\"\n";
	makeLabels();
	asmcode << makeGlobals();
	asmcode << makeStrConstants();
	
	string qstr;
	quad q;
	symtab_entry *se1, *se2, *res;
	string term1, term2, term3, s, currfn;
	stringstream ss;
	primtype pt;
	int ps, psize, k, space;
	vector < string > pstack;
	
	currfn = "";
	st = (&gst);
	
	for(int i = 0 ; i < qa.array.size() ; i++)
	{
		q = qa.array[i];
		if(st == &(gst) && q.op != OPER_FUNCT_BEGIN)
		{
			continue;
		}
		se1 = getEntry(st, q.arg1);
		se2 = getEntry(st, q.arg2);
		res = getEntry(st, q.result);
		
		term1 = formTerm(se1, q.arg1); 			// 1 - code for arg1
		term2 = formTerm(se2, q.arg2);			// 2 - code for arg2
		term3 = formTerm(res, q.result);		// 3 - code for result

		if(q.op >= OPER_GOTO && q.op <= OPER_IF_NOT_EXPRESSION)
			pt = getType(se1);
		else if(q.op == OPER_CALL)
			pt = getType(se2);
		else
			pt = getType(res);
		
		qstr = "";

		if(labelmap.count(i) != 0)
			qstr += labelmap[i] + ":\n";
		
		switch(q.op)
		{
			case OPER_PLUS:
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term2 + ", " + getReg("%edx", pt) + "\n";
				qstr += "\t" + getCmd("add", pt, 2) + "\t" + getReg("%edx", pt) + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("mov", pt, 0) + "\t" + getReg("%eax", pt, 1) + ", " + term3 + "\n";
				break;

			case OPER_MINUS:
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term2 + ", " + getReg("%edx", pt) + "\n";
				qstr += "\t" + getCmd("sub", pt, 2) + "\t" + getReg("%edx", pt) + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("mov", pt, 0) + "\t" + getReg("%eax", pt, 1) + ", " + term3 + "\n";
				break;

			case OPER_MULTIPLY:
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term2 + ", " + getReg("%edx", pt) + "\n";
				qstr += "\t" + getCmd("imul", pt, 2) + "\t" + getReg("%edx", pt) + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("mov", pt, 0) + "\t" + getReg("%eax", pt, 1) + ", " + term3 + "\n";
				break;

			case OPER_DIVIDE:
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\tcltd\n";
				qstr += "\t" + getCmd("idiv", pt, 2) + "\t" + term2 + "\n";
				qstr += "\t" + getCmd("mov", pt, 0) + "\t" + getReg("%eax", pt, 1) + ", " + term3 + "\n";
				break;

			case OPER_MODULUS:
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\tcltd\n";
				qstr += "\t" + getCmd("idiv", pt, 2) + "\t" + term2 + "\n";
				qstr += "\t" + getCmd("mov", pt, 0) + "\t" + getReg("%edx", pt, 1) + ", " + term3 + "\n";
				break;

			case OPER_UMINUS:
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("neg", pt, 2) + "\t" + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("mov", pt, 0) + "\t" + "" + getReg("%eax", pt, 1) + ", " + term3 + "\n";
				break;				

			case OPER_GOTO:
				ss.str(""); ss.clear();
				ss << term3.substr(1);
				ss >> k;
				qstr += "\tjmp\t" + labelmap[k] + "\n";
				break;

			case OPER_IF_EXPRESSION:
				ss.str(""); ss.clear();
				ss << term3.substr(1);
				ss >> k;
				qstr += "\t" + getCmd("cmp", pt, 0) + "\t$0, " + term1 + "\n";
				qstr += "\tjne\t" + labelmap[k] + "\n";
				break;

			case OPER_IF_NOT_EXPRESSION:
				ss.str(""); ss.clear();
				ss << term3.substr(1);
				ss >> k;
				qstr += "\t" + getCmd("cmp", pt, 0) + "\t$0, " + term1 + "\n";
				qstr += "\tje\t" + labelmap[k] + "\n";
				break;

			case OPER_IF_LESS:				
				ss.str(""); ss.clear();
				ss << term3.substr(1);
				ss >> k;
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("cmp", pt, 0) + "\t" + term2 + ", " + getReg("%eax", pt, 1) + "\n";
				qstr += "\tjl\t" + labelmap[k] + "\n";
				break;

			case OPER_IF_LESS_OR_EQUAL:
				ss.str(""); ss.clear();
				ss << term3.substr(1);
				ss >> k;
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("cmp", pt, 0) + "\t" + term2 + ", " + getReg("%eax", pt, 1) + "\n";
				qstr += "\tjle\t" + labelmap[k] + "\n";
				break;

			case OPER_IF_GREATER:
				ss.str(""); ss.clear();
				ss << term3.substr(1);
				ss >> k;
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("cmp", pt, 0) + "\t" + term2 + ", " + getReg("%eax", pt, 1) + "\n";
				qstr += "\tjg\t" + labelmap[k] + "\n";
				break;

			case OPER_IF_GREATER_OR_EQUAL:
				ss.str(""); ss.clear();
				ss << term3.substr(1);
				ss >> k;
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("cmp", pt, 0) + "\t" + term2 + ", " + getReg("%eax", pt, 1) + "\n";
				qstr += "\tjge\t" + labelmap[k] + "\n";
				break;

			case OPER_IF_EQUAL:
				ss.str(""); ss.clear();
				ss << term3.substr(1);
				ss >> k;
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("cmp", pt, 0) + "\t" + term2 + ", " + getReg("%eax", pt, 1) + "\n";
				qstr += "\tje\t" + labelmap[k] + "\n";
				break;

			case OPER_IF_NOT_EQUAL:
				ss.str(""); ss.clear();
				ss << term3.substr(1);
				ss >> k;
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\t" + getCmd("cmp", pt, 0) + "\t" + term2 + ", " + getReg("%eax", pt, 1) + "\n";
				qstr += "\tjne\t" + labelmap[k] + "\n";
				break;

			case OPER_ASSIGN:
				if(isintconst(q.arg1))
					qstr += "\t" + getCmd("mov", pt, 0) + "\t" + term1 + ", " + term3 + "\n";
				else
				{
					qstr += "\t" + getCmd("mov", pt, 2) + "\t" + term1 + ", " + getReg("%eax", pt) + "\n";
					qstr += "\t" + getCmd("mov", pt, 0)  + "\t" + getReg("%eax", pt, 1) + ", " + term3 + "\n";
				}
				break;

			case OPER_ARRAY_INDEX_FROM:
				ss.clear(); ss.str("");
				ss << se1->offset;
				ss >> s;
				qstr += "\t" + getCmd("mov", INT, 0) + "\t" + term2 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\tcltq\n";
				qstr += "\t" + getCmd("mov", pt, 0) + "\t" + s + "(%rbp, %rax), " + getReg("%ebx", pt, 2) + "\n";
				qstr += "\t" + getCmd("mov", pt, 0) + "\t" + getReg("%ebx", pt, 2) + ", " + term3 + "\n";
				break;

			case OPER_ARRAY_INDEX_TO:
				ss.clear(); ss.str("");
				ss << res->offset;
				ss >> s;
				qstr += "\t" + getCmd("mov", INT, 0) + "\t" + term2 + ", " + getReg("%eax", pt) + "\n";
				qstr += "\tcltq\n";
				qstr += "\t" + getCmd("mov", pt, 0) + "\t" + term1 + ", " + getReg("%ebx", pt, 2) + "\n";
				qstr += "\t" + getCmd("mov", pt, 0) + "\t" + getReg("%ebx", pt, 2) + ", " + s + "(%rbp, %rax)\n";
				break;

			case OPER_PARAM:

				s = findReg(pstack.size()+1, pt, true);
				qstr += "\t" + getCmd("mov", pt, 2) + "\t" + term3 + ", " + s + "\n";
				pstack.push_back(qstr);
				qstr = "";
				break;

			case OPER_CALL:
				psize = pstack.size();
				for(int j = psize-1 ; j >= 0 ; j--)
				{
					qstr += pstack[j];
				}
				pstack.clear();
				qstr += "\tmovl\t$0, %eax\n";
				qstr += "\tcall " + q.result + "\n";
				if(q.arg2 != "")
				{
					qstr += "\t" + getCmd("mov", pt, 0) + "\t" + getReg("%eax", pt, 1) + ", " + term2 + "\n";
				}
				break;

			case OPER_FUNCT_BEGIN:
				st = gst.lookup(q.arg1)->nested_symtab;
				space = generate_offset(st);
				asmcode << qstr;
				qstr = "";
				asmcode << makePrologue(q.arg1, st, space);
				currfn = term1;
				break;

			case OPER_FUNCT_END:
				st = &(gst);
				asmcode << qstr;
				qstr = "";
				asmcode << makeEpilogue(q.result);
				currfn = "";
				break;

			case OPER_REF:
				qstr += "\tleaq\t" + term1 + ", %rax\n";
				qstr += "\tmovq\t%rax, " + term3 + "\n";
				break;

			case OPER_DE_REF:
				qstr += "\tmovq\t" + term1 + ", %rax\n";				
				qstr += "\t" + getCmd("mov", pt, 1) + "\t0(%rax), " + getReg("%ebx", pt) + "\n";
				qstr += "\t" + getCmd("mov", pt, 0) + "\t" + getReg("%ebx", pt, 1) + ", " + term3 + "\n";
				break;

			case OPER_POINTER_ASSIGNMENT:
				qstr += "\tmovq\t" + term3 + ", %rax\n";
				qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term1 + ", " + getReg("%edx", pt) + "\n";
				qstr += "\t" + getCmd("mov", pt, 0) + "\t" + getReg("%edx", pt, 2) + ", (%rax)\n";
				break;

			case OPER_RETURN:
				if(term3 != "")
				{
					qstr += "\t" + getCmd("mov", pt, 1) + "\t" + term3 + ", " + getReg("%eax", pt) + "\n";
				}
				break;

		}

		asmcode << qstr;
	}

}

void printQuads()
{
	int sz = qa.array.size();
    cout << "\n============== PRINTING QUADS =================\n";
    for(int i = 0; i<sz;i++)
    {
        qa.array[i].print(i);
    }
    cout << "===============================================\n";
}

/*
NOTE : 
------
During the generation of the assembly code, symbol table gets modified with the offsets required for generation of the activation record.
Before that, the symbol table stores the offsets generated as the code is parsed during the parsing phase.

*/
void printSymbolTables(bool asmgen)
{
	if(asmgen)
	{
		cout << "\nGLOBAL SYMBOL TABLE IS ALLOCATED IN STATIC DATA SEGMENT -- NOT ON STACK -- \n";
		cout << "ACTIVATION RECORD IS HENCE NOT GENERATED FOR GLOBAL SYMBOLS\n\n";
	}
	else
	{
		st->printsymtab("global");	
	}
    for(map<string,symtab_entry*> :: iterator it = st->_symtab.begin(); it != st->_symtab.end(); ++it)
    {
        symtab_entry *tmp = it->second;
        if(tmp->nested_symtab != NULL)
        {
            const char *s = tmp->name.c_str();
            tmp->nested_symtab->printsymtab(s);
        }
    }
}

void printParseStatus(bool stat)
{
	cout << "===============================================\n";
	cout << "STATUS : ";
    if(stat)
        cout << "parsing failure\n";
    else
        cout << "parsing successful\n";
    cout << "===============================================\n";
}

string getAsmFilename(string cfile)
{
	int i, j;
	string asmfile = cfile;
	
	// NOTE: For correct parsing : input file must be of the form : ass6_<9-digit-roll-num>_test<num>.c

	for(i = cfile.length() ; i >= 0 ; i--)
	{
		if(cfile[i] == 't')
			break;
	}
	for(j = cfile.length() ; j >= 0 ; j--)
	{
		if(cfile[j] == '.')
			break;
	}
	++i;
	asmfile = cfile.substr(0, 14) + "_" + cfile.substr(i, j-i) + ".s";
	return asmfile;
}

string getQaudSymtabFileName(string cfile)
{
	int i, j;
	string quad_symtab_file = cfile;
	
	// NOTE: For correct parsing : input file must be of the form : ass6_<9-digit-roll-num>_test<num>.c

	for(i = cfile.length() ; i >= 0 ; i--)
	{
		if(cfile[i] == 't')
			break;
	}
	for(j = cfile.length() ; j >= 0 ; j--)
	{
		if(cfile[j] == '.')
			break;
	}
	++i;
	quad_symtab_file = cfile.substr(0, 15) + "quad" + cfile.substr(i, j-i) + ".out";
	return quad_symtab_file;	
}

void generateAssemblyCode(string cfile)
{
	string asmfile = getAsmFilename(cfile);

	cout << "Filename : " << asmfile << endl;
	
	asmcode.open(asmfile.c_str());
	makeQaudCodes(cfile);
	asmcode.close();
}

void prepare()
{
	cout << "\nENTERING PREDEFINED FUNCTIONS (printi, readi, prints)\n";

	symtab_entry *p_se_f_ri = gst.lookup("readi", 0, FUNCTION);
	symtab *p_st_ri = new symtab();
	p_se_f_ri->nested_symtab = p_st_ri;
	symtab_entry *p_se_par1_ri = p_st_ri->lookup("eP", 1, PTR);
	p_se_par1_ri->type.base_t = INT;
	p_se_par1_ri->size = 8;
	p_se_par1_ri->offset = -4;
	symtab_entry *p_se_ret_ri = p_st_ri->lookup("retVal", 0, INT);
	p_se_ret_ri->size = 4;
	p_se_ret_ri->offset = 0;

	symtab_entry *p_se_f_pi = gst.lookup("printi", 0, FUNCTION);
	symtab *p_st_pi = new symtab();
	p_se_f_pi->nested_symtab = p_st_pi;
	symtab_entry *p_se_par1_pi = p_st_pi->lookup("n", 0, INT);
	p_se_par1_pi->size = 4;
	p_se_par1_pi->offset = -4;
	symtab_entry *p_se_ret_pi = p_st_pi->lookup("retVal", 0, INT);
	p_se_ret_pi->size = 4;
	p_se_ret_pi->offset = 0;	
	
	symtab_entry *p_se_f_ps = gst.lookup("prints", 0, FUNCTION);
	symtab *p_st_ps = new symtab();
	p_se_f_ps->nested_symtab = p_st_ps;
	symtab_entry *p_se_par1_ps = p_st_ps->lookup("str", 1, PTR);
	p_se_par1_ps->type.base_t = CHAR;
	p_se_par1_ps->size = 8;
	p_se_par1_ps->offset = -4;
	symtab_entry *p_se_ret_ps = p_st_ps->lookup("retVal", 0, INT);
	p_se_ret_ps->size = 4;
	p_se_ret_ps->offset = 0;
}

// main() function for the final compiler program

int main(int argc, char **argv)
{
	bool asmgen = false;									// becomes true when the assembly code file generation is complete
	bool quad_symtab_output_to_file = false;				// make it true for automatically generating a file ass6_<9-digit-roll-num>_quad<num>.out

	if(argc < 2 || argc > 3)
	{
		cerr << "Please give only 2 or 3 arguments. (./mycc <input_filename> <executablefile>)\n";
		return 0;
	}
	
	freopen(argv[1], "r", stdin);
	if(stdin == 0)
	{
		cerr << "Input File opening unsuccessful\n";
		return 0;
	}

	string cfile = string(argv[1]);
	
	if(quad_symtab_output_to_file)
	{
		string quad_symtab_outfile = getQaudSymtabFileName(argv[1]);
		freopen(quad_symtab_outfile.c_str(), "w", stdout);
	}

	prepare(); 				// makes entries for the predefined library functions (printi, prints, readi)

	cout << "\nCODE PARSING STARTED\n";
    bool stat = yyparse();  

    printQuads();
    printSymbolTables(asmgen);
    printParseStatus(stat);

    cout << "\nGENERATING ASSEMBLY CODE...\n";

    generateAssemblyCode(cfile);
    asmgen = true;
    string asmfile = getAsmFilename(cfile);

    cout << "\nPRINTING SYMBOL TABLES AFTER OFFSET CALCULATION FOR ACTIVATION RECORDS\n";
    printSymbolTables(asmgen);

    cout << "\nDONE\n";

    string executablefile = "a.out";

    if(argc == 3)
    	executablefile = string(argv[2]);

    string cmd = "gcc " + asmfile + " -L. -lmyl -o " + executablefile;
    
    system(cmd.c_str());

    //-- CHECKER--
    // string check = "gcc -S " + cfile + " -L. -lmyl";
    // string checkrun = "gcc " + cfile + " -L. -lmyl";
    
    // system(check.c_str());
    // system(checkrun.c_str());

    // cout << "\n===============================================\n";
    // cout << "\nRUNNING YOUR COMPILED CODE :\n";

    // string cmdex = "./" + executablefile;
    // system(cmdex.c_str());

    // cout << "\n===============================================\n";
    // cout << "\nRUNNING GCC COMPILE :\n";

    // string checkex = "./a.out";
    // system(checkex.c_str());

    // cout << "\n===============================================\n";

    cout << "\nCOMPLETE\n";

    return 0;
}
