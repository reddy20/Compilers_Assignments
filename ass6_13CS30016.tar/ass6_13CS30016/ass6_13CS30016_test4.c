/*
	Name : ass6_13CS30016_test4.c
	Author : Rajasekhar Reddy
	Roll No. : 13CS30016
	Description : Test File for testing the made TinyC Compiler
*/


/*
	-	Handling of various types of control statements
	- 	Expressions Handling
	- 	Handling characters
	-	Handling calling of functions within functions
	-	Basic I/O
*/

int gcd(int m, int n)
{
	int temp, rem;
	
	if(m < n)
	{
		temp = m;
		m = n;
		n = temp;
	}

	while(n != 0)
	{
		temp = m % n;
		m = n;
		n = temp;
	}
	
	return m;
}

char getstatus(int x, int y)
{
	int n;
	char ans = 'y';

	n = gcd(x, y);

	if(n == 1)
		ans = 'n';

	return ans;
}

int main()
{
	int a, b, *err, k;
	char status;

	prints("\nEnter 2 numbers (a & b) : ");
	a = readi(err);
	b = readi(err);

	prints("\nHandling some operations with these two numbers :\n\n");

	if(a < 10 && b < 10)
	{
		prints("Both ");
		printi(a);
		prints(" and ");
		printi(b);
		prints(" are < 10\n");
	}
	else if(a < 10)
	{
		prints("Only ");
		printi(a);
		prints(" is < 10\n");
	}
	else if(b < 10)
	{
		prints("Only ");
		printi(b);
		prints(" is < 10\n");	
	}
	else
	{
		prints("None of ");
		printi(a);
		prints(" and ");
		printi(b);
		prints(" are < 10\n");
	}

	prints("\n");

	prints("Finding the maximum of the 2 numbers entered :\n");

	prints("\nMax. is : ");
	printi((a > b) ? a : b);

	prints("\n\n");

	prints("Finding if the no.s are co-prime (status = 'y' represents YES and status = 'n' represents NO) :\n");
	
	prints("status = ");

	status = (getstatus(a, b) == 1) ? 'y' : 'n';

	prints((status == 'y') ? "y" : "n");

	prints("\n\n");

	return 0;
}
