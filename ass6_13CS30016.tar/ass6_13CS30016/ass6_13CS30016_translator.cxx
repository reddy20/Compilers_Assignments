#include "ass6_13CS30016_translator.h"
#include "y.tab.h"

// The details of the various functions implemented in this file are provided in 'ass5_13CS30016_translator.h'

void quad::print(int quad_no)
{
    cout << quad_no << " : ";
    if(OPER_PLUS<=op && op<=OPER_NOT_EQUAL)
    {
        cout<<result<<" = "<<arg1<<" ";
        switch(op)
        {
            case OPER_PLUS: cout<<"+"; break;
            case OPER_NOT_EQUAL: cout<<"!="; break;
            case OPER_LESS_EQUAL: cout<<"<="; break;
            case OPER_BW_XOR: cout<<"^"; break;
            case OPER_BW_AND: cout<<"&"; break;
            case OPER_BW_OR: cout<<"|"; break;
            case OPER_LOGIC_AND: cout<<"&&"; break;
            case OPER_LOGIC_OR: cout<<"||"; break;
            case OPER_LESS: cout<<"<"; break;
            case OPER_GREATER: cout<<">"; break;
            case OPER_EQUAL: cout<<"=="; break;
            case OPER_MINUS: cout<<"-"; break;
            case OPER_MULTIPLY: cout<<"*"; break;
            case OPER_DIVIDE: cout<<"/"; break;
            case OPER_MODULUS: cout<<"%"; break;
            case OPER_SHIFT_LEFT: cout<<"<<"; break;
            case OPER_SHIFT_RIGHT: cout<<">>"; break;
            case OPER_GREATER_EQUAL: cout<<">="; break;
        }
        cout<<" "<<arg2<<endl;
    }
    else if(OPER_UMINUS<=op && op<=OPER_BW_NOT)
    {
        cout<<result<<" = ";
        switch(op)
        {
            case OPER_UMINUS : cout<<"-"; break;
            case OPER_COMPLEMENT : cout<<"~"; break;
            case OPER_UPLUS : cout<<"+"; break;
            case OPER_BW_NOT : cout<<"!"; break;
        }
        cout<<arg1<<endl;
    }
    else if(OPER_IF_LESS<=op && op<=OPER_IF_NOT_EXPRESSION)
    {
        cout<<"if "<<arg1<<" ";
        switch(op)
        {
            //Conditional Jump
            case   OPER_IF_EXPRESSION : cout<<"!= 0"; break;
            case   OPER_IF_NOT_EXPRESSION : cout<<"== 0"; break;
            case   OPER_IF_EQUAL : cout<<"=="; break;
            case   OPER_IF_NOT_EQUAL : cout<<"!="; break;
            case   OPER_IF_LESS : cout<<"<"; break;
            case   OPER_IF_GREATER : cout<<">"; break;
            case   OPER_IF_LESS_OR_EQUAL : cout<<"<="; break;
            case   OPER_IF_GREATER_OR_EQUAL : cout<<">="; break;
        }
        cout<<" "<<arg2<<" goto "<<result<<endl;            
    }
    else if (op == OPER_ASSIGN)
    {
         cout<<result<<" = "<<arg1<<endl;  
    }    
    else if(op == OPER_GOTO)
    {
        cout<<"goto "<<result<<endl;
    }
    else if(op == OPER_CALL)
    {
    	if(arg2 != "")
    		cout << arg2 << " = ";
        cout<<"call "<<result<<", "<<arg1<<endl;
    }
    else if(op == OPER_RETURN)
    {
        cout<<"return "<<result<<endl;
    }
    else if(op == OPER_FUNCT_BEGIN)
    {
        cout << arg1 << ":"<< endl;
    }
    else if(op == OPER_FUNCT_END)
    {
        cout << "end"<< endl;  
    }
    else if( op == OPER_ARRAY_INDEX_FROM)
    {
        cout<<result<<" = "<<arg1<<"["<<arg2<<"]"<<endl;
    }
    else if(OPER_C2I<=op && op<=OPER_D2I)
    {
        cout<<result<<" = ";
        switch(op)
        {
            case OPER_D2C : cout<<" Double2Char("<<arg1<<")"<<endl; break;
            case OPER_I2C : cout<<" Int2Char("<<arg1<<")"<<endl; break;
            case OPER_C2D : cout<<" Char2Double("<<arg1<<")"<<endl; break;
            case OPER_I2D : cout<<" Int2Double("<<arg1<<")"<<endl; break;
            case OPER_C2I : cout<<" Char2Int("<<arg1<<")"<<endl; break;
            case OPER_D2I : cout<<" Double2Int("<<arg1<<")"<<endl; break;
        }            
    }
    else if(op == OPER_PARAM)
    {
        cout<<"param "<<result<<endl;
    }
    else if(op == OPER_ARRAY_INDEX_TO)
    {
        cout<<result<<"["<<arg2<<"]"<<" = "<<arg1<<endl;
    }
    else if(op == OPER_REF)
    {
        cout<<result<<" = &"<<arg1<<endl;   
    }
    else if(op == OPER_DE_REF)
    {
        cout<<result<<" = *"<<arg1<<endl;
    }
    else if(op == OPER_POINTER_ASSIGNMENT)
    {
        cout << "*" << result << " = "  << arg1 << endl;
    }
}

exprr::exprr()
{
    dim_arr = 0;
    temp_arr_name = NULL;
}

exprr::~exprr()
{
    
}

q_array::q_array()
{
    nextinstr = 0;
}

q_array::~q_array()
{

}

void q_array::emit(string res, string arg1, opcode op, string arg2)
{
    quad to_insert;
    to_insert.op = op;
    to_insert.arg1 = arg1;
    to_insert.arg2 = arg2;
    to_insert.result = res;
    array.push_back(to_insert);
    nextinstr++;
}

void q_array::emit(string res, symval s, const char *type, opcode op)
{
    quad to_insert;
    to_insert.op = op;
    to_insert.result = res;
    stringstream ss; 
    if(!strcmp(type, "int"))
        ss << s.intval;
    if(!strcmp(type, "double"))
        ss << s.doubleval;
    if(!strcmp(type, "char"))
        ss << s.charval;
    ss>>to_insert.arg1;
    array.push_back(to_insert); nextinstr++;   
}


void q_array::backpatch(list<int> a, int index)
{
    list<int>::iterator it;
    for(it = a.begin(); it != a.end(); ++it)
    {
        stringstream ss; ss<<index;
        ss>>array[*it].result;
    }
}
void q_array::conv2type(exprr* t, exprr *res, primtype bt)
{
    if(res->p_type == bt) return;
    
    if(res->p_type == DOUBLE && bt == CHAR)
        emit(t->loc,res->loc,OPER_D2C,"");
    else if(res->p_type == DOUBLE && bt == INT)
        emit(t->loc,res->loc,OPER_D2I,"");
    else if(res->p_type == INT && bt == DOUBLE)
        emit(t->loc,res->loc,OPER_I2D,"");
    else if(res->p_type == INT && bt == CHAR)
        emit(t->loc,res->loc,OPER_I2C,"");
    else if(res->p_type == CHAR && bt == INT)
        emit(t->loc,res->loc,OPER_C2I,"");
    else if(res->p_type == CHAR && bt == DOUBLE)
        emit(t->loc,res->loc,OPER_C2D,"");
}

void q_array::convInt2Bool(exprr* res)
{
    if(res->p_type != BOOL)
    {
        res->p_type = BOOL;
        res->falselist = makelist(nextinstr);
        emit("",res->loc,OPER_IF_NOT_EXPRESSION,"");
        res->truelist = makelist(nextinstr);
        emit("","",OPER_GOTO,"");             
    }
}

void q_array::conv2type(string t,primtype bt, string f, primtype from)
{
    if(from == bt) return;
    if(from == DOUBLE && bt == CHAR)
        emit(t,f,OPER_D2C,"");
    else if (from == DOUBLE && bt == INT)
        emit(t,f,OPER_D2I,"");
    else if(from == INT && bt == DOUBLE)
        emit(t,f,OPER_I2D,"");
    else if(from == INT && bt == CHAR) 
        emit(t,f,OPER_I2C,"");
    else if(from == CHAR && bt == DOUBLE)
        emit(t,f,OPER_C2D,"");
    else if(from == CHAR && bt == INT) 
        emit(t,f,OPER_C2I,"");
}

symtab::symtab()
{
    offset = 0;
}

symtab::~symtab()
{
    
}

symtab_entry* symtab::lookup(string var, int pc, primtype bt)
{
    if(!_symtab.count(var))
    {
    	_symtab[var] = new symtab_entry(); 
        ord_sym.push_back(_symtab[var]);
        _symtab[var]->name = var;
        _symtab[var]->type.p_type = bt;
        _symtab[var]->offset = offset;
        _symtab[var]->init_val = NULL;
        
        int tz = 0;
        if(pc)
        {
            _symtab[var]->type.p_type = PTR;
            tz = PTR_SIZE;
            _symtab[var]->type.pc = pc;
            _symtab[var]->type.base_t = bt;
        }
        else
        {
            switch(bt)
            {
                case INT : tz = INT_SIZE; break;
                case CHAR : tz = CHAR_SIZE; break;
                case DOUBLE : tz = DOUBLE_SIZE; break;
                case PTR : tz = PTR_SIZE; break;
                case VOID : tz = 0; break;
                case FUNCTION : tz = 0; break;
                case ARRAY : tz = 0; break;
                default : tz = 0;
            }
        }
        _symtab[var]->size = tz;
        offset += tz;
    }
    return _symtab[var];
}



string symtab::gentemp(primtype bt)
{
    static int count = 0;
    char *s = new char[20];
    sprintf(s, "t%d", count);
    string ret(s);
    
    count++;
    _symtab[ret] = new symtab_entry; 
    ord_sym.push_back(_symtab[ret]);
    _symtab[ret]->name = ret;
    _symtab[ret]->type.p_type = bt;
    _symtab[ret]->offset = offset;
    _symtab[ret]->init_val = NULL;
    int tz = 0;
    switch(bt)
    {
        case INT : tz = INT_SIZE; break;
        case CHAR : tz = CHAR_SIZE; break;
        case DOUBLE : tz = DOUBLE_SIZE; break;
        case PTR : tz = PTR_SIZE; break;
        default : tz = 0;
    }
    _symtab[ret]->size = tz;
    
    offset += tz;
    return ret;
}



void symtab::printsymtab(const char *fn_name)
{
    cout << "============== SYMBOL TABLE (" << fn_name << ") ==============\nNAME\tTYPE\t\tINITVAL\tSIZE\tOFFSET\t\n";
    for(int i = 0; i < ord_sym.size(); i++)
    {
        symtab_entry * t = ord_sym[i];
        cout<<t->name<<"\t"; 
        if(t->type.p_type == CHAR) cout<<"char\t";
        else if(t->type.p_type == INT) cout<<"int\t";
        else if(t->type.p_type == DOUBLE) cout<<"double\t";
        else if(t->type.p_type == VOID) cout << "void\t";
        else if(t->type.p_type == FUNCTION) cout<<"function";
        else 
        {
            if(t->type.base_t == CHAR) cout<<"char";
            else if(t->type.base_t == INT) cout<<"int";
            else if(t->type.base_t == DOUBLE) cout<<"double";
            else if(t->type.base_t == VOID) cout << "void";
            else cout<<"---";
        }
        if(t->type.p_type == PTR)
        {
            for(int i= 0;i<t->type.pc;i++) 
                cout<<"*";
            cout<<"\t";
        }
        if(t->type.p_type == ARRAY)
        {
            vector < int > :: iterator it;
            for(it=t->type.alist.begin() ; it != t->type.alist.end() ; it++)
                 cout<<"["<<*it<<"]";
            cout << "\t";
        }        
        cout << "\t";
        if(t->init_val == NULL) cout<<"null";
        else
        {
            if(t->type.p_type == CHAR) cout<<t->init_val->charval;
            else if(t->type.p_type == INT) cout<<t->init_val->intval;
            else if(t->type.p_type == DOUBLE) cout<<t->init_val->doubleval;
            else cout<<"N/A";
        }
        cout << "\t" << t->size << "\t" << t->offset << "\n";
    }
    cout << "=================================================\n";
}

declr::declr(string id, primtype bt)
{
    name = id;
    pc = 0;
    init_val = 0;
    p_type = bt;
}

vector<int> declr::getArrList()
{
    return alist;
}

declr::declr()
{

}

declr::~declr()
{

}

symtab_entry::symtab_entry()
{
    nested_symtab = NULL;
}
symtab_entry::~symtab_entry()
{

}

bool symtab::ispresent(string s)
{
    if(_symtab.count(s))
        return true;
    return false;
}

list<int> merge(list<int> x, list<int> y)
{
    list<int> temp;
    temp.merge(x);
    temp.merge(y);
    return temp;
}

char *gettype(int arg)
{
    char *tstr = new char[10];
    sprintf(tstr, "int");
}

char *gettype(char arg)
{
    char *tstr = new char[10];
    sprintf(tstr, "char");
}

char *gettype(double arg)
{
    char *tstr = new char[10];
    sprintf(tstr, "double");
}

list<int> makelist(int dangling_goto)
{
    list<int> temp;
    temp.push_back(dangling_goto);
    return temp;
}

void addstr(string s)
{
    if(strmap.find(s) == strmap.end())
    {
        stringstream ss;
        string ls;
        ss << ".LC" << str_cnt;
        ss >> ls;
        ++str_cnt;
        strmap[s] = ls;
    }
}

int line_cnt = 0;

q_array qa;

symtab gst;
symtab *st = &(gst);

int str_cnt = 0;
map < string , string > strmap;
