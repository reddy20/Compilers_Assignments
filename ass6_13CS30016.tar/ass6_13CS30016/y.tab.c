/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* Copy the first part of user declarations.  */
#line 1 "ass6_13CS30016.y" /* yacc.c:339  */
 
#include <string>
#include <iostream>

#include "ass6_13CS30016_translator.h"
extern int yylex();
void yyerror(string s);



#line 77 "y.tab.c" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "y.tab.h".  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    _SINGLECOMMENT = 258,
    _MULTICOMMENT = 259,
    AUTO_KEYWORD = 260,
    BREAK_KEYWORD = 261,
    CASE_KEYWORD = 262,
    CHAR_KEYWORD = 263,
    CONST_KEYWORD = 264,
    CONTINUE_KEYWORD = 265,
    DEFAULT_KEYWORD = 266,
    DO_KEYWORD = 267,
    DOUBLE_KEYWORD = 268,
    ELSE_KEYWORD = 269,
    ENUM_KEYWORD = 270,
    EXTERN_KEYWORD = 271,
    FLOAT_KEYWORD = 272,
    FOR_KEYWORD = 273,
    GOTO_KEYWORD = 274,
    IF_KEYWORD = 275,
    INLINE_KEYWORD = 276,
    INT_KEYWORD = 277,
    LONG_KEYWORD = 278,
    REGISTER_KEYWORD = 279,
    RESTRICT_KEYWORD = 280,
    RETURN_KEYWORD = 281,
    SHORT_KEYWORD = 282,
    SIGNED_KEYWORD = 283,
    SIZEOF_KEYWORD = 284,
    STATIC_KEYWORD = 285,
    STRUCT_KEYWORD = 286,
    SWITCH_KEYWORD = 287,
    TYPEDEF_KEYWORD = 288,
    UNION_KEYWORD = 289,
    UNSIGNED_KEYWORD = 290,
    VOID_KEYWORD = 291,
    VOLATILE_KEYWORD = 292,
    WHILE_KEYWORD = 293,
    _BOOL_KEYWORD = 294,
    _COMPLEX_KEYWORD = 295,
    _IMAGINARY_KEYWORD = 296,
    ARROW = 297,
    INCREMENT_OP = 298,
    DECREMENT_OP = 299,
    SHIFT_LEFT = 300,
    SHIFT_RIGHT = 301,
    LESS_EQUAL = 302,
    GREATER_EQUAL = 303,
    EQUALITY_CHECK = 304,
    NOT_EQUAL = 305,
    AND_OP = 306,
    OR_OP = 307,
    ELLIPSES = 308,
    MULT_EQUAL = 309,
    DIV_EQUAL = 310,
    MOD_EQUAL = 311,
    ADD_EQUAL = 312,
    SUB_EQUAL = 313,
    SHIFT_LEFT_EQUAL = 314,
    SHIFT_RIGHT_EQUAL = 315,
    AND_EQUAL = 316,
    XOR_EQUAL = 317,
    OR_EQUAL = 318,
    STRING_LITERAL = 319,
    IDENTIFIER = 320,
    INT_CONSTANT = 321,
    FLOAT_CONSTANT = 322,
    CHAR_CONSTANT = 323,
    IFC = 324
  };
#endif
/* Tokens.  */
#define _SINGLECOMMENT 258
#define _MULTICOMMENT 259
#define AUTO_KEYWORD 260
#define BREAK_KEYWORD 261
#define CASE_KEYWORD 262
#define CHAR_KEYWORD 263
#define CONST_KEYWORD 264
#define CONTINUE_KEYWORD 265
#define DEFAULT_KEYWORD 266
#define DO_KEYWORD 267
#define DOUBLE_KEYWORD 268
#define ELSE_KEYWORD 269
#define ENUM_KEYWORD 270
#define EXTERN_KEYWORD 271
#define FLOAT_KEYWORD 272
#define FOR_KEYWORD 273
#define GOTO_KEYWORD 274
#define IF_KEYWORD 275
#define INLINE_KEYWORD 276
#define INT_KEYWORD 277
#define LONG_KEYWORD 278
#define REGISTER_KEYWORD 279
#define RESTRICT_KEYWORD 280
#define RETURN_KEYWORD 281
#define SHORT_KEYWORD 282
#define SIGNED_KEYWORD 283
#define SIZEOF_KEYWORD 284
#define STATIC_KEYWORD 285
#define STRUCT_KEYWORD 286
#define SWITCH_KEYWORD 287
#define TYPEDEF_KEYWORD 288
#define UNION_KEYWORD 289
#define UNSIGNED_KEYWORD 290
#define VOID_KEYWORD 291
#define VOLATILE_KEYWORD 292
#define WHILE_KEYWORD 293
#define _BOOL_KEYWORD 294
#define _COMPLEX_KEYWORD 295
#define _IMAGINARY_KEYWORD 296
#define ARROW 297
#define INCREMENT_OP 298
#define DECREMENT_OP 299
#define SHIFT_LEFT 300
#define SHIFT_RIGHT 301
#define LESS_EQUAL 302
#define GREATER_EQUAL 303
#define EQUALITY_CHECK 304
#define NOT_EQUAL 305
#define AND_OP 306
#define OR_OP 307
#define ELLIPSES 308
#define MULT_EQUAL 309
#define DIV_EQUAL 310
#define MOD_EQUAL 311
#define ADD_EQUAL 312
#define SUB_EQUAL 313
#define SHIFT_LEFT_EQUAL 314
#define SHIFT_RIGHT_EQUAL 315
#define AND_EQUAL 316
#define XOR_EQUAL 317
#define OR_EQUAL 318
#define STRING_LITERAL 319
#define IDENTIFIER 320
#define INT_CONSTANT 321
#define FLOAT_CONSTANT 322
#define CHAR_CONSTANT 323
#define IFC 324

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 12 "ass6_13CS30016.y" /* yacc.c:355  */

    char charval;                           // used to represent a character value
    int intval;                             // used to represent an integer value
    double doubleval;                       // used to represent a double precision value
    string *strval;                         // pointer to string
    void* ptr;                              // used to represent a pointer
    primtype p_type;                        // an enum of various supported primitive (basic) data types
    opcode opp;                             // an enum of various supported operators
    symtype *typeinfo;                      // stores the type-expression for a variable
    symtab_entry *symdat;                   // pointer to a row (entry) in the symbol table
    exprr *exp_info;                        // stores the type, value and other various attributes of expressions and statements
    param *prm;                             // stores the name and datatype of a parameter
    vector<param*> *prm_list;               // is a list of parameters
    declr *dec_info;                        // stores the necessary attributes for declaration statements 
    vector<declr*> *ldec;                   // is a list of declarators

#line 272 "y.tab.c" /* yacc.c:355  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */

/* Copy the second part of user declarations.  */

#line 287 "y.tab.c" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  50
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1288

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  94
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  69
/* YYNRULES -- Number of rules.  */
#define YYNRULES  213
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  371

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   324

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    83,     2,     2,     2,    85,    78,     2,
      70,    71,    79,    80,    77,    81,    74,    84,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    91,    93,
      86,    92,    87,    90,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    72,     2,    73,    88,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    75,    89,    76,    82,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   179,   179,   205,   226,   246,   266,   277,   283,   284,
     326,   363,   445,   446,   447,   483,   519,   523,   530,   538,
     549,   550,   580,   609,   685,   689,   696,   700,   704,   708,
     712,   716,   723,   724,   731,   747,   783,   819,   858,   859,
     895,   934,   935,   948,   963,   964,   974,   983,   992,  1003,
    1004,  1013,  1025,  1026,  1036,  1037,  1046,  1047,  1056,  1057,
    1070,  1071,  1085,  1086,  1118,  1119,  1171,  1172,  1173,  1174,
    1175,  1176,  1177,  1178,  1179,  1180,  1181,  1184,  1185,  1188,
    1199,  1214,  1215,  1288,  1292,  1296,  1297,  1298,  1302,  1306,
    1310,  1318,  1323,  1332,  1337,  1344,  1345,  1346,  1347,  1351,
    1355,  1359,  1363,  1367,  1371,  1375,  1379,  1383,  1387,  1391,
    1395,  1399,  1406,  1407,  1408,  1409,  1412,  1413,  1414,  1415,
    1416,  1419,  1420,  1423,  1424,  1427,  1430,  1431,  1432,  1435,
    1437,  1442,  1451,  1456,  1460,  1466,  1467,  1468,  1469,  1518,
    1522,  1523,  1526,  1528,  1535,  1539,  1543,  1547,  1553,  1554,
    1557,  1559,  1564,  1565,  1568,  1573,  1580,  1600,  1607,  1608,
    1612,  1616,  1620,  1624,  1631,  1635,  1639,  1643,  1650,  1654,
    1655,  1658,  1659,  1666,  1667,  1668,  1669,  1670,  1671,  1674,
    1678,  1682,  1689,  1693,  1700,  1705,  1714,  1718,  1721,  1726,
    1729,  1731,  1737,  1748,  1758,  1764,  1775,  1783,  1798,  1806,
    1810,  1814,  1818,  1826,  1846,  1847,  1851,  1852,  1856,  1857,
    1866,  1867,  1875,  1885
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "_SINGLECOMMENT", "_MULTICOMMENT",
  "AUTO_KEYWORD", "BREAK_KEYWORD", "CASE_KEYWORD", "CHAR_KEYWORD",
  "CONST_KEYWORD", "CONTINUE_KEYWORD", "DEFAULT_KEYWORD", "DO_KEYWORD",
  "DOUBLE_KEYWORD", "ELSE_KEYWORD", "ENUM_KEYWORD", "EXTERN_KEYWORD",
  "FLOAT_KEYWORD", "FOR_KEYWORD", "GOTO_KEYWORD", "IF_KEYWORD",
  "INLINE_KEYWORD", "INT_KEYWORD", "LONG_KEYWORD", "REGISTER_KEYWORD",
  "RESTRICT_KEYWORD", "RETURN_KEYWORD", "SHORT_KEYWORD", "SIGNED_KEYWORD",
  "SIZEOF_KEYWORD", "STATIC_KEYWORD", "STRUCT_KEYWORD", "SWITCH_KEYWORD",
  "TYPEDEF_KEYWORD", "UNION_KEYWORD", "UNSIGNED_KEYWORD", "VOID_KEYWORD",
  "VOLATILE_KEYWORD", "WHILE_KEYWORD", "_BOOL_KEYWORD", "_COMPLEX_KEYWORD",
  "_IMAGINARY_KEYWORD", "ARROW", "INCREMENT_OP", "DECREMENT_OP",
  "SHIFT_LEFT", "SHIFT_RIGHT", "LESS_EQUAL", "GREATER_EQUAL",
  "EQUALITY_CHECK", "NOT_EQUAL", "AND_OP", "OR_OP", "ELLIPSES",
  "MULT_EQUAL", "DIV_EQUAL", "MOD_EQUAL", "ADD_EQUAL", "SUB_EQUAL",
  "SHIFT_LEFT_EQUAL", "SHIFT_RIGHT_EQUAL", "AND_EQUAL", "XOR_EQUAL",
  "OR_EQUAL", "STRING_LITERAL", "IDENTIFIER", "INT_CONSTANT",
  "FLOAT_CONSTANT", "CHAR_CONSTANT", "IFC", "'('", "')'", "'['", "']'",
  "'.'", "'{'", "'}'", "','", "'&'", "'*'", "'+'", "'-'", "'~'", "'!'",
  "'/'", "'%'", "'<'", "'>'", "'^'", "'|'", "'?'", "':'", "'='", "';'",
  "$accept", "primary_expression", "postfix_expression",
  "argument_expression_list", "unary_expression", "unary_operator",
  "cast_expression", "multiplicative_expression", "additive_expression",
  "shift_expression", "relational_expression", "equality_expression",
  "and_expression", "exclusive_or_expression", "inclusive_or_expression",
  "logical_and_expression", "logical_or_expression",
  "conditional_expression", "assignment_expression", "assignment_operator",
  "expression", "constant_expression", "fn_signature", "declaration",
  "declaration_specifiers", "init_declarator_list", "init_declarator",
  "storage_class_specifier", "type_specifier", "specifier_qualifier_list",
  "enum_specifier", "enumerator_list", "enumerator",
  "enumeration_constant", "type_qualifier", "function_specifier",
  "declarator", "direct_declarator", "type_qualifier_list_opt",
  "assignment_expression_opt", "pointer", "type_qualifier_list",
  "parameter_type_list_opt", "parameter_type_list", "parameter_list",
  "parameter_declaration", "identifier_list", "type_name", "initializer",
  "initializer_list", "designation", "designator_list", "designator",
  "statement", "labeled_statement", "compound_statement",
  "block_item_list", "block_item", "expression_statement",
  "expression_opt", "selection_statement", "iteration_statement",
  "jump_statement", "translation_unit", "external_declaration",
  "function_definition", "declaration_list", "N", "M", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
      40,    41,    91,    93,    46,   123,   125,    44,    38,    42,
      43,    45,   126,    33,    47,    37,    60,    62,    94,   124,
      63,    58,    61,    59
};
# endif

#define YYPACT_NINF -261

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-261)))

#define YYTABLE_NINF -213

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    1213,  -261,  -261,  -261,  -261,    71,  -261,  -261,  -261,  -261,
    -261,  -261,  -261,  -261,  -261,  -261,  -261,  -261,  -261,  -261,
    -261,  -261,   -50,  -261,   108,  1213,  1213,  -261,  1213,  1213,
    1176,  -261,  -261,   -39,    18,   300,  -261,  -261,    77,    61,
    -261,   -45,  -261,   536,    80,   -13,  -261,  -261,  -261,  -261,
    -261,  -261,    18,  -261,    38,  -261,   -12,     6,   971,    19,
      44,  -261,    68,    84,    85,   717,   999,   106,  -261,  1027,
    1027,  -261,    74,  -261,  -261,  -261,   649,  -261,  -261,  -261,
    -261,  -261,  -261,  -261,  -261,  -261,   196,   373,   971,  -261,
      78,   115,   176,    96,   179,   101,   105,   128,   134,   -35,
    -261,  -261,   -40,  -261,   108,  -261,  -261,  -261,   143,  -261,
    -261,  -261,  -261,  -261,   133,  -261,  -261,    61,    77,  -261,
     915,  -261,   728,   796,   183,    80,   158,  -261,    27,   971,
    -261,  -261,  -261,  -261,   135,  -261,   457,   457,   573,   131,
     971,  -261,    -8,   649,  -261,   971,   175,   649,  -261,  -261,
     457,   -49,  1247,  -261,  1247,   186,   197,  -261,  -261,    -5,
     971,   200,  -261,  -261,  -261,  -261,  -261,  -261,  -261,  -261,
    -261,  -261,  -261,   971,  -261,   971,   971,   971,   971,   971,
     971,   971,   971,   971,   971,   971,   971,   971,   971,   971,
     971,   216,   -26,   971,  -261,   177,  -261,   379,  -261,  -261,
    -261,  -261,   882,  -261,  -261,  -261,  -261,  -261,    77,   206,
    -261,   201,  -261,   -37,    42,  1055,   221,  -261,    40,  -261,
    -261,  -261,   457,  -261,  -261,   205,   971,   190,  -261,   205,
    -261,   213,    95,   971,   215,  -261,  -261,  -261,  -261,   943,
    -261,  -261,    97,  -261,   130,  -261,  -261,  -261,  -261,  -261,
      78,    78,   115,   115,   176,   176,   176,   176,    96,    96,
     179,   101,   105,  -261,  -261,  -261,  -261,  -261,   971,   224,
    -261,   165,   915,   -43,  -261,  -261,  -261,  1134,  -261,   226,
     971,    42,   219,  -261,   222,   971,  -261,  -261,   256,   204,
    -261,   228,   239,   457,   205,   239,   882,  -261,  -261,   971,
    -261,   971,   971,   971,   230,  -261,  -261,   798,  -261,  -261,
    -261,  -261,  -261,  -261,   258,  -261,  -261,   260,   264,   971,
     971,  -261,  -261,   271,   184,  -261,   128,  -261,   205,  -261,
    -261,  -261,   915,  -261,  -261,   971,   274,  -261,   457,  -261,
    -261,   840,  -261,   216,   255,  -261,   113,   457,   254,  -261,
     457,  -261,  -261,   257,  -261,  -261,   334,  -261,   971,  -261,
     971,  -261,  -261,  -261,   457,   278,  -261,  -261,  -261,   457,
    -261
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,    97,   100,   126,   105,     0,    95,   104,   129,   102,
     103,    98,   127,   101,   106,    96,   107,    99,   128,   108,
     109,   110,     0,   207,     0,    83,    85,   111,    87,    89,
       0,   204,   206,   120,     0,     0,   209,   132,     0,   144,
      81,     0,    91,    93,   131,     0,    84,    86,    88,    90,
       1,   205,     0,   125,     0,   121,   123,     0,     0,     0,
       0,   213,     0,     0,     0,     0,     0,     0,   213,     0,
       0,     6,     2,     3,     4,     5,     0,   183,    26,    27,
      28,    29,    30,    31,   188,     8,    20,    32,     0,    34,
      38,    41,    44,    49,    52,    54,    56,    58,    60,    62,
      64,    77,     0,   186,     0,   187,   173,   174,   213,   184,
     175,   176,   177,   178,     0,   148,   146,   145,     0,    82,
       0,   210,     0,   151,   141,   130,     0,   116,     0,     0,
     201,     2,    32,    79,     0,   200,     0,     0,   191,     0,
       0,   202,     0,     0,    24,     0,     0,     0,    21,    22,
       0,     0,   113,   160,   115,     0,     0,    14,    15,     0,
       0,     0,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    66,     0,    23,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   189,    93,   182,     0,   133,   149,
     147,    92,     0,   161,    94,   211,   208,   158,   157,     0,
     150,   152,   154,     0,   141,   143,   140,   117,     0,   118,
     122,   124,     0,   181,   213,   190,   191,     0,   199,   212,
     203,     0,     0,     0,     0,   179,     7,   112,   114,     0,
      13,    10,     0,    18,     0,    12,    65,    35,    36,    37,
      39,    40,    42,    43,    47,    48,    45,    46,    50,    51,
      53,    55,    57,   213,   213,   213,    78,   185,     0,     0,
     164,     0,     0,     0,   169,   156,   138,     0,   139,     0,
       0,   140,    27,   142,     0,     0,   119,   180,     0,     0,
     213,     0,    25,     0,   212,     0,     0,    33,    11,     0,
       9,     0,     0,     0,     0,   172,   162,     0,   166,   168,
     170,   153,   155,   159,     0,   137,   134,     0,     0,   191,
     191,   213,   194,     0,     0,    19,   212,   212,   212,   171,
     163,   165,     0,   135,   136,     0,     0,   212,     0,   213,
      16,     0,    59,    61,     0,   167,     0,     0,     0,   212,
       0,    17,   213,     0,   198,   213,   193,   195,     0,   196,
     191,   213,    63,   212,     0,     0,   212,   213,   192,     0,
     197
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -261,  -261,  -261,  -261,   -58,  -261,   -81,    94,   100,    70,
      89,   163,   164,   162,    53,    54,  -261,   -57,  -105,  -261,
     -56,  -123,  -261,    15,    16,  -261,   237,  -261,   -41,    34,
    -261,   305,  -109,  -261,    17,  -261,   -11,   313,   145,  -261,
     -16,  -114,  -261,  -261,  -261,    83,  -261,    62,  -118,    65,
    -260,  -261,    90,  -132,  -261,    11,  -261,   172,  -261,  -212,
    -261,  -261,  -261,  -261,   332,  -261,  -261,   -78,   -65
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    85,    86,   242,    87,    88,    89,    90,    91,    92,
      93,    94,    95,    96,    97,    98,    99,   100,   101,   173,
     102,   134,    22,    23,   104,    41,    42,    25,    26,   153,
      27,    54,    55,    56,    28,    29,   195,    44,   215,   284,
      45,   117,   209,   210,   211,   212,   213,   155,   270,   271,
     272,   273,   274,   105,   106,   107,   108,   109,   110,   227,
     111,   112,   113,    30,    31,    32,   122,   191,   137
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
     132,   133,   204,   146,   223,   224,   221,   174,   144,   142,
     216,   148,   149,    43,   289,   203,    24,  -212,   235,   220,
     151,   192,   236,   116,    66,    35,   264,   114,   193,   268,
     132,   269,   118,    36,   278,   152,    52,   193,    69,    70,
     279,    46,    47,   197,    48,    49,    24,   332,   119,   309,
     103,     3,    37,   194,   243,  -212,   115,    38,   121,    71,
     131,    73,    74,    75,   265,    76,   241,    12,   246,   193,
       3,   132,   133,    78,    79,    80,    81,    82,    83,    18,
     129,   332,   225,    53,   229,   230,    12,   151,   266,   232,
     287,   151,    53,   154,   247,   248,   249,   203,    18,   130,
     281,   200,   152,   219,   244,    53,   152,   336,   337,   220,
     283,   152,   135,   152,   127,   128,   286,   132,   132,   132,
     132,   132,   132,   132,   132,   132,   132,   132,   132,   132,
     132,   132,   132,   206,   199,   136,    33,   205,   138,   208,
      39,   115,    37,   182,   183,   304,    34,    38,   363,   139,
     123,   291,   124,   226,   308,   140,    39,   175,   297,   288,
     154,   322,   176,   177,   154,   150,   293,   203,   298,   154,
     225,   154,   193,    37,   299,   314,   145,   294,    38,   188,
     317,   132,   184,   185,   353,  -212,   237,    39,   238,   331,
     193,   203,     3,   189,   325,   178,   179,   275,   301,   302,
     303,    40,   203,   300,   198,   231,   349,   193,    12,   234,
     132,   133,   103,   214,   345,   354,   323,   190,   357,   196,
      18,   180,   181,   331,   228,   320,   222,   203,   186,   187,
       3,   115,   366,   199,   217,   218,   203,   370,   156,   157,
     158,   306,   307,   132,   132,   233,    12,   328,   342,   343,
     344,   285,   254,   255,   256,   257,   338,   239,    18,   348,
     340,   341,   240,   225,   225,   245,   159,   263,   160,   120,
     161,   356,   250,   251,   350,   258,   259,   276,   277,   346,
     252,   253,   193,   290,   292,   365,   295,   358,   368,   305,
     360,   313,   315,   208,   318,   316,   364,   319,   199,   321,
     132,   362,   369,   329,   225,     1,    57,    58,     2,     3,
      59,    60,    61,     4,   296,     5,     6,     7,    62,    63,
      64,     8,     9,    10,    11,    12,    65,    13,    14,    66,
      15,   333,    67,   334,   335,    16,    17,    18,    68,    19,
      20,    21,   339,    69,    70,   347,   352,   355,   361,   367,
     359,   260,   262,   261,   326,   201,   327,   126,   125,   280,
     312,   324,    51,   310,    71,    72,    73,    74,    75,   267,
      76,     0,     0,     0,     0,    35,    77,     0,    78,    79,
      80,    81,    82,    83,     1,    57,    58,     2,     3,    59,
      60,    61,     4,    84,     5,     6,     7,    62,    63,    64,
       8,     9,    10,    11,    12,    65,    13,    14,    66,    15,
       0,    67,     0,     0,    16,    17,    18,    68,    19,    20,
      21,     0,    69,    70,     0,     0,     0,   162,   163,   164,
     165,   166,   167,   168,   169,   170,   171,     0,     0,     0,
       0,     0,     0,    71,    72,    73,    74,    75,     0,    76,
       0,     0,     0,     0,    35,     0,     0,    78,    79,    80,
      81,    82,    83,    57,    58,   172,     0,    59,    60,    61,
       0,     0,    84,     0,     0,    62,    63,    64,     0,     0,
       0,     0,     0,    65,     0,     0,    66,     0,     0,    67,
       0,     0,     0,     0,     0,    68,     0,     0,     0,     0,
      69,    70,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    71,    72,    73,    74,    75,     0,    76,     0,     0,
       0,     0,    35,     0,     0,    78,    79,    80,    81,    82,
      83,     1,     0,     0,     2,     3,     0,     0,     0,     4,
      84,     5,     6,     7,     0,     0,     0,     8,     9,    10,
      11,    12,     0,    13,    14,     0,    15,     0,     0,     0,
       0,    16,    17,    18,     0,    19,    20,    21,     1,     0,
       0,     2,     3,     0,     0,     0,     4,     0,     5,     6,
       7,     0,     0,     0,     8,     9,    10,    11,    12,     0,
      13,    14,    66,    15,     0,     0,     0,     0,    16,    17,
      18,   -80,    19,    20,    21,     0,    69,    70,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   120,     0,
       0,     0,     0,     0,     0,     0,     0,    71,   131,    73,
      74,    75,     0,    76,     0,     0,     0,     0,     0,     0,
       0,    78,    79,    80,    81,    82,    83,     2,     3,     0,
       0,     0,     4,     0,     5,     0,     7,     0,     0,     0,
       0,     9,    10,     0,    12,     0,    13,    14,    66,     0,
       0,     0,     0,     0,    16,    17,    18,     0,    19,    20,
      21,     0,    69,    70,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    71,   131,    73,    74,    75,     0,    76,
       0,     0,     0,     0,     0,     0,     0,    78,    79,    80,
      81,    82,    83,     1,     0,     0,     2,     3,     0,     0,
       0,     4,     0,     5,     6,     7,    66,     0,     0,     8,
       9,    10,    11,    12,     0,    13,    14,     0,    15,     0,
      69,    70,     0,    16,    17,    18,     0,    19,    20,    21,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    71,   131,    73,    74,    75,     0,    76,     0,     0,
       0,     0,     0,     0,     0,    78,    79,    80,    81,    82,
      83,     1,     0,    35,     2,     3,     0,     0,     0,     4,
     141,     5,     6,     7,     0,     0,     0,     8,     9,    10,
      11,    12,     0,    13,    14,     0,    15,    66,     0,     0,
       0,    16,    17,    18,     0,    19,    20,    21,     0,     0,
       0,    69,    70,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   207,    71,   131,    73,    74,    75,     0,    76,    66,
     268,     0,   269,   202,   330,     0,    78,    79,    80,    81,
      82,    83,     0,    69,    70,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    71,   131,    73,    74,    75,     0,
      76,    66,   268,     0,   269,   202,   351,     0,    78,    79,
      80,    81,    82,    83,     0,    69,    70,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    66,     0,    71,   131,    73,    74,
      75,     0,    76,     0,   268,     0,   269,   202,    69,    70,
      78,    79,    80,    81,    82,    83,     0,     0,     0,     0,
       0,     0,    66,     0,     0,     0,     0,     0,     0,    71,
     131,    73,    74,    75,     0,    76,    69,    70,     0,     0,
     202,     0,     0,    78,    79,    80,    81,    82,    83,     0,
      66,     0,     0,     0,     0,     0,     0,    71,   131,    73,
      74,    75,     0,    76,    69,    70,     0,     0,   296,     0,
       0,    78,    79,    80,    81,    82,    83,     0,    66,     0,
       0,     0,     0,     0,     0,    71,   131,    73,    74,    75,
       0,    76,    69,    70,     0,     0,     0,     0,     0,    78,
      79,    80,    81,    82,    83,     0,    66,     0,     0,     0,
       0,     0,     0,    71,   131,    73,    74,    75,     0,   143,
      69,    70,     0,     0,     0,     0,     0,    78,    79,    80,
      81,    82,    83,     0,    66,     0,     0,     0,     0,     0,
       0,    71,   131,    73,    74,    75,     0,   147,    69,    70,
       0,     0,     0,     0,     0,    78,    79,    80,    81,    82,
      83,     0,     0,     0,     0,     0,     0,     0,     0,    71,
     131,    73,    74,    75,     0,    76,     0,     0,     0,     0,
       0,     0,     0,    78,   282,    80,    81,    82,    83,     1,
       0,     0,     2,     3,     0,     0,     0,     4,     0,     5,
       6,     7,     0,     0,     0,     8,     9,    10,    11,    12,
       0,    13,    14,     0,    15,     0,     0,     0,     0,    16,
      17,    18,     0,    19,    20,    21,    50,     0,     0,     0,
       0,     1,     0,     0,     2,     3,     0,   311,     0,     4,
       0,     5,     6,     7,     0,     0,     0,     8,     9,    10,
      11,    12,     0,    13,    14,     0,    15,     0,     0,     0,
       0,    16,    17,    18,     0,    19,    20,    21,     1,     0,
       0,     2,     3,     0,     0,     0,     4,     0,     5,     6,
       7,     0,     0,     0,     8,     9,    10,    11,    12,     0,
      13,    14,     0,    15,     0,     0,     0,     0,    16,    17,
      18,     0,    19,    20,    21,     2,     3,     0,     0,     0,
       4,     0,     5,     0,     7,     0,     0,     0,     0,     9,
      10,     0,    12,     0,    13,    14,     0,     0,     0,     0,
       0,     0,    16,    17,    18,     0,    19,    20,    21
};

static const yytype_int16 yycheck[] =
{
      58,    58,   120,    68,   136,   137,   129,    88,    66,    65,
     124,    69,    70,    24,   226,   120,     0,    52,   150,   128,
      76,    99,    71,    39,    29,    75,    52,    38,    77,    72,
      88,    74,    77,    22,    71,    76,    75,    77,    43,    44,
      77,    25,    26,   108,    28,    29,    30,   307,    93,    92,
      35,     9,    65,    93,   159,    90,    39,    70,    43,    64,
      65,    66,    67,    68,    90,    70,    71,    25,   173,    77,
       9,   129,   129,    78,    79,    80,    81,    82,    83,    37,
      92,   341,   138,    65,   140,    93,    25,   143,   193,   145,
     222,   147,    65,    76,   175,   176,   177,   202,    37,    93,
     214,   117,   143,    76,   160,    65,   147,   319,   320,   218,
     215,   152,    93,   154,    76,    77,    76,   175,   176,   177,
     178,   179,   180,   181,   182,   183,   184,   185,   186,   187,
     188,   189,   190,   122,   117,    91,    65,   122,    70,   123,
      79,   124,    65,    47,    48,   268,    75,    70,   360,    65,
      70,   229,    72,   138,   272,    70,    79,    79,   239,   224,
     143,   293,    84,    85,   147,    91,    71,   272,    71,   152,
     226,   154,    77,    65,    77,   280,    70,   233,    70,    78,
     285,   239,    86,    87,    71,    51,   152,    79,   154,   307,
      77,   296,     9,    88,   299,    80,    81,   208,   263,   264,
     265,    93,   307,    73,    71,   143,   338,    77,    25,   147,
     268,   268,   197,    30,   332,   347,   294,    89,   350,    76,
      37,    45,    46,   341,    93,   290,    91,   332,    49,    50,
       9,   214,   364,   216,    76,    77,   341,   369,    42,    43,
      44,    76,    77,   301,   302,    70,    25,   303,   326,   327,
     328,    30,   182,   183,   184,   185,   321,    71,    37,   337,
      76,    77,    65,   319,   320,    65,    70,    51,    72,    92,
      74,   349,   178,   179,   339,   186,   187,    71,    77,   335,
     180,   181,    77,    93,    71,   363,    71,   352,   366,    65,
     355,    65,    73,   277,    38,    73,   361,    93,   281,    71,
     358,   358,   367,    73,   360,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    75,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    73,    32,    73,    70,    35,    36,    37,    38,    39,
      40,    41,    71,    43,    44,    71,    91,    93,    14,    71,
      93,   188,   190,   189,   301,   118,   302,    52,    45,   214,
     277,   296,    30,   273,    64,    65,    66,    67,    68,   197,
      70,    -1,    -1,    -1,    -1,    75,    76,    -1,    78,    79,
      80,    81,    82,    83,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    93,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      -1,    32,    -1,    -1,    35,    36,    37,    38,    39,    40,
      41,    -1,    43,    44,    -1,    -1,    -1,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    -1,    -1,    -1,
      -1,    -1,    -1,    64,    65,    66,    67,    68,    -1,    70,
      -1,    -1,    -1,    -1,    75,    -1,    -1,    78,    79,    80,
      81,    82,    83,     6,     7,    92,    -1,    10,    11,    12,
      -1,    -1,    93,    -1,    -1,    18,    19,    20,    -1,    -1,
      -1,    -1,    -1,    26,    -1,    -1,    29,    -1,    -1,    32,
      -1,    -1,    -1,    -1,    -1,    38,    -1,    -1,    -1,    -1,
      43,    44,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    64,    65,    66,    67,    68,    -1,    70,    -1,    -1,
      -1,    -1,    75,    -1,    -1,    78,    79,    80,    81,    82,
      83,     5,    -1,    -1,     8,     9,    -1,    -1,    -1,    13,
      93,    15,    16,    17,    -1,    -1,    -1,    21,    22,    23,
      24,    25,    -1,    27,    28,    -1,    30,    -1,    -1,    -1,
      -1,    35,    36,    37,    -1,    39,    40,    41,     5,    -1,
      -1,     8,     9,    -1,    -1,    -1,    13,    -1,    15,    16,
      17,    -1,    -1,    -1,    21,    22,    23,    24,    25,    -1,
      27,    28,    29,    30,    -1,    -1,    -1,    -1,    35,    36,
      37,    75,    39,    40,    41,    -1,    43,    44,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    92,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    64,    65,    66,
      67,    68,    -1,    70,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    78,    79,    80,    81,    82,    83,     8,     9,    -1,
      -1,    -1,    13,    -1,    15,    -1,    17,    -1,    -1,    -1,
      -1,    22,    23,    -1,    25,    -1,    27,    28,    29,    -1,
      -1,    -1,    -1,    -1,    35,    36,    37,    -1,    39,    40,
      41,    -1,    43,    44,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    64,    65,    66,    67,    68,    -1,    70,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    78,    79,    80,
      81,    82,    83,     5,    -1,    -1,     8,     9,    -1,    -1,
      -1,    13,    -1,    15,    16,    17,    29,    -1,    -1,    21,
      22,    23,    24,    25,    -1,    27,    28,    -1,    30,    -1,
      43,    44,    -1,    35,    36,    37,    -1,    39,    40,    41,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    64,    65,    66,    67,    68,    -1,    70,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    78,    79,    80,    81,    82,
      83,     5,    -1,    75,     8,     9,    -1,    -1,    -1,    13,
      93,    15,    16,    17,    -1,    -1,    -1,    21,    22,    23,
      24,    25,    -1,    27,    28,    -1,    30,    29,    -1,    -1,
      -1,    35,    36,    37,    -1,    39,    40,    41,    -1,    -1,
      -1,    43,    44,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    65,    64,    65,    66,    67,    68,    -1,    70,    29,
      72,    -1,    74,    75,    76,    -1,    78,    79,    80,    81,
      82,    83,    -1,    43,    44,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    64,    65,    66,    67,    68,    -1,
      70,    29,    72,    -1,    74,    75,    76,    -1,    78,    79,
      80,    81,    82,    83,    -1,    43,    44,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    29,    -1,    64,    65,    66,    67,
      68,    -1,    70,    -1,    72,    -1,    74,    75,    43,    44,
      78,    79,    80,    81,    82,    83,    -1,    -1,    -1,    -1,
      -1,    -1,    29,    -1,    -1,    -1,    -1,    -1,    -1,    64,
      65,    66,    67,    68,    -1,    70,    43,    44,    -1,    -1,
      75,    -1,    -1,    78,    79,    80,    81,    82,    83,    -1,
      29,    -1,    -1,    -1,    -1,    -1,    -1,    64,    65,    66,
      67,    68,    -1,    70,    43,    44,    -1,    -1,    75,    -1,
      -1,    78,    79,    80,    81,    82,    83,    -1,    29,    -1,
      -1,    -1,    -1,    -1,    -1,    64,    65,    66,    67,    68,
      -1,    70,    43,    44,    -1,    -1,    -1,    -1,    -1,    78,
      79,    80,    81,    82,    83,    -1,    29,    -1,    -1,    -1,
      -1,    -1,    -1,    64,    65,    66,    67,    68,    -1,    70,
      43,    44,    -1,    -1,    -1,    -1,    -1,    78,    79,    80,
      81,    82,    83,    -1,    29,    -1,    -1,    -1,    -1,    -1,
      -1,    64,    65,    66,    67,    68,    -1,    70,    43,    44,
      -1,    -1,    -1,    -1,    -1,    78,    79,    80,    81,    82,
      83,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    64,
      65,    66,    67,    68,    -1,    70,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    78,    79,    80,    81,    82,    83,     5,
      -1,    -1,     8,     9,    -1,    -1,    -1,    13,    -1,    15,
      16,    17,    -1,    -1,    -1,    21,    22,    23,    24,    25,
      -1,    27,    28,    -1,    30,    -1,    -1,    -1,    -1,    35,
      36,    37,    -1,    39,    40,    41,     0,    -1,    -1,    -1,
      -1,     5,    -1,    -1,     8,     9,    -1,    53,    -1,    13,
      -1,    15,    16,    17,    -1,    -1,    -1,    21,    22,    23,
      24,    25,    -1,    27,    28,    -1,    30,    -1,    -1,    -1,
      -1,    35,    36,    37,    -1,    39,    40,    41,     5,    -1,
      -1,     8,     9,    -1,    -1,    -1,    13,    -1,    15,    16,
      17,    -1,    -1,    -1,    21,    22,    23,    24,    25,    -1,
      27,    28,    -1,    30,    -1,    -1,    -1,    -1,    35,    36,
      37,    -1,    39,    40,    41,     8,     9,    -1,    -1,    -1,
      13,    -1,    15,    -1,    17,    -1,    -1,    -1,    -1,    22,
      23,    -1,    25,    -1,    27,    28,    -1,    -1,    -1,    -1,
      -1,    -1,    35,    36,    37,    -1,    39,    40,    41
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     5,     8,     9,    13,    15,    16,    17,    21,    22,
      23,    24,    25,    27,    28,    30,    35,    36,    37,    39,
      40,    41,   116,   117,   118,   121,   122,   124,   128,   129,
     157,   158,   159,    65,    75,    75,   149,    65,    70,    79,
      93,   119,   120,   130,   131,   134,   118,   118,   118,   118,
       0,   158,    75,    65,   125,   126,   127,     6,     7,    10,
      11,    12,    18,    19,    20,    26,    29,    32,    38,    43,
      44,    64,    65,    66,    67,    68,    70,    76,    78,    79,
      80,    81,    82,    83,    93,    95,    96,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,   112,   114,   117,   118,   147,   148,   149,   150,   151,
     152,   154,   155,   156,   130,   128,   134,   135,    77,    93,
      92,   117,   160,    70,    72,   131,   125,    76,    77,    92,
      93,    65,    98,   111,   115,    93,    91,   162,    70,    65,
      70,    93,   114,    70,    98,    70,   162,    70,    98,    98,
      91,   114,   122,   123,   128,   141,    42,    43,    44,    70,
      72,    74,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    92,   113,   100,    79,    84,    85,    80,    81,
      45,    46,    47,    48,    86,    87,    49,    50,    78,    88,
      89,   161,   161,    77,    93,   130,    76,   162,    71,   128,
     134,   120,    75,   112,   142,   117,   149,    65,   118,   136,
     137,   138,   139,   140,    30,   132,   135,    76,    77,    76,
     126,   115,    91,   147,   147,   114,   117,   153,    93,   114,
      93,   141,   114,    70,   141,   147,    71,   123,   123,    71,
      65,    71,    97,   112,   114,    65,   112,   100,   100,   100,
     101,   101,   102,   102,   103,   103,   103,   103,   104,   104,
     105,   106,   107,    51,    52,    90,   112,   151,    72,    74,
     142,   143,   144,   145,   146,   130,    71,    77,    71,    77,
     132,   135,    79,   112,   133,    30,    76,   147,   162,   153,
      93,   161,    71,    71,   114,    71,    75,   100,    71,    77,
      73,   162,   162,   162,   115,    65,    76,    77,   142,    92,
     146,    53,   139,    65,   112,    73,    73,   112,    38,    93,
     162,    71,   147,   161,   143,   112,   108,   109,   114,    73,
      76,   142,   144,    73,    73,    70,   153,   153,   162,    71,
      76,    77,   161,   161,   161,   142,   114,    71,   161,   147,
     162,    76,    91,    71,   147,    93,   161,   147,   162,    93,
     162,    14,   111,   153,   162,   161,   147,    71,   161,   162,
     147
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    94,    95,    95,    95,    95,    95,    95,    96,    96,
      96,    96,    96,    96,    96,    96,    96,    96,    97,    97,
      98,    98,    98,    98,    98,    98,    99,    99,    99,    99,
      99,    99,   100,   100,   101,   101,   101,   101,   102,   102,
     102,   103,   103,   103,   104,   104,   104,   104,   104,   105,
     105,   105,   106,   106,   107,   107,   108,   108,   109,   109,
     110,   110,   111,   111,   112,   112,   113,   113,   113,   113,
     113,   113,   113,   113,   113,   113,   113,   114,   114,   115,
     116,   117,   117,   118,   118,   118,   118,   118,   118,   118,
     118,   119,   119,   120,   120,   121,   121,   121,   121,   122,
     122,   122,   122,   122,   122,   122,   122,   122,   122,   122,
     122,   122,   123,   123,   123,   123,   124,   124,   124,   124,
     124,   125,   125,   126,   126,   127,   128,   128,   128,   129,
     130,   130,   131,   131,   131,   131,   131,   131,   131,   131,
     132,   132,   133,   133,   134,   134,   134,   134,   135,   135,
     136,   136,   137,   137,   138,   138,   139,   139,   140,   140,
     141,   142,   142,   142,   143,   143,   143,   143,   144,   145,
     145,   146,   146,   147,   147,   147,   147,   147,   147,   148,
     148,   148,   149,   149,   150,   150,   151,   151,   152,   152,
     153,   153,   154,   154,   154,   155,   155,   155,   155,   156,
     156,   156,   156,   156,   157,   157,   158,   158,   159,   159,
     160,   160,   161,   162
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     1,     1,     1,     1,     3,     1,     4,
       3,     4,     3,     3,     2,     2,     6,     7,     1,     3,
       1,     2,     2,     2,     2,     4,     1,     1,     1,     1,
       1,     1,     1,     4,     1,     3,     3,     3,     1,     3,
       3,     1,     3,     3,     1,     3,     3,     3,     3,     1,
       3,     3,     1,     3,     1,     3,     1,     3,     1,     6,
       1,     6,     1,     9,     1,     3,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     3,     1,
       2,     2,     3,     1,     2,     1,     2,     1,     2,     1,
       2,     1,     3,     1,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     1,     2,     1,     4,     5,     5,     6,
       2,     1,     3,     1,     3,     1,     1,     1,     1,     1,
       2,     1,     1,     3,     5,     6,     6,     5,     4,     4,
       1,     0,     1,     0,     1,     2,     2,     3,     1,     2,
       1,     0,     1,     3,     1,     3,     2,     1,     1,     3,
       1,     1,     3,     4,     1,     3,     2,     4,     2,     1,
       2,     3,     2,     1,     1,     1,     1,     1,     1,     3,
       4,     3,     3,     2,     1,     3,     1,     1,     1,     2,
       1,     0,    12,     8,     5,     8,     9,    14,     8,     3,
       2,     2,     2,     3,     1,     2,     1,     1,     4,     2,
       1,     2,     0,     0
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 180 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr; 
            string t = (*((yyvsp[0].strval)));
            symtab_entry *t1 = NULL; 
            if(st->ispresent(t))
                t1 = st->lookup(t);
            else
            {
                if(gst.ispresent(t))
                {
                    t1 = gst.lookup(t);
                }
                else
                {
                    yyerror("syntax error : variable was not declared in this scope");
                }
            }
            if(t1 != NULL)
            {
                (yyval.exp_info)->p_type = (t1->type).p_type;
            }
            else
                (yyval.exp_info)->p_type = none;
            (yyval.exp_info)->loc = t;
        }
#line 1873 "y.tab.c" /* yacc.c:1646  */
    break;

  case 3:
#line 206 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->loc = st->gentemp(INT);
        (yyval.exp_info)->p_type = INT;
        symtab_entry *se = st->lookup((yyval.exp_info)->loc);
        se->type.base_t = (yyval.exp_info)->p_type;
        se->type.pc = 0;
       
        symval s;
        s.intval = (yyvsp[0].intval);
        qa.emit((yyval.exp_info)->loc, s, "int", OPER_ASSIGN);
        symval *t = new symval;
        if(!strcmp(gettype((yyvsp[0].intval)), "int"))
        {
            t->intval = (yyvsp[0].intval);
            t->doubleval = (double)(yyvsp[0].intval);
            t->charval = (char)(yyvsp[0].intval);
            st->lookup((yyval.exp_info)->loc)->init_val = t;    
        }
    }
#line 1898 "y.tab.c" /* yacc.c:1646  */
    break;

  case 4:
#line 227 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(DOUBLE);
        (yyval.exp_info)->p_type = DOUBLE;
        symtab_entry *se = st->lookup((yyval.exp_info)->loc);
        se->type.base_t = (yyval.exp_info)->p_type;
        se->type.pc = 0;
        symval s;
        s.doubleval = (yyvsp[0].doubleval);
        qa.emit((yyval.exp_info)->loc, s, "double", OPER_ASSIGN);
        symval *t = new symval; 
        if(!strcmp(gettype((yyvsp[0].doubleval)), "double"))
        {
            t->doubleval = (yyvsp[0].doubleval);
            t->intval = (int)(yyvsp[0].doubleval);
            t->charval = (char)(yyvsp[0].doubleval);
            st->lookup((yyval.exp_info)->loc)->init_val = t;    
        }
    }
#line 1922 "y.tab.c" /* yacc.c:1646  */
    break;

  case 5:
#line 247 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(CHAR);
        (yyval.exp_info)->p_type = CHAR;
        symtab_entry *se = st->lookup((yyval.exp_info)->loc);
        se->type.base_t = (yyval.exp_info)->p_type;
        se->type.pc = 0;
        symval s; 
        s.charval = (yyvsp[0].charval);
        qa.emit((yyval.exp_info)->loc, s, "char", OPER_ASSIGN);
        symval *t = new symval; 
        if(!strcmp(gettype((yyvsp[0].charval)), "char"))
        {
            t->charval = (yyvsp[0].charval);
            t->doubleval = (double)(yyvsp[0].charval);
            t->intval = (int)(yyvsp[0].charval);
            st->lookup((yyval.exp_info)->loc)->init_val = t;    
        }
    }
#line 1946 "y.tab.c" /* yacc.c:1646  */
    break;

  case 6:
#line 267 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr;
            (yyval.exp_info)->p_type = PTR;
            (yyval.exp_info)->loc = st->gentemp(PTR);
            symtab_entry *se = st->lookup((yyval.exp_info)->loc);
            se->type.base_t = CHAR;
            se->type.pc = 1;
            qa.emit((yyval.exp_info)->loc, *((yyvsp[0].strval)), OPER_ASSIGN, "");
            addstr(*((yyvsp[0].strval)));
        }
#line 1961 "y.tab.c" /* yacc.c:1646  */
    break;

  case 7:
#line 278 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        	(yyval.exp_info) = (yyvsp[-1].exp_info);
        }
#line 1969 "y.tab.c" /* yacc.c:1646  */
    break;

  case 9:
#line 285 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
    	symtype t = st->lookup((yyvsp[-3].exp_info)->loc)->type;
        string f;
        if((yyvsp[-3].exp_info)->dim_arr == 0)
        {
            f = st->gentemp(INT);
            symval s; 
            s.intval = 0;
            qa.emit(f,s, "int",OPER_ASSIGN);
            (yyvsp[-3].exp_info)->temp_arr_name = new string(f);
        }
        f = *((yyvsp[-3].exp_info)->temp_arr_name);
        int prod = 1;
        for(int i = (yyvsp[-3].exp_info)->dim_arr+1 ; i < t.alist.size() ; i++)
        	prod = prod * t.alist[i];
        stringstream ss1;
        string s1;
        ss1 << prod;
        ss1 >> s1;
        string indextemp = st->gentemp();
        qa.emit(indextemp, (yyvsp[-1].exp_info)->loc, OPER_ASSIGN, "");
        qa.emit(indextemp, indextemp, OPER_MULTIPLY, s1);
        stringstream ss2;
        string s2;
        switch(t.base_t)
        {
        	case INT : ss2 << INT_SIZE;
        			   break;
        	case DOUBLE : ss2 << DOUBLE_SIZE;
        				  break;
        	case CHAR : ss2 << CHAR_SIZE;
        				break;
        	default : ss2 << PTR_SIZE;
        }
        ss2 >> s2;
        qa.emit(indextemp, indextemp, OPER_MULTIPLY, s2);
        qa.emit(f, f, OPER_PLUS, indextemp);
        int mult = t.alist[(yyvsp[-3].exp_info)->dim_arr]; 
        (yyvsp[-3].exp_info)->dim_arr++;
        (yyval.exp_info) = (yyvsp[-3].exp_info);
    }
#line 2015 "y.tab.c" /* yacc.c:1646  */
    break;

  case 10:
#line 327 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
    	(yyval.exp_info) = new exprr;
    	symtab *fsym = gst.lookup((yyvsp[-2].exp_info)->loc)->nested_symtab;
    	symtype tp = fsym->lookup("retVal")->type;
    	string temp = "";
    	if(tp.p_type != VOID)
    	{
    		if(tp.p_type != PTR && tp.p_type != ARRAY)
    		{
    			temp = st->gentemp(tp.p_type);
    		}
	    	else
	    	{
	    		temp = st->gentemp(tp.base_t);
	    		symtab_entry *se = st->lookup(temp);
	    		se->type.p_type = tp.p_type;
	    		se->type.alist = tp.alist;
	    		se->type.base_t = tp.base_t;
	    		se->type.pc = tp.pc;
	    		if(tp.pc > 0)
	    		{
	    			st->offset += PTR_SIZE - se->size;
	    			se->size = PTR_SIZE;
	    		}
	    	}
	    	qa.emit((yyvsp[-2].exp_info)->loc, "0", OPER_CALL, temp);
	    	(yyval.exp_info)->p_type = tp.p_type;
	    	(yyval.exp_info)->loc = temp;
	    }
    	else
    	{
    		symval stemp;
    		stemp.intval = 0;
    		qa.emit((yyvsp[-2].exp_info)->loc, stemp, "int", OPER_CALL);
    	}
    }
#line 2056 "y.tab.c" /* yacc.c:1646  */
    break;

  case 11:
#line 364 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
    	string fname = (yyvsp[-3].exp_info)->loc;
        symtab *fsym = gst.lookup(fname)->nested_symtab;
        symtype tp = fsym->lookup("retVal")->type;
        primtype rettype = fsym->lookup("retVal")->type.p_type;
        vector<param*> arglist = *((yyvsp[-1].prm_list));
        vector<symtab_entry*> paramlist = fsym->ord_sym;
        
        int i = 0;
        bool many = false;
        
        while(i < arglist.size())
        {
            if(paramlist[i]->name == "retVal")
            {
                many = true;
            }
            if(arglist[i]->type.p_type != paramlist[i]->type.p_type)
            {
                if(paramlist[i]->type.p_type == PTR || paramlist[i]->type.p_type == ARRAY)
                {
                	yyerror("syntax error");
                }
                else
                {
                	// st->offset += st->lookup(t)->size;
                }
                string t = st->gentemp(paramlist[i]->type.p_type);
                qa.conv2type(t,paramlist[i]->type.p_type,arglist[i]->name,arglist[i]->type.p_type);
                arglist[i]->name = t;
            }
            qa.emit(arglist[i]->name,"",OPER_PARAM,"");
            i++;
        }
        if(rettype == VOID)
        {
        	symval stemp;
        	stemp.intval = (int)arglist.size();
        	qa.emit(fname, stemp, "int", OPER_CALL);
        }
        else
        {
        	stringstream ss;
        	string temp = "";
        	if(rettype == PTR || rettype == ARRAY)
        	{
        		temp = st->gentemp(tp.base_t);
        		symtab_entry *se = st->lookup(temp);
        		se->type.base_t = tp.base_t;
        		se->type.p_type = rettype;
        		se->type.pc = tp.pc;
        		se->type.alist = tp.alist;
        		if(rettype == PTR)
        		{
        			st->offset += PTR_SIZE - se->size;
        			se->size = PTR_SIZE;
        		}
        		if(rettype == ARRAY)
        		{
        			int sz = 1;
        			for(int i = 0 ; i < tp.alist.size() ; i++)
        				sz *= tp.alist[i];
        			sz = sz * se->size;
        			se->size = sz;
        			st->offset += se->size;
        		}
        	}
        	else
        	{
        		temp = st->gentemp(tp.p_type);
        	}
        	
        	ss << arglist.size();
        	string k;
        	ss >> k;
        	qa.emit(fname, k, OPER_CALL, temp);
        	(yyval.exp_info) = new exprr;
        	(yyval.exp_info)->loc = temp;
        	(yyval.exp_info)->p_type = rettype; 
        }
    }
#line 2142 "y.tab.c" /* yacc.c:1646  */
    break;

  case 14:
#line 448 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr;
        symtab_entry *etemp = st->lookup((yyvsp[-1].exp_info)->loc);
        string temp;
        if((yyvsp[-1].exp_info)->p_type == ARRAY)
        {
        	(yyval.exp_info)->p_type = etemp->type.base_t;
        	temp = st->gentemp(etemp->type.base_t);
        	qa.emit(temp, (yyvsp[-1].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[-1].exp_info)->temp_arr_name));
        	(yyval.exp_info)->loc = st->gentemp(etemp->type.base_t);
        }
        else if((yyvsp[-1].exp_info)->p_type == PTR)
        {
        	(yyval.exp_info)->p_type == (yyvsp[-1].exp_info)->p_type;
        	temp = (yyvsp[-1].exp_info)->loc;
        	(yyval.exp_info)->loc = st->gentemp(etemp->type.base_t);
        	symtab_entry *se = st->lookup((yyval.exp_info)->loc);
        	symtype tp = st->lookup((yyvsp[-1].exp_info)->loc)->type;
        	se->type.base_t = tp.base_t;
        	se->type.p_type = tp.p_type;
        	se->type.alist = tp.alist;
        	se->type.pc = tp.pc;
        	st->offset += PTR_SIZE - se->size;
        	se->size = PTR_SIZE;
        }
        else
        {
        	(yyval.exp_info)->p_type == (yyvsp[-1].exp_info)->p_type;
        	temp = (yyvsp[-1].exp_info)->loc;
        	(yyval.exp_info)->loc = st->gentemp(etemp->type.p_type);
        }
        
        qa.emit((yyval.exp_info)->loc,temp,OPER_ASSIGN,""); 
	    qa.emit(temp,temp,OPER_PLUS,"1");
    }
#line 2182 "y.tab.c" /* yacc.c:1646  */
    break;

  case 15:
#line 484 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr;
        symtab_entry *etemp = st->lookup((yyvsp[-1].exp_info)->loc);
        string temp;
        if((yyvsp[-1].exp_info)->p_type == ARRAY)
        {
        	(yyval.exp_info)->p_type = etemp->type.base_t;
        	temp = st->gentemp(etemp->type.base_t);
        	qa.emit(temp, (yyvsp[-1].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[-1].exp_info)->temp_arr_name));
        	(yyval.exp_info)->loc = st->gentemp(etemp->type.base_t);
        }
        else if((yyvsp[-1].exp_info)->p_type == PTR)
        {
        	(yyval.exp_info)->p_type == (yyvsp[-1].exp_info)->p_type;
        	temp = (yyvsp[-1].exp_info)->loc;
        	(yyval.exp_info)->loc = st->gentemp(etemp->type.base_t);
        	symtab_entry *se = st->lookup((yyval.exp_info)->loc);
        	symtype tp = st->lookup((yyvsp[-1].exp_info)->loc)->type;
        	se->type.base_t = tp.base_t;
        	se->type.p_type = tp.p_type;
        	se->type.alist = tp.alist;
        	se->type.pc = tp.pc;
        	st->offset += PTR_SIZE - se->size;
        	se->size = PTR_SIZE;
        }
        else
        {
        	(yyval.exp_info)->p_type == (yyvsp[-1].exp_info)->p_type;
        	temp = (yyvsp[-1].exp_info)->loc;
        	(yyval.exp_info)->loc = st->gentemp(etemp->type.p_type);
        }

        qa.emit((yyval.exp_info)->loc,temp,OPER_ASSIGN,"");
	    qa.emit(temp,temp,OPER_MINUS,"1");
    }
#line 2222 "y.tab.c" /* yacc.c:1646  */
    break;

  case 16:
#line 520 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2230 "y.tab.c" /* yacc.c:1646  */
    break;

  case 17:
#line 524 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2238 "y.tab.c" /* yacc.c:1646  */
    break;

  case 18:
#line 531 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            param *t = new param; 
            t->name = (yyvsp[0].exp_info)->loc; 
            t->type = st->lookup(t->name)->type; 
            (yyval.prm_list) = new vector<param*>; 
            (yyval.prm_list)->push_back(t);
        }
#line 2250 "y.tab.c" /* yacc.c:1646  */
    break;

  case 19:
#line 539 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            param *t = new param; 
            t->name = (yyvsp[0].exp_info)->loc; 
            t->type = st->lookup(t->name)->type; 
            (yyval.prm_list) = (yyvsp[-2].prm_list); 
            (yyval.prm_list)->push_back(t);
        }
#line 2262 "y.tab.c" /* yacc.c:1646  */
    break;

  case 21:
#line 551 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
    	(yyval.exp_info) = new exprr;
    	string temp;
    	symtype tp = st->lookup((yyvsp[0].exp_info)->loc)->type;
    	if(tp.p_type == ARRAY)
    	{
    		(yyval.exp_info)->p_type = tp.base_t;
    		temp = st->gentemp(tp.base_t);
    		qa.emit(temp, (yyvsp[0].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[0].exp_info)->temp_arr_name));
    		(yyval.exp_info)->loc = st->gentemp(st->lookup((yyvsp[0].exp_info)->loc)->type.base_t);
    	}
    	else
    	{
    		(yyval.exp_info)->p_type = (yyvsp[0].exp_info)->p_type;
    		temp = (yyvsp[0].exp_info)->loc;
    		(yyval.exp_info)->loc = st->gentemp(tp.p_type);
    		if(tp.p_type == PTR)
    		{
    			symtab_entry *se = st->lookup((yyval.exp_info)->loc);
    			se->type.base_t = tp.base_t;
    			se->type.alist = tp.alist;
    			se->type.pc = tp.pc;
    		}
    	}
        qa.emit(temp,temp,OPER_PLUS,"1"); 
         
        qa.emit((yyval.exp_info)->loc,temp,OPER_ASSIGN,""); 
        
    }
#line 2296 "y.tab.c" /* yacc.c:1646  */
    break;

  case 22:
#line 581 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        
        string temp;
    	symtype tp = st->lookup((yyvsp[0].exp_info)->loc)->type;
    	if(tp.p_type == ARRAY)
    	{
    		(yyval.exp_info)->p_type = tp.base_t;
    		temp = st->gentemp(tp.base_t);
    		qa.emit(temp, (yyvsp[0].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[0].exp_info)->temp_arr_name));
    		(yyval.exp_info)->loc = st->gentemp(st->lookup((yyvsp[0].exp_info)->loc)->type.base_t);
    	}
    	else
    	{
    		(yyval.exp_info)->p_type = (yyvsp[0].exp_info)->p_type;
    		temp = (yyvsp[0].exp_info)->loc;
    		(yyval.exp_info)->loc = st->gentemp(tp.p_type);
    		if(tp.p_type == PTR)
    		{
    			symtab_entry *se = st->lookup((yyval.exp_info)->loc);
    			se->type.base_t = tp.base_t;
    			se->type.alist = tp.alist;
    			se->type.pc = tp.pc;
    		}
    	}
        qa.emit(temp,temp,OPER_MINUS,"1"); 
        qa.emit((yyval.exp_info)->loc,temp,OPER_ASSIGN,""); 
    }
#line 2329 "y.tab.c" /* yacc.c:1646  */
    break;

  case 23:
#line 610 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
    	if(!((yyvsp[-1].opp) == OPER_PLUS))
    	{
    		(yyval.exp_info) = new exprr;
    		symtype tp = st->lookup((yyvsp[0].exp_info)->loc)->type; 
	        if((yyvsp[-1].opp) == OPER_REF)
	        {
	        	(yyval.exp_info)->loc = st->gentemp(PTR);
	        	symtab_entry *se = st->lookup((yyval.exp_info)->loc);
            	
	        	(yyval.exp_info)->p_type = PTR;
	        	if((yyvsp[0].exp_info)->p_type == PTR)
	        	{
	        		se->type.pc = tp.pc + 1;
	        		se->type.base_t = tp.base_t;
	        	}
	        	else
	        	{
	        		se->type.pc = 1;
	        		se->type.base_t = tp.p_type;
	        	}
	        }
	        else if((yyvsp[-1].opp) == OPER_DE_REF)
	        {
	        	if(tp.p_type == PTR)
	        	{
	        		if(tp.pc == 1)
	        		{
	        			(yyval.exp_info)->loc = st->gentemp(tp.base_t);
	        			(yyval.exp_info)->p_type = tp.base_t;
	        		}
	        		else
	        		{
	        			(yyval.exp_info)->loc = st->gentemp(PTR);
	        			(yyval.exp_info)->p_type = PTR;
	        		}
	        		symtab_entry *se = st->lookup((yyval.exp_info)->loc);
	        		se->type.pc = tp.pc - 1;
	        		se->type.base_t = tp.base_t;
	        	}
	        	else
	        	{
	        		// throw error
	        	}
	        }
	        else
	        {
	        	(yyval.exp_info)->loc = st->gentemp((yyvsp[0].exp_info)->p_type);
	        	symtab_entry *se = st->lookup((yyval.exp_info)->loc);
	        	(yyval.exp_info)->p_type = (yyvsp[0].exp_info)->p_type;
	        	se->type.base_t = tp.base_t;
	        	se->type.pc = tp.pc;
	        }
	        qa.emit((yyval.exp_info)->loc, (yyvsp[0].exp_info)->loc, (yyvsp[-1].opp), "");
            /*
            stringstream ss;
            char ch;
            switch($1)
            {
                case OPER_REF : ch = '&'; break;
                case OPER_DE_REF : ch = '*'; break;
                case OPER_UMINUS : ch = '-'; break;
                case OPER_COMPLEMENT : ch = '!'; break;
                case OPER_BW_NOT : ch = '~'; break;
            }
            ss << ch << $2->loc;
            ss >> $$->loc;
	        */
        }
    	else
    	{
    		(yyval.exp_info) = (yyvsp[0].exp_info);
    	}
    	
    }
#line 2409 "y.tab.c" /* yacc.c:1646  */
    break;

  case 24:
#line 686 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // sizeof operator not considered as per the assignment 
        }
#line 2417 "y.tab.c" /* yacc.c:1646  */
    break;

  case 25:
#line 690 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // sizeof operator not considered as per the assignment    
        }
#line 2425 "y.tab.c" /* yacc.c:1646  */
    break;

  case 26:
#line 697 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.opp) = OPER_REF;
        }
#line 2433 "y.tab.c" /* yacc.c:1646  */
    break;

  case 27:
#line 701 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.opp) = OPER_DE_REF;
        }
#line 2441 "y.tab.c" /* yacc.c:1646  */
    break;

  case 28:
#line 705 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.opp) = OPER_UPLUS;
        }
#line 2449 "y.tab.c" /* yacc.c:1646  */
    break;

  case 29:
#line 709 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.opp) = OPER_UMINUS;
        }
#line 2457 "y.tab.c" /* yacc.c:1646  */
    break;

  case 30:
#line 713 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.opp) = OPER_COMPLEMENT;
        }
#line 2465 "y.tab.c" /* yacc.c:1646  */
    break;

  case 31:
#line 717 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.opp) = OPER_BW_NOT;
        }
#line 2473 "y.tab.c" /* yacc.c:1646  */
    break;

  case 33:
#line 725 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 2481 "y.tab.c" /* yacc.c:1646  */
    break;

  case 34:
#line 732 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
	    	(yyval.exp_info) = (yyvsp[0].exp_info);
	    	if((yyvsp[0].exp_info)->loc != "")
	    	{
        		symtype tp = st->lookup((yyvsp[0].exp_info)->loc)->type;
		    	if(tp.p_type == ARRAY)
		    	{
            		string stemp = st->gentemp(tp.base_t);
		    		qa.emit(stemp, (yyvsp[0].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[0].exp_info)->temp_arr_name));
		    		(yyvsp[0].exp_info)->loc = stemp;
		    		(yyvsp[0].exp_info)->p_type = tp.base_t;
		    	}	
		    		
	    	}
	    }
#line 2501 "y.tab.c" /* yacc.c:1646  */
    break;

  case 35:
#line 748 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        symtype tp = st->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(tp.p_type == ARRAY)
        {
        	(yyvsp[-2].exp_info)->p_type = tp.base_t;
        	string temp = st->gentemp(tp.base_t);
        	qa.emit(temp, (yyvsp[-2].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[-2].exp_info)->temp_arr_name));
        	(yyvsp[-2].exp_info)->loc = temp;
        }
        tp = st->lookup((yyvsp[0].exp_info)->loc)->type;
        if(tp.p_type == ARRAY)
        {
        	(yyvsp[0].exp_info)->p_type = tp.base_t;
        	string temp = st->gentemp(tp.base_t);
        	qa.emit(temp, (yyvsp[0].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[0].exp_info)->temp_arr_name));
        	(yyvsp[0].exp_info)->loc = temp;
        }
        (yyval.exp_info) = new exprr; 
        primtype final_type = max(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type, st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);      // assigned types in enum based on their safe type-casting conditions
        (yyval.exp_info)->loc = st->gentemp(final_type); 
        (yyval.exp_info)->p_type = final_type;                                
        if(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[-2].exp_info)->loc,st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type);
            (yyvsp[-2].exp_info)->loc = t;
        }
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            (yyvsp[0].exp_info)->loc = t;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_MULTIPLY,(yyvsp[0].exp_info)->loc);
    }
#line 2541 "y.tab.c" /* yacc.c:1646  */
    break;

  case 36:
#line 784 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
    	symtype tp = st->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(tp.p_type == ARRAY)
        {
        	(yyvsp[-2].exp_info)->p_type = tp.base_t;
        	string temp = st->gentemp(tp.base_t);
        	qa.emit(temp, (yyvsp[-2].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[-2].exp_info)->temp_arr_name));
        	(yyvsp[-2].exp_info)->loc = temp;
        }
        tp = st->lookup((yyvsp[0].exp_info)->loc)->type;
        if(tp.p_type == ARRAY)
        {
        	(yyvsp[0].exp_info)->p_type = tp.base_t;
        	string temp = st->gentemp(tp.base_t);
        	qa.emit(temp, (yyvsp[0].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[0].exp_info)->temp_arr_name));
        	(yyvsp[0].exp_info)->loc = temp;
        }
        (yyval.exp_info) = new exprr; 
        primtype final_type = max(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type, st->lookup((yyvsp[0].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->loc = st->gentemp(final_type); 
        (yyval.exp_info)->p_type = final_type;
        if(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[-2].exp_info)->loc,st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type);
            (yyvsp[-2].exp_info)->loc = t;
        }
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            (yyvsp[0].exp_info)->loc = t;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_DIVIDE,(yyvsp[0].exp_info)->loc);
    }
#line 2581 "y.tab.c" /* yacc.c:1646  */
    break;

  case 37:
#line 820 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
    	symtype tp = st->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(tp.p_type == ARRAY)
        {
        	(yyvsp[-2].exp_info)->p_type = tp.base_t;
        	string temp = st->gentemp(tp.base_t);
        	qa.emit(temp, (yyvsp[-2].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[-2].exp_info)->temp_arr_name));
        	(yyvsp[-2].exp_info)->loc = temp;
        }
        tp = st->lookup((yyvsp[0].exp_info)->loc)->type;
        if(tp.p_type == ARRAY)
        {
        	(yyvsp[0].exp_info)->p_type = tp.base_t;
        	string temp = st->gentemp(tp.base_t);
        	qa.emit(temp, (yyvsp[0].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[0].exp_info)->temp_arr_name));
        	(yyvsp[0].exp_info)->loc = temp;
        }
        (yyval.exp_info) = new exprr; 
        primtype final_type = max(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type, st->lookup((yyvsp[0].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->loc = st->gentemp(final_type); 
        (yyval.exp_info)->p_type = final_type;
        if(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[-2].exp_info)->loc,st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type);
            (yyvsp[-2].exp_info)->loc = t;
        }
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            (yyvsp[0].exp_info)->loc = t;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_MODULUS,(yyvsp[0].exp_info)->loc);
    }
#line 2621 "y.tab.c" /* yacc.c:1646  */
    break;

  case 39:
#line 860 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
    	symtype tp = st->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(tp.p_type == ARRAY)
        {
        	(yyvsp[-2].exp_info)->p_type = tp.base_t;
        	string temp = st->gentemp(tp.base_t);
        	qa.emit(temp, (yyvsp[-2].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[-2].exp_info)->temp_arr_name));
        	(yyvsp[-2].exp_info)->loc = temp;
        }
        tp = st->lookup((yyvsp[0].exp_info)->loc)->type;
        if(tp.p_type == ARRAY)
        {
        	(yyvsp[0].exp_info)->p_type = tp.base_t;
        	string temp = st->gentemp(tp.base_t);
        	qa.emit(temp, (yyvsp[0].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[0].exp_info)->temp_arr_name));
        	(yyvsp[0].exp_info)->loc = temp;
        }
        (yyval.exp_info) = new exprr; 
        primtype final_type = max(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type, st->lookup((yyvsp[0].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->loc = st->gentemp(final_type); 
        (yyval.exp_info)->p_type = final_type;
        if(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[-2].exp_info)->loc,st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type);
            (yyvsp[-2].exp_info)->loc = t;
        }
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            (yyvsp[0].exp_info)->loc = t;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_PLUS,(yyvsp[0].exp_info)->loc);
    }
#line 2661 "y.tab.c" /* yacc.c:1646  */
    break;

  case 40:
#line 896 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
    	symtype tp = st->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(tp.p_type == ARRAY)
        {
        	(yyvsp[-2].exp_info)->p_type = tp.base_t;
        	string temp = st->gentemp(tp.base_t);
        	qa.emit(temp, (yyvsp[-2].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[-2].exp_info)->temp_arr_name));
        	(yyvsp[-2].exp_info)->loc = temp;
        }
        tp = st->lookup((yyvsp[0].exp_info)->loc)->type;
        if(tp.p_type == ARRAY)
        {
        	(yyvsp[0].exp_info)->p_type = tp.base_t;
        	string temp = st->gentemp(tp.base_t);
        	qa.emit(temp, (yyvsp[0].exp_info)->loc, OPER_ARRAY_INDEX_FROM, *((yyvsp[0].exp_info)->temp_arr_name));
        	(yyvsp[0].exp_info)->loc = temp;
        }
        (yyval.exp_info) = new exprr; 
        primtype final_type = max(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type, st->lookup((yyvsp[0].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->loc = st->gentemp(final_type); 
        (yyval.exp_info)->p_type = final_type;
        if(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[-2].exp_info)->loc,st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type);
            (yyvsp[-2].exp_info)->loc = t;
        }
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            (yyvsp[0].exp_info)->loc = t;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_MINUS,(yyvsp[0].exp_info)->loc);
    }
#line 2701 "y.tab.c" /* yacc.c:1646  */
    break;

  case 42:
#line 936 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->p_type = st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type;
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != INT)
        {
            string t = st->gentemp(INT);
            qa.conv2type(t,INT,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            (yyvsp[0].exp_info)->loc = t;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_SHIFT_LEFT,(yyvsp[0].exp_info)->loc);
    }
#line 2718 "y.tab.c" /* yacc.c:1646  */
    break;

  case 43:
#line 949 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->p_type = st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type;
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != INT)
        {
            string t = st->gentemp(INT);
            qa.conv2type(t,INT,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            (yyvsp[0].exp_info)->loc = t;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_SHIFT_RIGHT,(yyvsp[0].exp_info)->loc);
    }
#line 2735 "y.tab.c" /* yacc.c:1646  */
    break;

  case 45:
#line 965 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

            (yyval.exp_info) = new exprr; 
            (yyval.exp_info)->p_type = BOOL;
            (yyval.exp_info)->truelist = makelist(qa.nextinstr); 
            qa.emit("",(yyvsp[-2].exp_info)->loc,OPER_IF_LESS,(yyvsp[0].exp_info)->loc);
            (yyval.exp_info)->falselist = makelist(qa.nextinstr); 
            qa.emit("","",OPER_GOTO,"");
        }
#line 2749 "y.tab.c" /* yacc.c:1646  */
    break;

  case 46:
#line 975 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
    	(yyval.exp_info) = new exprr; 
        (yyval.exp_info)->p_type = BOOL; 
        (yyval.exp_info)->truelist = makelist(qa.nextinstr); 
        qa.emit("",(yyvsp[-2].exp_info)->loc,OPER_IF_GREATER,(yyvsp[0].exp_info)->loc); 
        (yyval.exp_info)->falselist = makelist(qa.nextinstr); 
        qa.emit("","",OPER_GOTO,"");
    }
#line 2762 "y.tab.c" /* yacc.c:1646  */
    break;

  case 47:
#line 984 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr; 
            (yyval.exp_info)->p_type = BOOL; 
            (yyval.exp_info)->truelist = makelist(qa.nextinstr); 
            qa.emit("",(yyvsp[-2].exp_info)->loc,OPER_IF_LESS_OR_EQUAL,(yyvsp[0].exp_info)->loc); 
            (yyval.exp_info)->falselist = makelist(qa.nextinstr); 
            qa.emit("","",OPER_GOTO,"");
        }
#line 2775 "y.tab.c" /* yacc.c:1646  */
    break;

  case 48:
#line 993 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->p_type = BOOL; 
        (yyval.exp_info)->truelist = makelist(qa.nextinstr); 
        qa.emit("",(yyvsp[-2].exp_info)->loc,OPER_IF_GREATER_OR_EQUAL,(yyvsp[0].exp_info)->loc); 
        (yyval.exp_info)->falselist = makelist(qa.nextinstr); 
        qa.emit("","",OPER_GOTO,"");
    }
#line 2788 "y.tab.c" /* yacc.c:1646  */
    break;

  case 50:
#line 1005 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr; 
            (yyval.exp_info)->p_type = BOOL; 
            (yyval.exp_info)->truelist = makelist(qa.nextinstr); 
            qa.emit("",(yyvsp[-2].exp_info)->loc,OPER_IF_EQUAL,(yyvsp[0].exp_info)->loc); 
            (yyval.exp_info)->falselist = makelist(qa.nextinstr);  
            qa.emit("","",OPER_GOTO,"");
        }
#line 2801 "y.tab.c" /* yacc.c:1646  */
    break;

  case 51:
#line 1014 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->p_type = BOOL; 
        (yyval.exp_info)->truelist = makelist(qa.nextinstr); 
        qa.emit("",(yyvsp[-2].exp_info)->loc,OPER_IF_NOT_EQUAL,(yyvsp[0].exp_info)->loc); 
        (yyval.exp_info)->falselist = makelist(qa.nextinstr); 
        qa.emit("","",OPER_GOTO,"");
    }
#line 2814 "y.tab.c" /* yacc.c:1646  */
    break;

  case 53:
#line 1027 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(); 
        (yyval.exp_info)->p_type = INT;
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_BW_AND,(yyvsp[0].exp_info)->loc);
    }
#line 2825 "y.tab.c" /* yacc.c:1646  */
    break;

  case 55:
#line 1038 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr; 
            (yyval.exp_info)->loc = st->gentemp();
            (yyval.exp_info)->p_type = INT; 
            qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_BW_XOR,(yyvsp[0].exp_info)->loc);
        }
#line 2836 "y.tab.c" /* yacc.c:1646  */
    break;

  case 57:
#line 1048 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr; 
            (yyval.exp_info)->loc = st->gentemp();
            (yyval.exp_info)->p_type = INT; 
            qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_BW_OR,(yyvsp[0].exp_info)->loc);
        }
#line 2847 "y.tab.c" /* yacc.c:1646  */
    break;

  case 59:
#line 1058 "ass6_13CS30016.y" /* yacc.c:1646  */
    {       
        qa.backpatch((yyvsp[-4].exp_info)->nextlist,qa.nextinstr);
        qa.convInt2Bool((yyvsp[-5].exp_info));
        qa.backpatch((yyvsp[0].exp_info)->nextlist, qa.nextinstr);
        qa.convInt2Bool((yyvsp[-1].exp_info));
        (yyval.exp_info) = new exprr; (yyval.exp_info)->p_type = BOOL;
        qa.backpatch((yyvsp[-5].exp_info)->truelist,(yyvsp[-2].exp_info)->instr); 
        (yyval.exp_info)->falselist = merge((yyvsp[-5].exp_info)->falselist, (yyvsp[-1].exp_info)->falselist); 
        (yyval.exp_info)->truelist = (yyvsp[-1].exp_info)->truelist; 
    }
#line 2862 "y.tab.c" /* yacc.c:1646  */
    break;

  case 61:
#line 1072 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        qa.backpatch((yyvsp[-4].exp_info)->nextlist,qa.nextinstr);
        qa.convInt2Bool((yyvsp[-5].exp_info));
        qa.backpatch((yyvsp[0].exp_info)->nextlist, qa.nextinstr);
        qa.convInt2Bool((yyvsp[-1].exp_info));
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->p_type = BOOL;
        qa.backpatch((yyvsp[-5].exp_info)->falselist,(yyvsp[-2].exp_info)->instr); 
        (yyval.exp_info)->truelist = merge((yyvsp[-5].exp_info)->truelist, (yyvsp[-1].exp_info)->truelist); 
        (yyval.exp_info)->falselist = (yyvsp[-1].exp_info)->falselist; 
    }
#line 2878 "y.tab.c" /* yacc.c:1646  */
    break;

  case 63:
#line 1087 "ass6_13CS30016.y" /* yacc.c:1646  */
    { 
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(st->lookup((yyvsp[-4].exp_info)->loc)->type.p_type);
        (yyval.exp_info)->p_type = st->lookup((yyvsp[-4].exp_info)->loc)->type.p_type;
        if((yyval.exp_info)->p_type != st->lookup((yyvsp[0].exp_info)->loc)->type.p_type)
        {
        	exprr *ne = new exprr;
        	ne->loc = st->gentemp((yyval.exp_info)->p_type);
        	qa.conv2type(ne, (yyvsp[0].exp_info), (yyval.exp_info)->p_type);
        	qa.emit((yyval.exp_info)->loc,ne->loc,OPER_ASSIGN);	
        }
        else
        {
        	qa.emit((yyval.exp_info)->loc,(yyvsp[0].exp_info)->loc,OPER_ASSIGN);
        }
        
        list<int> I = makelist(qa.nextinstr);
        qa.emit("","",OPER_GOTO,"");
        qa.backpatch((yyvsp[-3].exp_info)->nextlist,qa.nextinstr);
        qa.emit((yyval.exp_info)->loc,(yyvsp[-4].exp_info)->loc, OPER_ASSIGN);
        I = merge(I,makelist(qa.nextinstr));
        qa.emit("","",OPER_GOTO,"");
        qa.backpatch((yyvsp[-7].exp_info)->nextlist, qa.nextinstr);
        qa.convInt2Bool((yyvsp[-8].exp_info));  
        qa.backpatch((yyvsp[-8].exp_info)->truelist,(yyvsp[-5].exp_info)->instr);
        qa.backpatch((yyvsp[-8].exp_info)->falselist,(yyvsp[-1].exp_info)->instr);
        qa.backpatch(I,qa.nextinstr);
    }
#line 2911 "y.tab.c" /* yacc.c:1646  */
    break;

  case 65:
#line 1120 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

    	symtype t1 =  st->lookup((yyvsp[-2].exp_info)->loc)->type;
        symtype t3 = st->lookup((yyvsp[0].exp_info)->loc)->type;
    	
        if(t3.p_type == ARRAY)
        {

            string t = st->gentemp(t3.base_t);
            qa.emit(t,(yyvsp[0].exp_info)->loc,OPER_ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->temp_arr_name));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->p_type = t3.base_t;
        }
        
        if((t1.p_type == ARRAY && t1.base_t != (yyvsp[0].exp_info)->p_type) )
        {

            string t = st->gentemp(t1.base_t);
            qa.conv2type(t,t1.base_t,(yyvsp[0].exp_info)->loc,(yyvsp[0].exp_info)->p_type);
            (yyvsp[0].exp_info)->loc = t; 
        } 
        else if(t1.p_type != ARRAY && t1.p_type != (yyvsp[0].exp_info)->p_type)
        {
            string t = st->gentemp(t1.p_type);
            qa.conv2type(t,t1.p_type,(yyvsp[0].exp_info)->loc,(yyvsp[0].exp_info)->p_type);
            (yyvsp[0].exp_info)->loc = t;
        }
        if(t1.p_type == ARRAY)
        {
            qa.emit((yyvsp[-2].exp_info)->loc,(yyvsp[0].exp_info)->loc, OPER_ARRAY_INDEX_TO,*((yyvsp[-2].exp_info)->temp_arr_name));
        }
        /*
        else if(t1.p_type == PTR)
        {
            qa.emit($1->loc, $3->loc, OPER_POINTER_ASSIGNMENT, "");
            if(t1.pc == 1)
                $1->p_type = t1.base_t;
        }
        */
        else
        { 
            if((yyval.exp_info)->loc[0] == '*')
                qa.emit((yyval.exp_info)->loc, (yyvsp[0].exp_info)->loc, OPER_POINTER_ASSIGNMENT, "");
            else
                qa.emit((yyvsp[-2].exp_info)->loc, (yyvsp[0].exp_info)->loc,OPER_ASSIGN,"");
        }
        (yyval.exp_info) = (yyvsp[-2].exp_info);
    }
#line 2964 "y.tab.c" /* yacc.c:1646  */
    break;

  case 80:
#line 1200 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.dec_info) = (yyvsp[0].dec_info);
        primtype tn = (yyvsp[-1].p_type);
        declr *my_dec = (yyvsp[0].dec_info);
        
        symtab_entry *var = gst.lookup(my_dec->name);
        if(my_dec->p_type == FUNCTION) 
        {
            symtab_entry *retval = var->nested_symtab->lookup("retVal",my_dec->pc, tn);
            retval->type.alist = (yyvsp[0].dec_info)->alist;
        }
    }
#line 2981 "y.tab.c" /* yacc.c:1646  */
    break;

  case 82:
#line 1216 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        primtype type_now = (yyvsp[-2].p_type);
        int size_now = -1;
        if(type_now == CHAR) size_now = CHAR_SIZE;
        if(type_now == INT)  size_now = INT_SIZE;
        if(type_now == DOUBLE)  size_now = DOUBLE_SIZE;
        if(type_now == PTR) size_now = PTR_SIZE;
        if(type_now == VOID) size_now = 0;
        if(type_now == FUNCTION) size_now = 0;
        vector<declr*> lst = *((yyvsp[-1].ldec));
        for(vector<declr*>::iterator it = lst.begin(); it != lst.end(); it++)
        {
           declr *my_dec = *it;
            if(my_dec->p_type == FUNCTION)
            {
                st = &(gst);                // transfer control back to the global symbol table
                symtab_entry *var = st->lookup(my_dec->name);
                symtab_entry *retval = var->nested_symtab->lookup("retVal",my_dec->pc, type_now);
                var->init_val = NULL;
                continue;
            }
            symtab_entry *var = st->lookup(my_dec->name,0,type_now);
            var->nested_symtab = NULL;
            if(my_dec->alist == vector<int>() && my_dec->pc == 0) 
            {
                var->type.p_type = type_now;
        
                var->size = size_now;
                if(my_dec->init_val != NULL)
                {
                    string rval = my_dec->init_val->loc;
                    qa.emit(var->name, rval,OPER_ASSIGN,"");
                    var->init_val = st->lookup(rval)->init_val;
                }
                else
                    var->init_val = NULL;
            }
            else if(my_dec->alist!=vector<int>())  
            {
                var->type.p_type = ARRAY;
                var->type.base_t = type_now;
                var->type.alist = my_dec->alist;
                
                int sz = size_now; 
                vector<int> tmp = var->type.alist; 
                int tsz = tmp.size();
                for(int i = 0; i<tsz; i++) 
                	sz *= tmp[i];
                st->offset += sz - var->size;
                var->size = sz;
            }
            else if(my_dec->pc != 0)
            {
                var->type.p_type = PTR;
                var->type.base_t = type_now;
                var->type.pc = my_dec->pc;
                st->offset += (PTR_SIZE-var->size);
                var->size = PTR_SIZE;
                if(my_dec->init_val != NULL)
                {
                    string rval = my_dec->init_val->loc;
                    qa.emit(var->name, rval, OPER_ASSIGN, "");
                    var->init_val = st->lookup(rval)->init_val;
                }
                else
                    var->init_val = NULL;
            }
        }  
    }
#line 3055 "y.tab.c" /* yacc.c:1646  */
    break;

  case 83:
#line 1289 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3063 "y.tab.c" /* yacc.c:1646  */
    break;

  case 84:
#line 1293 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3071 "y.tab.c" /* yacc.c:1646  */
    break;

  case 87:
#line 1299 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3079 "y.tab.c" /* yacc.c:1646  */
    break;

  case 88:
#line 1303 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3087 "y.tab.c" /* yacc.c:1646  */
    break;

  case 89:
#line 1307 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3095 "y.tab.c" /* yacc.c:1646  */
    break;

  case 90:
#line 1311 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3103 "y.tab.c" /* yacc.c:1646  */
    break;

  case 91:
#line 1319 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.ldec) = new vector<declr*>; 
            (yyval.ldec)->push_back((yyvsp[0].dec_info));
        }
#line 3112 "y.tab.c" /* yacc.c:1646  */
    break;

  case 92:
#line 1324 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyvsp[-2].ldec)->push_back((yyvsp[0].dec_info)); 
            (yyval.ldec) = (yyvsp[-2].ldec);
        }
#line 3121 "y.tab.c" /* yacc.c:1646  */
    break;

  case 93:
#line 1333 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.dec_info) = (yyvsp[0].dec_info); 
            (yyval.dec_info)->init_val = NULL;
        }
#line 3130 "y.tab.c" /* yacc.c:1646  */
    break;

  case 94:
#line 1338 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.dec_info) = (yyvsp[-2].dec_info);
           (yyval.dec_info)->init_val = (yyvsp[0].exp_info);
        }
#line 3139 "y.tab.c" /* yacc.c:1646  */
    break;

  case 99:
#line 1352 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.p_type) = VOID;
        }
#line 3147 "y.tab.c" /* yacc.c:1646  */
    break;

  case 100:
#line 1356 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.p_type) = CHAR;
        }
#line 3155 "y.tab.c" /* yacc.c:1646  */
    break;

  case 101:
#line 1360 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3163 "y.tab.c" /* yacc.c:1646  */
    break;

  case 102:
#line 1364 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.p_type) = INT;
        }
#line 3171 "y.tab.c" /* yacc.c:1646  */
    break;

  case 103:
#line 1368 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3179 "y.tab.c" /* yacc.c:1646  */
    break;

  case 104:
#line 1372 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3187 "y.tab.c" /* yacc.c:1646  */
    break;

  case 105:
#line 1376 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.p_type) = DOUBLE;
        }
#line 3195 "y.tab.c" /* yacc.c:1646  */
    break;

  case 106:
#line 1380 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3203 "y.tab.c" /* yacc.c:1646  */
    break;

  case 107:
#line 1384 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3211 "y.tab.c" /* yacc.c:1646  */
    break;

  case 108:
#line 1388 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3219 "y.tab.c" /* yacc.c:1646  */
    break;

  case 109:
#line 1392 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3227 "y.tab.c" /* yacc.c:1646  */
    break;

  case 110:
#line 1396 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3235 "y.tab.c" /* yacc.c:1646  */
    break;

  case 111:
#line 1400 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3243 "y.tab.c" /* yacc.c:1646  */
    break;

  case 130:
#line 1438 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.dec_info) = (yyvsp[0].dec_info); 
            (yyval.dec_info)->pc = (yyvsp[-1].intval);
        }
#line 3252 "y.tab.c" /* yacc.c:1646  */
    break;

  case 131:
#line 1443 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.dec_info) = (yyvsp[0].dec_info); 
            (yyval.dec_info)->pc = 0;
        }
#line 3261 "y.tab.c" /* yacc.c:1646  */
    break;

  case 132:
#line 1452 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.dec_info) = new declr; 
            (yyval.dec_info)->name = *((yyvsp[0].strval));
        }
#line 3270 "y.tab.c" /* yacc.c:1646  */
    break;

  case 133:
#line 1457 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3278 "y.tab.c" /* yacc.c:1646  */
    break;

  case 134:
#line 1461 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.dec_info) = (yyvsp[-4].dec_info); 
        int idx = st->lookup((yyvsp[-1].exp_info)->loc)->init_val->intval;
        (yyval.dec_info)->alist.push_back(idx);
    }
#line 3288 "y.tab.c" /* yacc.c:1646  */
    break;

  case 138:
#line 1470 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.dec_info) = (yyvsp[-3].dec_info);                                        // default bison operation
        (yyval.dec_info)->p_type = FUNCTION;
        symtab_entry *fdata = st->lookup((yyval.dec_info)->name,0,(yyval.dec_info)->p_type);
        symtab *fsym = new symtab();
        fdata->nested_symtab = fsym;
        qa.emit("", (yyvsp[-3].dec_info)->name, OPER_FUNCT_BEGIN);
        vector<param*> plist = *((yyvsp[-1].prm_list));
        for(int i = 0;i<plist.size(); i++)
        {
            param *my_prm = plist[i];
            symtab_entry *var = fsym->lookup(my_prm->name,0,my_prm->type.p_type);
            int sz = -1;
            switch(my_prm->type.base_t)
            {
            	case INT : sz = INT_SIZE; break;
            	case DOUBLE : sz = DOUBLE_SIZE; break;
            	case CHAR : sz = CHAR_SIZE; break;
            	default : sz = 4;
            }
            if(my_prm->type.p_type == ARRAY)
            {
            	var->type.p_type = ARRAY;
                var->type.base_t = my_prm->type.base_t;
                var->type.alist = my_prm->type.alist;
                var->offset = fsym->offset;
              
                vector<int> tmp = var->type.alist; int tsz = tmp.size();
                for(int i = 0; i<tsz; i++) 
                	sz *= tmp[i];
                fsym->offset += sz - var->size;
                var->size = sz;
            }
            else if(my_prm->type.p_type == PTR)
            {
            	var->type.p_type = PTR;
                var->type.base_t = my_prm->type.base_t;
                var->type.alist = my_prm->type.alist;
                var->type.pc = my_prm->type.pc;
            }
            else
            {
            	var->type.p_type = my_prm->type.p_type;
                var->init_val = NULL;
            }
        }
        st = fsym;
    }
#line 3341 "y.tab.c" /* yacc.c:1646  */
    break;

  case 143:
#line 1528 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->p_type = none;
    }
#line 3350 "y.tab.c" /* yacc.c:1646  */
    break;

  case 144:
#line 1536 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.intval) = 1;
        }
#line 3358 "y.tab.c" /* yacc.c:1646  */
    break;

  case 145:
#line 1540 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3366 "y.tab.c" /* yacc.c:1646  */
    break;

  case 146:
#line 1544 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.intval) = 1 + (yyvsp[0].intval);
        }
#line 3374 "y.tab.c" /* yacc.c:1646  */
    break;

  case 147:
#line 1548 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3382 "y.tab.c" /* yacc.c:1646  */
    break;

  case 151:
#line 1559 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.prm_list) = new vector<param*>;
        }
#line 3390 "y.tab.c" /* yacc.c:1646  */
    break;

  case 154:
#line 1569 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.prm_list) = new vector<param*>; 
            (yyval.prm_list)->push_back((yyvsp[0].prm));
        }
#line 3399 "y.tab.c" /* yacc.c:1646  */
    break;

  case 155:
#line 1574 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyvsp[-2].prm_list)->push_back((yyvsp[0].prm)); 
            (yyval.prm_list) = (yyvsp[-2].prm_list);
        }
#line 3408 "y.tab.c" /* yacc.c:1646  */
    break;

  case 156:
#line 1581 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.prm) = new param; 
            (yyval.prm)->name = (yyvsp[0].dec_info)->name; 
            (yyval.prm)->type.base_t = (yyvsp[-1].p_type);
            (yyval.prm)->type.pc = (yyvsp[0].dec_info)->pc;
            (yyval.prm)->type.alist = (yyvsp[0].dec_info)->alist;
            if((yyvsp[0].dec_info)->alist.size() != 0)
            {
            	(yyval.prm)->type.p_type = ARRAY;
            }
            else if((yyvsp[0].dec_info)->pc != 0)
            {
            	(yyval.prm)->type.p_type = PTR;
            }
            else
            {
            	(yyval.prm)->type.p_type = (yyvsp[-1].p_type);
            }
        }
#line 3432 "y.tab.c" /* yacc.c:1646  */
    break;

  case 157:
#line 1601 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3440 "y.tab.c" /* yacc.c:1646  */
    break;

  case 161:
#line 1617 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = (yyvsp[0].exp_info);
        }
#line 3448 "y.tab.c" /* yacc.c:1646  */
    break;

  case 162:
#line 1621 "ass6_13CS30016.y" /* yacc.c:1646  */
    {  
            // not used
        }
#line 3456 "y.tab.c" /* yacc.c:1646  */
    break;

  case 163:
#line 1625 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3464 "y.tab.c" /* yacc.c:1646  */
    break;

  case 164:
#line 1632 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3472 "y.tab.c" /* yacc.c:1646  */
    break;

  case 165:
#line 1636 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3480 "y.tab.c" /* yacc.c:1646  */
    break;

  case 166:
#line 1640 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3488 "y.tab.c" /* yacc.c:1646  */
    break;

  case 167:
#line 1644 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3496 "y.tab.c" /* yacc.c:1646  */
    break;

  case 179:
#line 1675 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3504 "y.tab.c" /* yacc.c:1646  */
    break;

  case 180:
#line 1679 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3512 "y.tab.c" /* yacc.c:1646  */
    break;

  case 181:
#line 1683 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3520 "y.tab.c" /* yacc.c:1646  */
    break;

  case 182:
#line 1690 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = (yyvsp[-1].exp_info);
    }
#line 3528 "y.tab.c" /* yacc.c:1646  */
    break;

  case 183:
#line 1694 "ass6_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3536 "y.tab.c" /* yacc.c:1646  */
    break;

  case 184:
#line 1701 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = (yyvsp[0].exp_info); 
            qa.backpatch((yyvsp[0].exp_info)->nextlist, qa.nextinstr);
        }
#line 3545 "y.tab.c" /* yacc.c:1646  */
    break;

  case 185:
#line 1706 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr;
        qa.backpatch((yyvsp[-2].exp_info)->nextlist, (yyvsp[-1].exp_info)->instr);
        (yyval.exp_info)->nextlist = (yyvsp[0].exp_info)->nextlist;
        (yyval.exp_info)->p_type = (yyvsp[0].exp_info)->p_type;
    }
#line 3556 "y.tab.c" /* yacc.c:1646  */
    break;

  case 186:
#line 1715 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr;
        }
#line 3564 "y.tab.c" /* yacc.c:1646  */
    break;

  case 188:
#line 1722 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr;
            (yyval.exp_info)->p_type = none;
        }
#line 3573 "y.tab.c" /* yacc.c:1646  */
    break;

  case 191:
#line 1731 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr;
            (yyval.exp_info)->p_type = none;
        }
#line 3582 "y.tab.c" /* yacc.c:1646  */
    break;

  case 192:
#line 1738 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        qa.backpatch((yyvsp[-8].exp_info)->nextlist,qa.nextinstr);
        qa.convInt2Bool((yyvsp[-9].exp_info));
        qa.backpatch((yyvsp[-9].exp_info)->truelist,(yyvsp[-6].exp_info)->instr);
        qa.backpatch((yyvsp[-9].exp_info)->falselist,(yyvsp[-2].exp_info)->instr);
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->nextlist = merge((yyvsp[-5].exp_info)->nextlist,(yyvsp[-4].exp_info)->nextlist);        
        (yyval.exp_info)->nextlist = merge((yyval.exp_info)->nextlist,(yyvsp[-1].exp_info)->nextlist);   
        (yyval.exp_info)->nextlist = merge((yyval.exp_info)->nextlist,(yyvsp[0].exp_info)->nextlist);           
    }
#line 3597 "y.tab.c" /* yacc.c:1646  */
    break;

  case 193:
#line 1749 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        qa.backpatch((yyvsp[-4].exp_info)->nextlist,qa.nextinstr);
        qa.convInt2Bool((yyvsp[-5].exp_info));
        qa.backpatch((yyvsp[-5].exp_info)->truelist,(yyvsp[-2].exp_info)->instr);
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->nextlist = merge((yyvsp[-1].exp_info)->nextlist,(yyvsp[0].exp_info)->nextlist);        
        (yyval.exp_info)->nextlist = merge((yyval.exp_info)->nextlist,(yyvsp[-5].exp_info)->falselist);           
    }
#line 3610 "y.tab.c" /* yacc.c:1646  */
    break;

  case 194:
#line 1759 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3618 "y.tab.c" /* yacc.c:1646  */
    break;

  case 195:
#line 1765 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        qa.emit("","",OPER_GOTO,"");
        qa.backpatch(makelist(qa.nextinstr-1),(yyvsp[-6].exp_info)->instr);    
        qa.backpatch((yyvsp[-3].exp_info)->nextlist,qa.nextinstr);
        qa.convInt2Bool((yyvsp[-4].exp_info));
        qa.backpatch((yyvsp[-4].exp_info)->truelist,(yyvsp[-1].exp_info)->instr);
        qa.backpatch((yyvsp[0].exp_info)->nextlist,(yyvsp[-6].exp_info)->instr);    
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->nextlist = (yyvsp[-4].exp_info)->falselist;        
    }
#line 3633 "y.tab.c" /* yacc.c:1646  */
    break;

  case 196:
#line 1776 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        qa.convInt2Bool((yyvsp[-2].exp_info));
        qa.backpatch((yyvsp[-2].exp_info)->truelist,(yyvsp[-7].exp_info)->instr);
        qa.backpatch((yyvsp[-6].exp_info)->nextlist,(yyvsp[-5].exp_info)->instr);
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->nextlist = (yyvsp[-2].exp_info)->falselist;
    }
#line 3645 "y.tab.c" /* yacc.c:1646  */
    break;

  case 197:
#line 1784 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
    	stringstream ss1;
    	ss1 << (yyvsp[-5].exp_info)->instr;
    	string s1;
    	ss1 >> s1;
    	qa.emit(s1,"",OPER_GOTO,"");
        qa.backpatch((yyvsp[0].exp_info)->nextlist, (yyvsp[-5].exp_info)->instr);
        qa.backpatch((yyvsp[-3].exp_info)->nextlist, (yyvsp[-9].exp_info)->instr);
        qa.backpatch((yyvsp[-7].exp_info)->nextlist, qa.nextinstr);
        qa.convInt2Bool((yyvsp[-8].exp_info));
        qa.backpatch((yyvsp[-8].exp_info)->truelist, (yyvsp[-1].exp_info)->instr);
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->nextlist = (yyvsp[-8].exp_info)->falselist;
    }
#line 3664 "y.tab.c" /* yacc.c:1646  */
    break;

  case 198:
#line 1799 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
    	// not used
    }
#line 3672 "y.tab.c" /* yacc.c:1646  */
    break;

  case 199:
#line 1807 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3680 "y.tab.c" /* yacc.c:1646  */
    break;

  case 200:
#line 1811 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3688 "y.tab.c" /* yacc.c:1646  */
    break;

  case 201:
#line 1815 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3696 "y.tab.c" /* yacc.c:1646  */
    break;

  case 202:
#line 1819 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr;
        if(st->lookup("retVal")->type.p_type == VOID)
        {
            qa.emit("","",OPER_RETURN,"");
        }
    }
#line 3708 "y.tab.c" /* yacc.c:1646  */
    break;

  case 203:
#line 1827 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        if(st->lookup("retVal")->type.p_type == st->lookup((yyvsp[-1].exp_info)->loc)->type.p_type)
        {
            qa.emit((yyvsp[-1].exp_info)->loc,"",OPER_RETURN,"");
        }
        else
        {
            primtype ret_typ = st->lookup("retVal")->type.p_type;
            string t = st->gentemp(ret_typ);
            qa.conv2type(t,ret_typ,(yyvsp[-1].exp_info)->loc,st->lookup((yyvsp[-1].exp_info)->loc)->type.p_type);
            qa.emit(t,"",OPER_RETURN,"");
        }
        (yyval.exp_info) = new exprr;
    }
#line 3727 "y.tab.c" /* yacc.c:1646  */
    break;

  case 209:
#line 1858 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        qa.emit((yyvsp[-1].dec_info)->name, "", OPER_FUNCT_END);
        st = &(gst);
    }
#line 3736 "y.tab.c" /* yacc.c:1646  */
    break;

  case 212:
#line 1875 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) =  new exprr;  
        (yyval.exp_info)->nextlist = makelist(qa.nextinstr); 
        qa.emit("","",OPER_GOTO,"");
    }
#line 3746 "y.tab.c" /* yacc.c:1646  */
    break;

  case 213:
#line 1885 "ass6_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) =  new exprr; 
        (yyval.exp_info)->instr = qa.nextinstr;
    }
#line 3755 "y.tab.c" /* yacc.c:1646  */
    break;


#line 3759 "y.tab.c" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 1891 "ass6_13CS30016.y" /* yacc.c:1906  */


void yyerror(string s)                  // Function that is invoked when reporting an error in parsing (exception conditions)
{
    std::cout << s << std::endl;
}
