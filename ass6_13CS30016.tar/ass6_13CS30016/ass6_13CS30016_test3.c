/*
	Name : ass6_13CS30016_test1.c
	Author : Rajasekhar Reddy
	Roll No. : 13CS30016
	Description : Test File for testing the made TinyC Compiler
*/


/*
	-	Handling of pointers
	- 	Expressions Handling
	-	Basic I/O
*/

int main()
{
	int a, b, *p, *err, k;

	prints("\nEnter some value for integer variable 'a' :\n");
	prints("\na = ");

	a = readi(err);
	
	prints("You Entered : a = ");
	printi(a);

	prints("\n'p' is a integer pointer. 'p' points to 'a' : p = &a\n");
	p = &a;

	prints("\nprinting the value that 'p' points to : *p\n");
	prints("*p = ");
	printi(*p);

	prints("\nNow, enter another integer 'k' : ");
	prints("\nk = ");
	k = readi(err);

	prints("\nYou Entered : k = ");
	printi(k);

	prints("\nLets change the value of 'a' to be equal to 'k' : a = k\n");
	a = k;

	prints("\nNow, the value of 'a' is :\n");
	prints("a = ");
	printi(a);

	prints("\nSince pointer 'p' points to 'a', *p = ");
	printi(*p);
	prints("\n\n");

	return 0;
}
