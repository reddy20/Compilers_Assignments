#include "myl.h"
#define INT_LEN 20
#define FLOAT_LEN 50
#define N 1000000000000000000							// N = 10^18

typedef long long lli;

int printi(int n){										// function for printing integer
	char buff[INT_LEN], zero = '0';						// buff[] is the buffer which stores the integer in character form for printing
	int i, j, k;
	i = 0;
	if(n == 0)
		buff[i++] = zero;
	else{
		if(n < 0){										// handling (-) sign for negative integers
			buff[i++] = '-';
			n = -n;
		}
		while(n > 0){									// accessing the digits of the integer
			int dig = n % 10;
			buff[i++] = dig + zero;
			n /= 10;
		}
		if(buff[0] == '-')
			j = 1;
		else
			j = 0;
		k = i-1;
		while(j < k){
			char temp = buff[j];
			buff[j++] = buff[k];
			buff[k--] = temp;
		}

	}

	__asm__ __volatile__ (								// printing integer
		"movl $1, %%eax \n\t"
		"movq $1, %%rdi \n\t"
		"syscall \n\t"
		:
		:"S"(buff), "d"(i)
	);	// $1 : write, $1, for stdout

	return i;											// returning number of characters printed
}

int prints(char *str){									// function for printing string(null terminated)
	int n;

	for(n = 0 ; str[n] != '\0' ; n++);					// compute length of string
	n++;												// n = length of string

	__asm__ __volatile__(								// printing string
		"movl $1, %%eax \n\t"
		"movq $1, %%rdi \n\t"
		"syscall \n\t"
		:
		:"S"(str), "d"(n)
	);

	return n;											// returning number of characters printed
}
int readi(int *eP){										// function for reading integer
	char buff[INT_LEN];									// buff[] is the buffer array for storing the input from user
	int i, n, flag;
	
	n = i = flag = 0;									// n -> stores final number, flag = 0 -> means positive number, flag = 1 -> means negative number
	while(i < INT_LEN){									// reading integer digit-by-digit
		__asm__ __volatile(
			"movl $0, %%eax \n\t"
			"movq $0, %%rdi \n\t"
			"syscall \n\t"
			:
			:"S"(buff+i), "d"(1)
		);
	
		if(buff[i] == '\n')								// input terminated
			break;
		if(i == 0 && buff[i] == '-')					// number is negative
			flag = 1;
		else if(i == 0 && buff[i] == '+'){				// single '+' in the beginning is allowed

		}
		else if(buff[i] >= '0' && buff[i] <= '9'){		// valid digits
			n *= 10;
			n += (buff[i]-'0');	
			i++;	
		}
		else{											// invalid input
			return n;
		}
	}
	
	if(i == INT_LEN){
		return n;
	}
	
	if(flag == 1)										// input number is negative
		n *= -1;
	
	return n;
}
int printd(float f){									// function for printing float
	char buff[FLOAT_LEN];								// for storing the floating point number for printing character-wise
	int cnt, n, i, j, k;
	lli n_large;
	float temp;
	i = 0;
	if(f < 0){											// handling negative floating point number
		buff[0] = '-';
		i = 1;
		f = -f;
	}
	if(f < 1){											// for printing a number with absolute value less than 1
		n = f * 1000000;
		if(n < 0){
			n = -n;
			buff[0] = '-';
			i++;
		}
		buff[i] = '0';
		i++;
		buff[i] = '.';
		i++;
		j = i+5;
		i = j+1;
		for(k = 0 ; k < 6 ; k++){
			buff[j] = (n % 10) + '0';
			n /= 10;
			j--;
		}
	}
	else {												
		temp = f;
		cnt = 0;
		while(temp >= 1){								// counting the number of digits before decimal point in the number
			temp /= 10;
			cnt++;
		}
		if(cnt <= 18){
			n_large = f;								// 'n_large' stores the number formed by the digits before the decimal point
			temp = f - (float)n_large;
			temp *= 1000000;
			n = temp;									// 'n' stores the number formed by the digits after decimal point
			j = i;
			while(n_large > 0){							// storing digits before decimal point into buffer
				buff[i] = (n_large % 10) + '0';
				n_large /= 10;
				i++;
			}
			k = i-1;
			while(j < k){
				char tempc = buff[j];
				buff[j++] = buff[k];
				buff[k--] = tempc;
			}
			buff[i] = '.';								// storing decimal point
			i++;
			j = i+5;
			i = j+1;
			for(k = 0 ; k < 6 ; k++){					// storing digits after decimal point into buffer
				buff[j] = (n % 10) + '0';
				n /= 10;
				j--;
			}
		}
	}
	__asm__ __volatile__ (									// printing the floating point number
		"movl $1, %%eax \n\t"
		"movq $1, %%rdi \n\t"
		"syscall \n\t"
		:
		:"S"(buff), "d"(i)
	);	// $1 : write, $1, for stdout
	return i;												// returning the number of digits printed
}
int readf(float *fP){										// function to read floating point number
	int i, flag, dec;
	float n, power;
	char buff[FLOAT_LEN];									// buffer to store input floating point number
	i = n = flag = dec = 0;
	power = 1;
	while(i < FLOAT_LEN){									// reading the number from the user character-by-character
		__asm__ __volatile(
			"movl $0, %%eax \n\t"
			"movq $0, %%rdi \n\t"
			"syscall \n\t"
			:
			:"S"(buff+i), "d"(1)
		);
		if(buff[i] == '\n')									// input terminated
			break;
		if(i == 0 && buff[i] == '-'){						// input number is negative
			flag = 1;
		}
		else if(i == 0 && buff[i] == '+'){					// single '+' before the number is valid

		}
		else if(buff[i] >= '0' && buff[i] <= '9'){			
			if(dec == 0){									// handling valid digits before decimal point 
				n = n * 10;
				n += (buff[i] - '0');
			}
			else{											// handling valid digits after decimal point
				power /= (float)10;
				n += (power * (float)(buff[i]-'0'));
			}
		}
		else if(buff[i] == '.' && dec == 0){				// reading decimal point
			dec = 1;
		}
		else{												// invalid input
			*fP = n;
			return 1;
		}
		i++;
	}
	if(i == FLOAT_LEN){
		*fP = n;
		return 1;
	}
	if(flag == 1)											// input number is negative
		n = -n;
	*fP = n;												
	return 0;
}
