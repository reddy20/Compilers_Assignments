/*******

  Name: K Rajasekhar Reddy
  Roll Number: 13CS30016
  Assignment 4: parser 
**/
int Hello;

int add(int* c1, int* c2){
  int c;
  c.x = c1->x + c2->x;
  c.y = c1->y + c2->y;
  c.p = NULL;
  return c;
}

float add_float(float f1, float f2){
  float f3 = 2E-3;
  f3 -= (f1+f2);
  return f3;
}

int main(){
  unsigned int x;
  x = 5;
  char *str;
  /* Checking the For Statement*/
  for (int i=0;i<x;i++){
    printf("This code test the correctness of Parser.");
  }
  /* Checking the Do While Statement*/
  x = 1;
  do{
    int *c1,*c2;
    c1->x = 4;
    c2->x = 5;
    int c3;
    c3 = add(c1,c2);
  }while(--x);

  

  int arr[7]={0,0,0,0,0,0,0};

  switch(day){
    case 1:{
        arr[0] = 1;
        break;
      }
    case 2:{
      arr[1] = 1;
      break;
    }
    default: arr[6] = 1;
  }

  if (arr[0] == 1 && arr[1] == 0){
    str = "Monday";
  }
  else if(arr[1]==1){
    str = "Tuesday";
  }
  else{
    str="Sunday";
  }

  x = 1;
  x = x>>2;

  int *p;
  p = &x;
  int y = *(&x);
  static const int z = *(p);

  double m,n;

  m = 4.534;
  n = 3.456;
  m = m*n;
  n = m/n;
  z += n;
  z %= n;
  z = (int)m;
  x = z | y;
  if (x!=0){
    char c='I';
  }
  return 0;
}
