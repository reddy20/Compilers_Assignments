/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* Copy the first part of user declarations.  */
#line 1 "ass4_13CS30016.y" /* yacc.c:339  */

	#include <stdio.h>
	extern int yylex();
	void yyerror(const char* s);

#line 72 "y.tab.c" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "y.tab.h".  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    _SINGLECOMMENT = 258,
    _MULTICOMMENT = 259,
    AUTO = 260,
    BREAK = 261,
    CASE = 262,
    CHAR = 263,
    CONST = 264,
    CONTINUE = 265,
    DEFAULT = 266,
    DO = 267,
    DOUBLE = 268,
    ELSE = 269,
    ENUM = 270,
    EXTERN = 271,
    FLOAT = 272,
    FOR = 273,
    GOTO = 274,
    IF = 275,
    INLINE = 276,
    INT = 277,
    LONG = 278,
    REGISTER = 279,
    RESTRICT = 280,
    RETURN = 281,
    SHORT = 282,
    SIGNED = 283,
    SIZEOF = 284,
    STATIC = 285,
    STRUCT = 286,
    SWITCH = 287,
    TYPEDEF = 288,
    UNION = 289,
    UNSIGNED = 290,
    VOID = 291,
    VOLATILE = 292,
    WHILE = 293,
    _BOOL = 294,
    _COMPLEX = 295,
    _IMAGINARY = 296,
    DEFERENCER = 297,
    INCREMENT = 298,
    DECREMENT = 299,
    SHIFT_LEFT = 300,
    SHIFT_RIGHT = 301,
    LESS_EQUAL = 302,
    GREATER_EQUAL = 303,
    EQUAL_TO = 304,
    NOT_EQUAL = 305,
    AND = 306,
    OR = 307,
    THREE_DOTS = 308,
    MULT_ASSIGN = 309,
    DIV_ASSIGN = 310,
    MOD_ASSIGN = 311,
    ADD_ASSIGN = 312,
    SUB_ASSIGN = 313,
    SHIFT_LEFT_ASSIGN = 314,
    SHIFT_RIGHT_ASSIGN = 315,
    AND_ASSIGN = 316,
    XOR_ASSIGN = 317,
    OR_ASSIGN = 318,
    IDENTIFIER = 319,
    CONSTANT = 320,
    STRING_LITERAL = 321
  };
#endif
/* Tokens.  */
#define _SINGLECOMMENT 258
#define _MULTICOMMENT 259
#define AUTO 260
#define BREAK 261
#define CASE 262
#define CHAR 263
#define CONST 264
#define CONTINUE 265
#define DEFAULT 266
#define DO 267
#define DOUBLE 268
#define ELSE 269
#define ENUM 270
#define EXTERN 271
#define FLOAT 272
#define FOR 273
#define GOTO 274
#define IF 275
#define INLINE 276
#define INT 277
#define LONG 278
#define REGISTER 279
#define RESTRICT 280
#define RETURN 281
#define SHORT 282
#define SIGNED 283
#define SIZEOF 284
#define STATIC 285
#define STRUCT 286
#define SWITCH 287
#define TYPEDEF 288
#define UNION 289
#define UNSIGNED 290
#define VOID 291
#define VOLATILE 292
#define WHILE 293
#define _BOOL 294
#define _COMPLEX 295
#define _IMAGINARY 296
#define DEFERENCER 297
#define INCREMENT 298
#define DECREMENT 299
#define SHIFT_LEFT 300
#define SHIFT_RIGHT 301
#define LESS_EQUAL 302
#define GREATER_EQUAL 303
#define EQUAL_TO 304
#define NOT_EQUAL 305
#define AND 306
#define OR 307
#define THREE_DOTS 308
#define MULT_ASSIGN 309
#define DIV_ASSIGN 310
#define MOD_ASSIGN 311
#define ADD_ASSIGN 312
#define SUB_ASSIGN 313
#define SHIFT_LEFT_ASSIGN 314
#define SHIFT_RIGHT_ASSIGN 315
#define AND_ASSIGN 316
#define XOR_ASSIGN 317
#define OR_ASSIGN 318
#define IDENTIFIER 319
#define CONSTANT 320
#define STRING_LITERAL 321

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 7 "ass4_13CS30016.y" /* yacc.c:355  */

	int t;
	float p;
	char *c;

#line 250 "y.tab.c" /* yacc.c:355  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */

/* Copy the second part of user declarations.  */

#line 265 "y.tab.c" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  47
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1154

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  91
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  65
/* YYNRULES -- Number of rules.  */
#define YYNRULES  204
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  341

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   321

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    80,     2,     2,     2,    82,    75,     2,
      67,    68,    76,    77,    74,    78,    71,    81,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    88,    90,
      83,    89,    84,    87,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    69,     2,    70,    85,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    72,    86,    73,    79,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,    87,    87,    88,    89,    90,    94,    95,    96,    97,
      98,    99,   100,   101,   102,   103,   107,   108,   112,   113,
     114,   115,   116,   117,   121,   122,   123,   124,   125,   126,
     130,   131,   135,   136,   137,   138,   142,   143,   144,   148,
     149,   150,   154,   155,   156,   157,   158,   162,   163,   164,
     168,   169,   173,   174,   178,   179,   183,   184,   188,   189,
     193,   194,   198,   199,   203,   204,   205,   206,   207,   208,
     209,   210,   211,   212,   213,   217,   218,   222,   228,   229,
     233,   234,   235,   236,   237,   238,   239,   240,   244,   245,
     249,   250,   254,   255,   256,   257,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   277,
     278,   279,   280,   284,   285,   286,   287,   288,   292,   293,
     297,   298,   302,   306,   307,   308,   312,   316,   317,   321,
     322,   323,   324,   325,   326,   327,   328,   329,   333,   334,
     338,   339,   343,   344,   348,   349,   353,   354,   358,   359,
     363,   364,   368,   369,   373,   377,   378,   379,   383,   384,
     385,   386,   390,   394,   395,   399,   400,   406,   407,   408,
     409,   410,   411,   415,   416,   417,   421,   422,   426,   427,
     431,   432,   436,   437,   441,   442,   443,   447,   448,   449,
     450,   454,   455,   459,   460,   461,   462,   468,   469,   473,
     474,   478,   479,   483,   484
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "_SINGLECOMMENT", "_MULTICOMMENT",
  "AUTO", "BREAK", "CASE", "CHAR", "CONST", "CONTINUE", "DEFAULT", "DO",
  "DOUBLE", "ELSE", "ENUM", "EXTERN", "FLOAT", "FOR", "GOTO", "IF",
  "INLINE", "INT", "LONG", "REGISTER", "RESTRICT", "RETURN", "SHORT",
  "SIGNED", "SIZEOF", "STATIC", "STRUCT", "SWITCH", "TYPEDEF", "UNION",
  "UNSIGNED", "VOID", "VOLATILE", "WHILE", "_BOOL", "_COMPLEX",
  "_IMAGINARY", "DEFERENCER", "INCREMENT", "DECREMENT", "SHIFT_LEFT",
  "SHIFT_RIGHT", "LESS_EQUAL", "GREATER_EQUAL", "EQUAL_TO", "NOT_EQUAL",
  "AND", "OR", "THREE_DOTS", "MULT_ASSIGN", "DIV_ASSIGN", "MOD_ASSIGN",
  "ADD_ASSIGN", "SUB_ASSIGN", "SHIFT_LEFT_ASSIGN", "SHIFT_RIGHT_ASSIGN",
  "AND_ASSIGN", "XOR_ASSIGN", "OR_ASSIGN", "IDENTIFIER", "CONSTANT",
  "STRING_LITERAL", "'('", "')'", "'['", "']'", "'.'", "'{'", "'}'", "','",
  "'&'", "'*'", "'+'", "'-'", "'~'", "'!'", "'/'", "'%'", "'<'", "'>'",
  "'^'", "'|'", "'?'", "':'", "'='", "';'", "$accept",
  "primary_expression", "postfix_expression", "argument_expression_list",
  "unary_expression", "unary_operator", "cast_expression",
  "multiplicative_expression", "additive_expression", "shift_expression",
  "relational_expression", "equality_expression", "AND_expression",
  "exclusive_OR_expression", "inclusive_OR_expression",
  "logical_AND_expression", "logical_OR_expression",
  "conditional_expression", "assignment_expression", "assignment_operator",
  "expression", "constant_expression", "declaration",
  "declaration_specifiers", "init_declarator_list", "init_declarator",
  "storage_class_specifier", "type_specifier", "specifier_qualifier_list",
  "enum_specifier", "enumerator_list", "enumerator",
  "enumeration_constant", "type_qualifier", "function_specifier",
  "declarator", "direct_declarator", "type_qualifier_list_opt",
  "assignment_expression_opt", "pointer", "type_qualifier_list",
  "parameter_type_list", "parameter_list", "parameter_declaration",
  "identifier_list", "type_name", "initializer", "initializer_list",
  "designation", "designator_list", "designator", "statement",
  "labeled_statement", "compound_statement", "block_item_list",
  "block_item", "expression_statement", "selection_statement",
  "iteration_statement", "expression_opt", "jump_statement",
  "translation_unit", "external_declaration", "function_definition",
  "declaration_list", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,    40,    41,    91,
      93,    46,   123,   125,    44,    38,    42,    43,    45,   126,
      33,    47,    37,    60,    62,    94,   124,    63,    58,    61,
      59
};
# endif

#define YYPACT_NINF -272

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-272)))

#define YYTABLE_NINF -1

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    1079,  -272,  -272,  -272,  -272,   -47,  -272,  -272,  -272,  -272,
    -272,  -272,  -272,  -272,  -272,  -272,  -272,  -272,  -272,  -272,
    -272,  -272,  -272,   -11,  1079,  1079,  -272,  1079,  1079,  1042,
    -272,  -272,   -50,    16,  -272,    57,     9,  -272,   -26,  -272,
     506,    72,    34,  -272,  -272,  -272,  -272,  -272,  -272,    16,
    -272,    85,  -272,   -59,   -41,  -272,    17,     9,    57,  -272,
     279,   796,  -272,   -11,  -272,   693,   731,    20,    72,   100,
    -272,    49,   857,  -272,  -272,  -272,  -272,    -1,    37,   857,
      40,    60,   430,    87,    98,   109,   857,   882,   135,   156,
     899,   899,    77,  -272,  -272,   617,  -272,  -272,  -272,  -272,
    -272,  -272,  -272,  -272,  -272,     0,   150,   857,  -272,     1,
     -19,   153,   -32,   151,   145,   142,   140,   178,   -33,  -272,
    -272,   -14,  -272,  -272,  -272,  -272,   355,  -272,  -272,  -272,
    -272,  -272,  -272,   400,  -272,  -272,  -272,  -272,  -272,  -272,
      57,   167,   164,  -272,    13,     9,   924,    38,  -272,    59,
    -272,  -272,  -272,  -272,  -272,  -272,   154,  -272,   430,   205,
     544,   155,   857,   172,   158,   617,  -272,   857,   857,   617,
    -272,  -272,   430,    41,  1113,  -272,  1113,   181,   186,  -272,
    -272,   813,   857,   187,  -272,  -272,  -272,  -272,  -272,  -272,
    -272,  -272,  -272,  -272,  -272,   857,  -272,   857,   857,   857,
     857,   857,   857,   857,   857,   857,   857,   857,   857,   857,
     857,   857,   857,   857,   857,   857,   857,  -272,  -272,  -272,
     857,   188,  -272,   141,   796,    39,  -272,  -272,  -272,  1000,
    -272,   192,   857,   189,  -272,   190,   857,  -272,   430,  -272,
     194,   857,   173,  -272,    43,  -272,   196,    61,    63,   197,
    -272,  -272,  -272,  -272,   840,  -272,  -272,    70,  -272,    83,
    -272,  -272,  -272,  -272,  -272,     1,     1,   -19,   -19,   153,
     153,   153,   153,   -32,   -32,   151,   145,   142,   140,   178,
     -53,  -272,   198,  -272,  -272,   740,  -272,  -272,  -272,  -272,
    -272,  -272,   199,  -272,  -272,   200,  -272,   857,   183,   857,
     430,   185,   430,   430,   185,   400,  -272,  -272,   857,  -272,
     857,  -272,  -272,  -272,   796,  -272,  -272,    75,   857,   184,
     261,  -272,  -272,   143,  -272,  -272,  -272,   191,   208,   857,
     430,  -272,   757,  -272,   430,   209,  -272,  -272,  -272,   430,
    -272
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,    94,    97,   123,   102,     0,    92,   101,   126,    99,
     100,    95,   124,    98,   103,    93,   104,    96,   125,   105,
     106,   107,   200,     0,    80,    82,   108,    84,    86,     0,
     197,   199,   117,     0,   129,     0,   139,    78,     0,    88,
      90,   127,     0,    81,    83,    85,    87,     1,   198,     0,
     122,     0,   118,   120,     0,   144,   142,   138,     0,    79,
       0,     0,   203,     0,   201,     0,     0,   139,   128,     0,
     113,     0,     0,   130,   143,   145,    89,    90,     0,     0,
       0,     0,     0,     0,     0,     0,   192,     0,     0,     0,
       0,     0,     2,     3,     4,     0,   176,    24,    25,    26,
      27,    28,    29,   183,     6,    18,    30,     0,    32,    36,
      39,    42,    47,    50,    52,    54,    56,    58,    60,    62,
      75,     0,   180,   181,   167,   168,     0,   178,   169,   170,
     171,   172,     2,     0,   155,    91,   204,   202,   152,   136,
     151,     0,   146,   148,     0,   139,   141,   138,   114,     0,
     115,   119,    30,    77,   121,   195,     0,   194,     0,     0,
     192,     0,     0,   191,     0,     0,    22,     0,     0,     0,
      19,    20,     0,     0,   109,   154,   111,     0,     0,    12,
      13,     0,     0,     0,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    64,     0,    21,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   182,   177,   179,
       0,     0,   158,     0,     0,     0,   163,   150,   135,     0,
     137,     0,     0,    25,   140,     0,     0,   116,     0,   175,
       0,   192,     0,   193,     0,   196,     0,     0,     0,     0,
     173,     5,   110,   112,     0,    11,     8,     0,    16,     0,
      10,    63,    33,    34,    35,    37,    38,    40,    41,    45,
      46,    43,    44,    48,    49,    51,    53,    55,    57,    59,
       0,    76,     0,   166,   156,     0,   159,   162,   164,   147,
     149,   153,     0,   134,   131,     0,   174,     0,     0,   192,
       0,    23,     0,     0,     0,     0,    31,     9,     0,     7,
       0,   165,   157,   160,     0,   132,   133,     0,   192,     0,
     184,   186,   187,     0,    17,    61,   161,     0,     0,   192,
       0,    14,     0,   188,     0,     0,   185,    15,   190,     0,
     189
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -272,  -272,  -272,  -272,   -17,  -272,  -103,    18,    19,   -37,
      24,    68,    69,    67,    97,    99,  -272,   -70,   -61,  -272,
     -63,   -74,   -34,    12,  -272,   224,  -272,   -62,     3,  -272,
     234,   -58,  -272,   -29,  -272,   -15,   270,   -56,  -272,   265,
     257,  -272,  -272,    96,  -272,    -9,   -60,    21,  -271,  -272,
     102,   -72,  -272,   -16,  -272,   202,  -272,  -272,  -272,  -157,
    -272,  -272,   300,  -272,  -272
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,   104,   105,   257,   106,   107,   108,   109,   110,   111,
     112,   113,   114,   115,   116,   117,   118,   119,   120,   195,
     121,   154,    22,    63,    38,    39,    24,    25,   175,    26,
      51,    52,    53,    27,    28,    77,    41,    56,   235,    42,
      57,   141,   142,   143,   144,   177,   222,   223,   224,   225,
     226,   123,   124,   125,   126,   127,   128,   129,   130,   164,
     131,    29,    30,    31,    65
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_uint16 yytable[] =
{
     134,   135,   153,   242,   196,   156,    62,    55,    40,   153,
     159,   146,    23,   151,   314,   204,   205,    32,     3,   214,
      54,   216,    49,   163,    64,    33,   122,    73,    75,     3,
      72,   136,   173,   174,    12,   310,    43,    44,    55,    45,
      46,    23,   178,   179,   180,    12,    18,     3,    58,   137,
     145,   206,   207,    34,   215,   152,    35,    18,   200,   201,
     216,   314,   152,    12,    59,    36,   176,   181,   236,   182,
     166,   183,   134,   170,   171,    18,   217,   197,   140,    37,
      50,   230,   198,   199,   298,   234,   239,   231,    61,   232,
     152,   151,   122,    36,   262,   263,   264,   163,    34,   244,
     250,    35,   173,   174,   247,   248,   173,   174,   220,   251,
     221,   300,   174,    50,   174,   216,    55,   216,    75,   259,
     258,    34,   150,    50,    35,   227,   241,   155,   287,   302,
     157,   303,   237,    36,   261,   216,   176,   216,   307,    66,
     176,    67,   319,   327,   308,   176,   282,   176,   158,   216,
     153,   306,   280,   309,   160,   281,   246,   216,    70,    71,
     249,   328,   161,   134,   286,   172,   296,   269,   270,   271,
     272,   292,   335,   148,   149,   295,   162,   252,   163,   253,
     152,   152,   152,   152,   152,   152,   152,   152,   152,   152,
     152,   152,   152,   152,   152,   152,   152,   152,   202,   203,
     208,   209,   167,   152,   184,   185,   186,   187,   188,   189,
     190,   191,   192,   193,   284,   285,   331,   332,   265,   266,
     210,   267,   268,   168,   134,   313,   212,   211,   320,   213,
     321,   322,   273,   274,   317,   228,   163,   152,   229,   194,
     325,   140,   238,   240,   134,   243,   216,   324,   245,   254,
     255,   260,   283,   134,   326,   163,   291,   305,   336,   293,
     294,   297,   338,   299,   301,   304,   163,   340,   311,   315,
     316,   134,   313,   318,   329,   330,   334,   339,   275,   277,
     276,   333,    76,    69,     1,    78,    79,     2,     3,    80,
      81,    82,     4,   152,     5,     6,     7,    83,    84,    85,
       8,     9,    10,    11,    12,    86,    13,    14,    87,    15,
     278,    88,    68,   279,    16,    17,    18,    89,    19,    20,
      21,    74,    90,    91,   147,   290,   323,   288,   219,    48,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    92,    93,    94,    95,     0,     0,     0,
       0,    60,    96,     0,    97,    98,    99,   100,   101,   102,
       1,    78,    79,     2,     3,    80,    81,    82,     4,   103,
       5,     6,     7,    83,    84,    85,     8,     9,    10,    11,
      12,    86,    13,    14,    87,    15,     0,    88,     0,     0,
      16,    17,    18,    89,    19,    20,    21,     0,    90,    91,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    92,
      93,    94,    95,     0,     0,     0,     0,    60,   218,    87,
      97,    98,    99,   100,   101,   102,    78,    79,     0,     0,
      80,    81,    82,    90,    91,   103,     0,     0,    83,    84,
      85,     0,     0,     0,     0,     0,    86,     0,     0,    87,
       0,     0,    88,     0,   132,    93,    94,    95,    89,   220,
       0,   221,   133,    90,    91,    97,    98,    99,   100,   101,
     102,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    92,    93,    94,    95,     0,     0,
       0,     0,    60,     0,     0,    97,    98,    99,   100,   101,
     102,     1,     0,     0,     2,     3,     0,     0,     0,     4,
     103,     5,     6,     7,     0,     0,     0,     8,     9,    10,
      11,    12,     0,    13,    14,     0,    15,     0,     0,     0,
       0,    16,    17,    18,     0,    19,    20,    21,     0,     1,
       0,     0,     2,     3,     0,     0,     0,     4,     0,     5,
       6,     7,     0,     0,     0,     8,     9,    10,    11,    12,
       0,    13,    14,    87,    15,     0,     0,     0,    60,    16,
      17,    18,     0,    19,    20,    21,     0,    90,    91,     0,
       0,     0,     0,     0,     0,    61,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   132,    93,
      94,    95,     0,     0,     0,     0,     0,     0,     0,    97,
      98,    99,   100,   101,   102,     2,     3,     0,     0,     0,
       4,     0,     5,     0,     7,     0,     0,     0,     0,     9,
      10,     0,    12,     0,    13,    14,    87,     0,     0,     0,
       0,     0,    16,    17,    18,     0,    19,    20,    21,     0,
      90,    91,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   132,    93,    94,    95,     0,     0,     0,     0,     0,
       0,     0,    97,    98,    99,   100,   101,   102,     1,     0,
       0,     2,     3,     0,     0,     0,     4,     0,     5,     6,
       7,     0,     0,     0,     8,     9,    10,    11,    12,     0,
      13,    14,     0,    15,     0,     0,     0,     0,    16,    17,
      18,     0,    19,    20,    21,     0,     1,     0,     0,     2,
       3,     0,     0,     0,     4,     0,     5,     6,     7,     0,
       0,     0,     8,     9,    10,    11,    12,     0,    13,    14,
       0,    15,     0,     0,     0,    60,    16,    17,    18,    87,
      19,    20,    21,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    90,    91,     0,    87,     0,     0,     0,
       0,     0,     0,     0,     0,   138,     0,     0,     0,   139,
      90,    91,     0,     0,   132,    93,    94,    95,     0,   220,
       0,   221,   133,   312,     0,    97,    98,    99,   100,   101,
     102,   132,    93,    94,    95,    87,   220,     0,   221,   133,
     337,     0,    97,    98,    99,   100,   101,   102,     0,    90,
      91,     0,    87,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    90,    91,     0,     0,
     132,    93,    94,    95,     0,     0,     0,     0,   133,    87,
       0,    97,    98,    99,   100,   101,   102,   132,    93,    94,
      95,   256,     0,    90,    91,     0,    87,     0,    97,    98,
      99,   100,   101,   102,     0,     0,     0,     0,     0,     0,
      90,    91,     0,     0,   132,    93,    94,    95,     0,     0,
       0,    87,   305,     0,     0,    97,    98,    99,   100,   101,
     102,   132,    93,    94,    95,    90,    91,     0,    87,     0,
       0,     0,    97,    98,    99,   100,   101,   102,     0,     0,
       0,     0,    90,    91,     0,     0,   132,    93,    94,   165,
       0,     0,     0,    87,     0,     0,     0,    97,    98,    99,
     100,   101,   102,   132,    93,    94,   169,    90,    91,     0,
       0,     0,     0,     0,    97,    98,    99,   100,   101,   102,
       0,     0,     0,     0,     0,     0,     0,     0,   132,    93,
      94,    95,     0,     0,     0,     0,     0,     0,     0,    97,
     233,    99,   100,   101,   102,     1,     0,     0,     2,     3,
       0,     0,     0,     4,     0,     5,     6,     7,     0,     0,
       0,     8,     9,    10,    11,    12,     0,    13,    14,     0,
      15,     0,     0,     0,     0,    16,    17,    18,     0,    19,
      20,    21,    47,     0,     0,     0,     0,     1,     0,     0,
       2,     3,     0,   289,     0,     4,     0,     5,     6,     7,
       0,     0,     0,     8,     9,    10,    11,    12,     0,    13,
      14,     0,    15,     0,     0,     0,     0,    16,    17,    18,
       0,    19,    20,    21,     1,     0,     0,     2,     3,     0,
       0,     0,     4,     0,     5,     6,     7,     0,     0,     0,
       8,     9,    10,    11,    12,     0,    13,    14,     0,    15,
       0,     0,     0,     0,    16,    17,    18,     0,    19,    20,
      21,     2,     3,     0,     0,     0,     4,     0,     5,     0,
       7,     0,     0,     0,     0,     9,    10,     0,    12,     0,
      13,    14,     0,     0,     0,     0,     0,     0,    16,    17,
      18,     0,    19,    20,    21
};

static const yytype_int16 yycheck[] =
{
      61,    61,    72,   160,   107,    79,    40,    36,    23,    79,
      82,    67,     0,    71,   285,    47,    48,    64,     9,    52,
      35,    74,    72,    86,    40,    72,    60,    68,    57,     9,
      89,    65,    95,    95,    25,    88,    24,    25,    67,    27,
      28,    29,    42,    43,    44,    25,    37,     9,    74,    65,
      30,    83,    84,    64,    87,    72,    67,    37,    77,    78,
      74,   332,    79,    25,    90,    76,    95,    67,    30,    69,
      87,    71,   133,    90,    91,    37,    90,    76,    66,    90,
      64,    68,    81,    82,   241,   146,   158,    74,    89,   145,
     107,   149,   126,    76,   197,   198,   199,   160,    64,   162,
     172,    67,   165,   165,   167,   168,   169,   169,    69,    68,
      71,    68,   174,    64,   176,    74,   145,    74,   147,   182,
     181,    64,    73,    64,    67,   140,   160,    90,    89,    68,
      90,    68,    73,    76,   195,    74,   165,    74,    68,    67,
     169,    69,   299,    68,    74,   174,   220,   176,    88,    74,
     220,   254,   215,    70,    67,   216,   165,    74,    73,    74,
     169,   318,    64,   224,   224,    88,   238,   204,   205,   206,
     207,   232,   329,    73,    74,   236,    67,   174,   241,   176,
     197,   198,   199,   200,   201,   202,   203,   204,   205,   206,
     207,   208,   209,   210,   211,   212,   213,   214,    45,    46,
      49,    50,    67,   220,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    73,    74,    73,    74,   200,   201,
      75,   202,   203,    67,   285,   285,    86,    85,   300,    51,
     302,   303,   208,   209,   297,    68,   299,   254,    74,    89,
     310,   229,    88,    38,   305,    90,    74,   308,    90,    68,
      64,    64,    64,   314,   314,   318,    64,    72,   330,    70,
      70,    67,   334,    90,    68,    68,   329,   339,    70,    70,
      70,   332,   332,    90,    90,    14,    68,    68,   210,   212,
     211,    90,    58,    49,     5,     6,     7,     8,     9,    10,
      11,    12,    13,   310,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    30,
     213,    32,    42,   214,    35,    36,    37,    38,    39,    40,
      41,    56,    43,    44,    67,   229,   305,   225,   126,    29,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    64,    65,    66,    67,    -1,    -1,    -1,
      -1,    72,    73,    -1,    75,    76,    77,    78,    79,    80,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    90,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    -1,    32,    -1,    -1,
      35,    36,    37,    38,    39,    40,    41,    -1,    43,    44,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    64,
      65,    66,    67,    -1,    -1,    -1,    -1,    72,    73,    29,
      75,    76,    77,    78,    79,    80,     6,     7,    -1,    -1,
      10,    11,    12,    43,    44,    90,    -1,    -1,    18,    19,
      20,    -1,    -1,    -1,    -1,    -1,    26,    -1,    -1,    29,
      -1,    -1,    32,    -1,    64,    65,    66,    67,    38,    69,
      -1,    71,    72,    43,    44,    75,    76,    77,    78,    79,
      80,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    64,    65,    66,    67,    -1,    -1,
      -1,    -1,    72,    -1,    -1,    75,    76,    77,    78,    79,
      80,     5,    -1,    -1,     8,     9,    -1,    -1,    -1,    13,
      90,    15,    16,    17,    -1,    -1,    -1,    21,    22,    23,
      24,    25,    -1,    27,    28,    -1,    30,    -1,    -1,    -1,
      -1,    35,    36,    37,    -1,    39,    40,    41,    -1,     5,
      -1,    -1,     8,     9,    -1,    -1,    -1,    13,    -1,    15,
      16,    17,    -1,    -1,    -1,    21,    22,    23,    24,    25,
      -1,    27,    28,    29,    30,    -1,    -1,    -1,    72,    35,
      36,    37,    -1,    39,    40,    41,    -1,    43,    44,    -1,
      -1,    -1,    -1,    -1,    -1,    89,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    64,    65,
      66,    67,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    75,
      76,    77,    78,    79,    80,     8,     9,    -1,    -1,    -1,
      13,    -1,    15,    -1,    17,    -1,    -1,    -1,    -1,    22,
      23,    -1,    25,    -1,    27,    28,    29,    -1,    -1,    -1,
      -1,    -1,    35,    36,    37,    -1,    39,    40,    41,    -1,
      43,    44,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    64,    65,    66,    67,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    75,    76,    77,    78,    79,    80,     5,    -1,
      -1,     8,     9,    -1,    -1,    -1,    13,    -1,    15,    16,
      17,    -1,    -1,    -1,    21,    22,    23,    24,    25,    -1,
      27,    28,    -1,    30,    -1,    -1,    -1,    -1,    35,    36,
      37,    -1,    39,    40,    41,    -1,     5,    -1,    -1,     8,
       9,    -1,    -1,    -1,    13,    -1,    15,    16,    17,    -1,
      -1,    -1,    21,    22,    23,    24,    25,    -1,    27,    28,
      -1,    30,    -1,    -1,    -1,    72,    35,    36,    37,    29,
      39,    40,    41,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    43,    44,    -1,    29,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    64,    -1,    -1,    -1,    68,
      43,    44,    -1,    -1,    64,    65,    66,    67,    -1,    69,
      -1,    71,    72,    73,    -1,    75,    76,    77,    78,    79,
      80,    64,    65,    66,    67,    29,    69,    -1,    71,    72,
      73,    -1,    75,    76,    77,    78,    79,    80,    -1,    43,
      44,    -1,    29,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    43,    44,    -1,    -1,
      64,    65,    66,    67,    -1,    -1,    -1,    -1,    72,    29,
      -1,    75,    76,    77,    78,    79,    80,    64,    65,    66,
      67,    68,    -1,    43,    44,    -1,    29,    -1,    75,    76,
      77,    78,    79,    80,    -1,    -1,    -1,    -1,    -1,    -1,
      43,    44,    -1,    -1,    64,    65,    66,    67,    -1,    -1,
      -1,    29,    72,    -1,    -1,    75,    76,    77,    78,    79,
      80,    64,    65,    66,    67,    43,    44,    -1,    29,    -1,
      -1,    -1,    75,    76,    77,    78,    79,    80,    -1,    -1,
      -1,    -1,    43,    44,    -1,    -1,    64,    65,    66,    67,
      -1,    -1,    -1,    29,    -1,    -1,    -1,    75,    76,    77,
      78,    79,    80,    64,    65,    66,    67,    43,    44,    -1,
      -1,    -1,    -1,    -1,    75,    76,    77,    78,    79,    80,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    64,    65,
      66,    67,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    75,
      76,    77,    78,    79,    80,     5,    -1,    -1,     8,     9,
      -1,    -1,    -1,    13,    -1,    15,    16,    17,    -1,    -1,
      -1,    21,    22,    23,    24,    25,    -1,    27,    28,    -1,
      30,    -1,    -1,    -1,    -1,    35,    36,    37,    -1,    39,
      40,    41,     0,    -1,    -1,    -1,    -1,     5,    -1,    -1,
       8,     9,    -1,    53,    -1,    13,    -1,    15,    16,    17,
      -1,    -1,    -1,    21,    22,    23,    24,    25,    -1,    27,
      28,    -1,    30,    -1,    -1,    -1,    -1,    35,    36,    37,
      -1,    39,    40,    41,     5,    -1,    -1,     8,     9,    -1,
      -1,    -1,    13,    -1,    15,    16,    17,    -1,    -1,    -1,
      21,    22,    23,    24,    25,    -1,    27,    28,    -1,    30,
      -1,    -1,    -1,    -1,    35,    36,    37,    -1,    39,    40,
      41,     8,     9,    -1,    -1,    -1,    13,    -1,    15,    -1,
      17,    -1,    -1,    -1,    -1,    22,    23,    -1,    25,    -1,
      27,    28,    -1,    -1,    -1,    -1,    -1,    -1,    35,    36,
      37,    -1,    39,    40,    41
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     5,     8,     9,    13,    15,    16,    17,    21,    22,
      23,    24,    25,    27,    28,    30,    35,    36,    37,    39,
      40,    41,   113,   114,   117,   118,   120,   124,   125,   152,
     153,   154,    64,    72,    64,    67,    76,    90,   115,   116,
     126,   127,   130,   114,   114,   114,   114,     0,   153,    72,
      64,   121,   122,   123,   126,   124,   128,   131,    74,    90,
      72,    89,   113,   114,   144,   155,    67,    69,   127,   121,
      73,    74,    89,    68,   130,   124,   116,   126,     6,     7,
      10,    11,    12,    18,    19,    20,    26,    29,    32,    38,
      43,    44,    64,    65,    66,    67,    73,    75,    76,    77,
      78,    79,    80,    90,    92,    93,    95,    96,    97,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
     109,   111,   113,   142,   143,   144,   145,   146,   147,   148,
     149,   151,    64,    72,   109,   137,   113,   144,    64,    68,
     114,   132,   133,   134,   135,    30,   128,   131,    73,    74,
      73,   122,    95,   108,   112,    90,   112,    90,    88,   142,
      67,    64,    67,   111,   150,    67,    95,    67,    67,    67,
      95,    95,    88,   111,   118,   119,   124,   136,    42,    43,
      44,    67,    69,    71,    54,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    89,   110,    97,    76,    81,    82,
      77,    78,    45,    46,    47,    48,    83,    84,    49,    50,
      75,    85,    86,    51,    52,    87,    74,    90,    73,   146,
      69,    71,   137,   138,   139,   140,   141,   126,    68,    74,
      68,    74,   128,    76,   109,   129,    30,    73,    88,   142,
      38,   113,   150,    90,   111,    90,   136,   111,   111,   136,
     142,    68,   119,   119,    68,    64,    68,    94,   109,   111,
      64,   109,    97,    97,    97,    98,    98,    99,    99,   100,
     100,   100,   100,   101,   101,   102,   103,   104,   105,   106,
     111,   109,   112,    64,    73,    74,   137,    89,   141,    53,
     134,    64,   109,    70,    70,   109,   142,    67,   150,    90,
      68,    68,    68,    68,    68,    72,    97,    68,    74,    70,
      88,    70,    73,   137,   139,    70,    70,   111,    90,   150,
     142,   142,   142,   138,   109,   108,   137,    68,   150,    90,
      14,    73,    74,    90,    68,   150,   142,    73,   142,    68,
     142
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    91,    92,    92,    92,    92,    93,    93,    93,    93,
      93,    93,    93,    93,    93,    93,    94,    94,    95,    95,
      95,    95,    95,    95,    96,    96,    96,    96,    96,    96,
      97,    97,    98,    98,    98,    98,    99,    99,    99,   100,
     100,   100,   101,   101,   101,   101,   101,   102,   102,   102,
     103,   103,   104,   104,   105,   105,   106,   106,   107,   107,
     108,   108,   109,   109,   110,   110,   110,   110,   110,   110,
     110,   110,   110,   110,   110,   111,   111,   112,   113,   113,
     114,   114,   114,   114,   114,   114,   114,   114,   115,   115,
     116,   116,   117,   117,   117,   117,   118,   118,   118,   118,
     118,   118,   118,   118,   118,   118,   118,   118,   118,   119,
     119,   119,   119,   120,   120,   120,   120,   120,   121,   121,
     122,   122,   123,   124,   124,   124,   125,   126,   126,   127,
     127,   127,   127,   127,   127,   127,   127,   127,   128,   128,
     129,   129,   130,   130,   131,   131,   132,   132,   133,   133,
     134,   134,   135,   135,   136,   137,   137,   137,   138,   138,
     138,   138,   139,   140,   140,   141,   141,   142,   142,   142,
     142,   142,   142,   143,   143,   143,   144,   144,   145,   145,
     146,   146,   147,   147,   148,   148,   148,   149,   149,   149,
     149,   150,   150,   151,   151,   151,   151,   152,   152,   153,
     153,   154,   154,   155,   155
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     1,     1,     3,     1,     4,     3,     4,
       3,     3,     2,     2,     6,     7,     1,     3,     1,     2,
       2,     2,     2,     4,     1,     1,     1,     1,     1,     1,
       1,     4,     1,     3,     3,     3,     1,     3,     3,     1,
       3,     3,     1,     3,     3,     3,     3,     1,     3,     3,
       1,     3,     1,     3,     1,     3,     1,     3,     1,     3,
       1,     5,     1,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     1,     2,     3,
       1,     2,     1,     2,     1,     2,     1,     2,     1,     3,
       1,     3,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       2,     1,     2,     4,     5,     5,     6,     2,     1,     3,
       1,     3,     1,     1,     1,     1,     1,     1,     2,     1,
       3,     5,     6,     6,     5,     4,     3,     4,     1,     0,
       1,     0,     2,     3,     1,     2,     1,     3,     1,     3,
       2,     1,     1,     3,     1,     1,     3,     4,     1,     2,
       3,     4,     2,     1,     2,     3,     2,     1,     1,     1,
       1,     1,     1,     3,     4,     3,     2,     3,     1,     2,
       1,     1,     2,     1,     5,     7,     5,     5,     7,     9,
       8,     1,     0,     3,     2,     2,     3,     1,     2,     1,
       1,     3,     4,     1,     2
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 87 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("primary_expression -> IDENTIFIER\n"); }
#line 1784 "y.tab.c" /* yacc.c:1646  */
    break;

  case 3:
#line 88 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("primary_expression -> CONSTANT\n"); }
#line 1790 "y.tab.c" /* yacc.c:1646  */
    break;

  case 4:
#line 89 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("primary_expression -> STRING_LITERAL\n"); }
#line 1796 "y.tab.c" /* yacc.c:1646  */
    break;

  case 5:
#line 90 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("primary_expression -> (expression)\n"); }
#line 1802 "y.tab.c" /* yacc.c:1646  */
    break;

  case 6:
#line 94 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("postfix_expression -> primary_expression\n"); }
#line 1808 "y.tab.c" /* yacc.c:1646  */
    break;

  case 7:
#line 95 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("postfix_expression -> postfix_expression [expression]\n"); }
#line 1814 "y.tab.c" /* yacc.c:1646  */
    break;

  case 8:
#line 96 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("postfix_expression -> postfix_expression ()\n"); }
#line 1820 "y.tab.c" /* yacc.c:1646  */
    break;

  case 9:
#line 97 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("postfix_expression -> postfix_expression (argument_expression_list)\n"); }
#line 1826 "y.tab.c" /* yacc.c:1646  */
    break;

  case 10:
#line 98 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("postfix_expression -> postfix_expression . IDENTIFIER\n"); }
#line 1832 "y.tab.c" /* yacc.c:1646  */
    break;

  case 11:
#line 99 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("postfix_expression -> postfix_expression DEFERENCER IDENTIFIER\n"); }
#line 1838 "y.tab.c" /* yacc.c:1646  */
    break;

  case 12:
#line 100 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("postfix_expression -> postfix_expression INCREMENT\n"); }
#line 1844 "y.tab.c" /* yacc.c:1646  */
    break;

  case 13:
#line 101 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("postfix_expression -> postfix_expression DECREMENT\n"); }
#line 1850 "y.tab.c" /* yacc.c:1646  */
    break;

  case 14:
#line 102 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("postfix_expression -> (type_name) {initializer_list}\n"); }
#line 1856 "y.tab.c" /* yacc.c:1646  */
    break;

  case 15:
#line 103 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("postfix_expression -> (type_name) {initializer_list , }\n"); }
#line 1862 "y.tab.c" /* yacc.c:1646  */
    break;

  case 16:
#line 107 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("argument_expression_list -> assignment_expression\n"); }
#line 1868 "y.tab.c" /* yacc.c:1646  */
    break;

  case 17:
#line 108 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("argument_expression_list -> argument_expression_list , assignment_expression\n"); }
#line 1874 "y.tab.c" /* yacc.c:1646  */
    break;

  case 18:
#line 112 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("unary_expression -> postfix_expression\n"); }
#line 1880 "y.tab.c" /* yacc.c:1646  */
    break;

  case 19:
#line 113 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("unary_expression -> ++ unary_expression"); }
#line 1886 "y.tab.c" /* yacc.c:1646  */
    break;

  case 20:
#line 114 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("unary_expression -> -- unary_expression"); }
#line 1892 "y.tab.c" /* yacc.c:1646  */
    break;

  case 21:
#line 115 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("unary_expression -> unary_operator cast_expression"); }
#line 1898 "y.tab.c" /* yacc.c:1646  */
    break;

  case 22:
#line 116 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("unary_expression -> SIZEOF unary_expression"); }
#line 1904 "y.tab.c" /* yacc.c:1646  */
    break;

  case 23:
#line 117 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("unary_expression -> SIZEOF (type_name)"); }
#line 1910 "y.tab.c" /* yacc.c:1646  */
    break;

  case 24:
#line 121 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("unary_operator -> '&'\n"); }
#line 1916 "y.tab.c" /* yacc.c:1646  */
    break;

  case 25:
#line 122 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("unary_operator -> '*'\n"); }
#line 1922 "y.tab.c" /* yacc.c:1646  */
    break;

  case 26:
#line 123 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("unary_operator -> '+'\n"); }
#line 1928 "y.tab.c" /* yacc.c:1646  */
    break;

  case 27:
#line 124 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("unary_operator -> '-'\n"); }
#line 1934 "y.tab.c" /* yacc.c:1646  */
    break;

  case 28:
#line 125 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("unary_operator -> '~'\n"); }
#line 1940 "y.tab.c" /* yacc.c:1646  */
    break;

  case 29:
#line 126 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("unary_operator -> '!'\n"); }
#line 1946 "y.tab.c" /* yacc.c:1646  */
    break;

  case 30:
#line 130 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("cast_expression -> unary_expression\n"); }
#line 1952 "y.tab.c" /* yacc.c:1646  */
    break;

  case 31:
#line 131 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("cast_expression -> (type_name) cast_expression\n"); }
#line 1958 "y.tab.c" /* yacc.c:1646  */
    break;

  case 32:
#line 135 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("multiplicative_expression -> cast_expression\n"); }
#line 1964 "y.tab.c" /* yacc.c:1646  */
    break;

  case 33:
#line 136 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("multiplicative_expression -> multiplicative_expression * cast_expression\n"); }
#line 1970 "y.tab.c" /* yacc.c:1646  */
    break;

  case 34:
#line 137 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("multiplicative_expression -> multiplicative_expression / cast_expression\n"); }
#line 1976 "y.tab.c" /* yacc.c:1646  */
    break;

  case 35:
#line 138 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("multiplicative_expression -> multiplicative_expression %% cast_expression\n"); }
#line 1982 "y.tab.c" /* yacc.c:1646  */
    break;

  case 36:
#line 142 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("additive_expression -> multiplicative_expression\n"); }
#line 1988 "y.tab.c" /* yacc.c:1646  */
    break;

  case 37:
#line 143 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("additive_expression -> additive_expression + multiplicative_expression\n"); }
#line 1994 "y.tab.c" /* yacc.c:1646  */
    break;

  case 38:
#line 144 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("additive_expression -> additive_expression - multiplicative_expression\n"); }
#line 2000 "y.tab.c" /* yacc.c:1646  */
    break;

  case 39:
#line 148 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("shift_expression -> additive_expression\n"); }
#line 2006 "y.tab.c" /* yacc.c:1646  */
    break;

  case 40:
#line 149 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("shift_expression -> shift_expression << additive_expression\n"); }
#line 2012 "y.tab.c" /* yacc.c:1646  */
    break;

  case 41:
#line 150 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("shift_expression -> shift_expression >> additive_expression\n"); }
#line 2018 "y.tab.c" /* yacc.c:1646  */
    break;

  case 42:
#line 154 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("relational_expression -> shift_expression\n"); }
#line 2024 "y.tab.c" /* yacc.c:1646  */
    break;

  case 43:
#line 155 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("relational_expression -> relational_expression < shift_expression\n"); }
#line 2030 "y.tab.c" /* yacc.c:1646  */
    break;

  case 44:
#line 156 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("relational_expression -> relational_expression > shift_expression\n"); }
#line 2036 "y.tab.c" /* yacc.c:1646  */
    break;

  case 45:
#line 157 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("relational_expression -> relational_expression <= shift_expression\n"); }
#line 2042 "y.tab.c" /* yacc.c:1646  */
    break;

  case 46:
#line 158 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("relational_expression -> relational_expression >= shift_expression\n"); }
#line 2048 "y.tab.c" /* yacc.c:1646  */
    break;

  case 47:
#line 162 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("equality_expression -> relational_expression\n"); }
#line 2054 "y.tab.c" /* yacc.c:1646  */
    break;

  case 48:
#line 163 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("equality_expression -> equality_expression == relational_expression\n"); }
#line 2060 "y.tab.c" /* yacc.c:1646  */
    break;

  case 49:
#line 164 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("equality_expression -> equality_expression != relational_expression\n"); }
#line 2066 "y.tab.c" /* yacc.c:1646  */
    break;

  case 50:
#line 168 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("AND_expression -> equality_expression\n"); }
#line 2072 "y.tab.c" /* yacc.c:1646  */
    break;

  case 51:
#line 169 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("AND_expression -> AND_expression & equality_expression\n"); }
#line 2078 "y.tab.c" /* yacc.c:1646  */
    break;

  case 52:
#line 173 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("exclusive_OR_expression -> AND_expression\n"); }
#line 2084 "y.tab.c" /* yacc.c:1646  */
    break;

  case 53:
#line 174 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("exclusive_OR_expression -> exclusive_OR_expression ^ AND_expression\n"); }
#line 2090 "y.tab.c" /* yacc.c:1646  */
    break;

  case 54:
#line 178 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("inclusive_OR_expression -> exclusive_OR_expression\n"); }
#line 2096 "y.tab.c" /* yacc.c:1646  */
    break;

  case 55:
#line 179 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("inclusive_OR_expression -> inclusive_OR_expression | exclusive_OR_expression\n"); }
#line 2102 "y.tab.c" /* yacc.c:1646  */
    break;

  case 56:
#line 183 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("logical_AND_expression -> inclusive_OR_expression\n"); }
#line 2108 "y.tab.c" /* yacc.c:1646  */
    break;

  case 57:
#line 184 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("logical_AND_expression -> logical_AND_expression & inclusive_OR_expression\n"); }
#line 2114 "y.tab.c" /* yacc.c:1646  */
    break;

  case 58:
#line 188 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("logical_OR_expression -> logical_AND_expression\n"); }
#line 2120 "y.tab.c" /* yacc.c:1646  */
    break;

  case 59:
#line 189 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("logical_OR_expression -> logical_OR_expression | logical_AND_expression\n"); }
#line 2126 "y.tab.c" /* yacc.c:1646  */
    break;

  case 60:
#line 193 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("conditional_expression -> logical_OR_expression\n"); }
#line 2132 "y.tab.c" /* yacc.c:1646  */
    break;

  case 61:
#line 194 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("conditional_expression -> logical_OR_expression ? expression : conditional_expression\n"); }
#line 2138 "y.tab.c" /* yacc.c:1646  */
    break;

  case 62:
#line 198 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_expression -> conditional_expression\n"); }
#line 2144 "y.tab.c" /* yacc.c:1646  */
    break;

  case 63:
#line 199 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_expression -> unary_expression assignment_operator assignment_expression\n"); }
#line 2150 "y.tab.c" /* yacc.c:1646  */
    break;

  case 64:
#line 203 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_operator -> '='\n"); }
#line 2156 "y.tab.c" /* yacc.c:1646  */
    break;

  case 65:
#line 204 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_operator -> '*='\n"); }
#line 2162 "y.tab.c" /* yacc.c:1646  */
    break;

  case 66:
#line 205 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_operator -> '/='\n"); }
#line 2168 "y.tab.c" /* yacc.c:1646  */
    break;

  case 67:
#line 206 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_operator -> '%%='\n"); }
#line 2174 "y.tab.c" /* yacc.c:1646  */
    break;

  case 68:
#line 207 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_operator -> '+='\n"); }
#line 2180 "y.tab.c" /* yacc.c:1646  */
    break;

  case 69:
#line 208 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_operator -> '-='\n"); }
#line 2186 "y.tab.c" /* yacc.c:1646  */
    break;

  case 70:
#line 209 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_operator -> '<<='\n"); }
#line 2192 "y.tab.c" /* yacc.c:1646  */
    break;

  case 71:
#line 210 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_operator -> '>>='\n"); }
#line 2198 "y.tab.c" /* yacc.c:1646  */
    break;

  case 72:
#line 211 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_operator -> '&='\n"); }
#line 2204 "y.tab.c" /* yacc.c:1646  */
    break;

  case 73:
#line 212 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_operator -> '^='\n"); }
#line 2210 "y.tab.c" /* yacc.c:1646  */
    break;

  case 74:
#line 213 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_operator -> '|='\n"); }
#line 2216 "y.tab.c" /* yacc.c:1646  */
    break;

  case 75:
#line 217 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("expression -> assignment_expression\n"); }
#line 2222 "y.tab.c" /* yacc.c:1646  */
    break;

  case 76:
#line 218 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("expression -> expression , assignment_expression\n"); }
#line 2228 "y.tab.c" /* yacc.c:1646  */
    break;

  case 77:
#line 222 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("constant_expression -> conditional_expression\n"); }
#line 2234 "y.tab.c" /* yacc.c:1646  */
    break;

  case 78:
#line 228 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declaration -> declaration_specifiers\n"); }
#line 2240 "y.tab.c" /* yacc.c:1646  */
    break;

  case 79:
#line 229 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declaration -> declaration_specifiers init_declarator_list\n"); }
#line 2246 "y.tab.c" /* yacc.c:1646  */
    break;

  case 80:
#line 233 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declaration_specifiers -> storage_class_specifier\n"); }
#line 2252 "y.tab.c" /* yacc.c:1646  */
    break;

  case 81:
#line 234 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declaration_specifiers -> storage_class_specifier declaration_specifiers\n"); }
#line 2258 "y.tab.c" /* yacc.c:1646  */
    break;

  case 82:
#line 235 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declaration_specifiers -> type_specifier\n"); }
#line 2264 "y.tab.c" /* yacc.c:1646  */
    break;

  case 83:
#line 236 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declaration_specifiers -> type_specifier declaration_specifiers\n"); }
#line 2270 "y.tab.c" /* yacc.c:1646  */
    break;

  case 84:
#line 237 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declaration_specifiers -> type_qualifier\n"); }
#line 2276 "y.tab.c" /* yacc.c:1646  */
    break;

  case 85:
#line 238 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declaration_specifiers -> type_qualifier declaration_specifiers\n"); }
#line 2282 "y.tab.c" /* yacc.c:1646  */
    break;

  case 86:
#line 239 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declaration_specifiers -> function_specifier\n"); }
#line 2288 "y.tab.c" /* yacc.c:1646  */
    break;

  case 87:
#line 240 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declaration_specifiers -> function_specifier declaration_specifiers\n"); }
#line 2294 "y.tab.c" /* yacc.c:1646  */
    break;

  case 88:
#line 244 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("init_declarator_list -> init_declarator\n"); }
#line 2300 "y.tab.c" /* yacc.c:1646  */
    break;

  case 89:
#line 245 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("initializer_list , init_declarator\n"); }
#line 2306 "y.tab.c" /* yacc.c:1646  */
    break;

  case 90:
#line 249 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("init_declarator -> declarator\n"); }
#line 2312 "y.tab.c" /* yacc.c:1646  */
    break;

  case 91:
#line 250 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("init_declarator -> declarator = initializer"); }
#line 2318 "y.tab.c" /* yacc.c:1646  */
    break;

  case 92:
#line 254 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("storage_class_specifier -> EXTERN\n"); }
#line 2324 "y.tab.c" /* yacc.c:1646  */
    break;

  case 93:
#line 255 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("storage_class_specifier -> STATIC\n"); }
#line 2330 "y.tab.c" /* yacc.c:1646  */
    break;

  case 94:
#line 256 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("storage_class_specifier -> AUTO\n"); }
#line 2336 "y.tab.c" /* yacc.c:1646  */
    break;

  case 95:
#line 257 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("storage_class_specifier -> REGISTER\n"); }
#line 2342 "y.tab.c" /* yacc.c:1646  */
    break;

  case 96:
#line 261 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> VOID\n"); }
#line 2348 "y.tab.c" /* yacc.c:1646  */
    break;

  case 97:
#line 262 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> CHAR\n"); }
#line 2354 "y.tab.c" /* yacc.c:1646  */
    break;

  case 98:
#line 263 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> SHORT\n"); }
#line 2360 "y.tab.c" /* yacc.c:1646  */
    break;

  case 99:
#line 264 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> INT\n"); }
#line 2366 "y.tab.c" /* yacc.c:1646  */
    break;

  case 100:
#line 265 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> LONG\n"); }
#line 2372 "y.tab.c" /* yacc.c:1646  */
    break;

  case 101:
#line 266 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> FLOAT\n"); }
#line 2378 "y.tab.c" /* yacc.c:1646  */
    break;

  case 102:
#line 267 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> DOUBLE\n"); }
#line 2384 "y.tab.c" /* yacc.c:1646  */
    break;

  case 103:
#line 268 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> SIGNED\n"); }
#line 2390 "y.tab.c" /* yacc.c:1646  */
    break;

  case 104:
#line 269 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> UNSIGNED\n"); }
#line 2396 "y.tab.c" /* yacc.c:1646  */
    break;

  case 105:
#line 270 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> _BOOL\n"); }
#line 2402 "y.tab.c" /* yacc.c:1646  */
    break;

  case 106:
#line 271 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> _COMPLEX\n"); }
#line 2408 "y.tab.c" /* yacc.c:1646  */
    break;

  case 107:
#line 272 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> _IMAGINARY\n"); }
#line 2414 "y.tab.c" /* yacc.c:1646  */
    break;

  case 108:
#line 273 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_specifier -> enum_specifier\n"); }
#line 2420 "y.tab.c" /* yacc.c:1646  */
    break;

  case 109:
#line 277 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("specifier_qualifier_list -> type_specifier\n"); }
#line 2426 "y.tab.c" /* yacc.c:1646  */
    break;

  case 110:
#line 278 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("specifier_qualifier_list -> type_specifier specifier_qualifier_list\n"); }
#line 2432 "y.tab.c" /* yacc.c:1646  */
    break;

  case 111:
#line 279 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("specifier_qualifier_list -> type_qualifier\n"); }
#line 2438 "y.tab.c" /* yacc.c:1646  */
    break;

  case 112:
#line 280 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("specifier_qualifier_list -> type_qualifier specifier_qualifier_list\n"); }
#line 2444 "y.tab.c" /* yacc.c:1646  */
    break;

  case 113:
#line 284 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("enum_specifier -> ENUM { enumerator_list }\n"); }
#line 2450 "y.tab.c" /* yacc.c:1646  */
    break;

  case 114:
#line 285 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("enum_specifier -> ENUM IDENTIFIER { enumerator_list }\n"); }
#line 2456 "y.tab.c" /* yacc.c:1646  */
    break;

  case 115:
#line 286 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("enum_specifier -> ENUM { enumerator_list , }\n"); }
#line 2462 "y.tab.c" /* yacc.c:1646  */
    break;

  case 116:
#line 287 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("enum_specifier -> ENUM IDENTIFIER { enumerator_list , }\n"); }
#line 2468 "y.tab.c" /* yacc.c:1646  */
    break;

  case 117:
#line 288 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("enum_specifier -> ENUM IDENTIFIER\n"); }
#line 2474 "y.tab.c" /* yacc.c:1646  */
    break;

  case 118:
#line 292 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("enumerator_list -> enumerator\n"); }
#line 2480 "y.tab.c" /* yacc.c:1646  */
    break;

  case 119:
#line 293 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("enumerator_list -> enumerator_list , enumerator\n"); }
#line 2486 "y.tab.c" /* yacc.c:1646  */
    break;

  case 120:
#line 297 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("enumerator -> enumeration_constant\n"); }
#line 2492 "y.tab.c" /* yacc.c:1646  */
    break;

  case 121:
#line 298 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("enumerator -> enumeration_constant = constant_expression\n"); }
#line 2498 "y.tab.c" /* yacc.c:1646  */
    break;

  case 122:
#line 302 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("enumeration_constant -> IDENTIFIER\n"); }
#line 2504 "y.tab.c" /* yacc.c:1646  */
    break;

  case 123:
#line 306 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_qualifier -> CONST\n"); }
#line 2510 "y.tab.c" /* yacc.c:1646  */
    break;

  case 124:
#line 307 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_qualifier -> RESTRICT\n"); }
#line 2516 "y.tab.c" /* yacc.c:1646  */
    break;

  case 125:
#line 308 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_qualifier -> VOLATILE\n"); }
#line 2522 "y.tab.c" /* yacc.c:1646  */
    break;

  case 126:
#line 312 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("function_specifier -> INLINE\n"); }
#line 2528 "y.tab.c" /* yacc.c:1646  */
    break;

  case 127:
#line 316 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declarator -> direct_declarator\n"); }
#line 2534 "y.tab.c" /* yacc.c:1646  */
    break;

  case 128:
#line 317 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declarator -> pointer direct_declarator\n"); }
#line 2540 "y.tab.c" /* yacc.c:1646  */
    break;

  case 129:
#line 321 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("direct_declarator -> IDENTIFIER\n"); }
#line 2546 "y.tab.c" /* yacc.c:1646  */
    break;

  case 130:
#line 322 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("direct_declarator -> (declarator)\n"); }
#line 2552 "y.tab.c" /* yacc.c:1646  */
    break;

  case 131:
#line 323 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("direct_declarator -> direct_declarator [type_qualifier_list_opt assignment_expression_opt]\n"); }
#line 2558 "y.tab.c" /* yacc.c:1646  */
    break;

  case 132:
#line 324 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("direct_declarator -> direct_declarator [STATIC type_qualifier_list_opt assignment_expression]\n"); }
#line 2564 "y.tab.c" /* yacc.c:1646  */
    break;

  case 133:
#line 325 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("direct_declarator -> direct_declarator [type_qualifier_list STATIC assignment_expression]\n"); }
#line 2570 "y.tab.c" /* yacc.c:1646  */
    break;

  case 134:
#line 326 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("direct_declarator -> direct_declarator [type_qualifier_list_opt * ]\n"); }
#line 2576 "y.tab.c" /* yacc.c:1646  */
    break;

  case 135:
#line 327 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("direct_declarator -> direct_declarator (parameter_type_list)\n"); }
#line 2582 "y.tab.c" /* yacc.c:1646  */
    break;

  case 136:
#line 328 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("direct_declarator -> direct_declarator ()\n"); }
#line 2588 "y.tab.c" /* yacc.c:1646  */
    break;

  case 137:
#line 329 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("direct_declarator -> (identifier_list)"); }
#line 2594 "y.tab.c" /* yacc.c:1646  */
    break;

  case 138:
#line 333 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_qualifier_list_opt -> type_qualifier_list\n"); }
#line 2600 "y.tab.c" /* yacc.c:1646  */
    break;

  case 139:
#line 334 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_qualifier_list_opt -> EPSILON {epsilon transition}\n"); }
#line 2606 "y.tab.c" /* yacc.c:1646  */
    break;

  case 140:
#line 338 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_expression_opt -> assignment_expression\n"); }
#line 2612 "y.tab.c" /* yacc.c:1646  */
    break;

  case 141:
#line 339 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("assignment_expression_opt -> EPSILON {epsilon transition}\n"); }
#line 2618 "y.tab.c" /* yacc.c:1646  */
    break;

  case 142:
#line 343 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("pointer -> * type_qualifier_list_opt\n"); }
#line 2624 "y.tab.c" /* yacc.c:1646  */
    break;

  case 143:
#line 344 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("pointer -> * type_qualifier_list_opt pointer\n"); }
#line 2630 "y.tab.c" /* yacc.c:1646  */
    break;

  case 144:
#line 348 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_qualifier_list -> type_qualifier\n"); }
#line 2636 "y.tab.c" /* yacc.c:1646  */
    break;

  case 145:
#line 349 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_qualifier_list -> type_qualifier\n"); }
#line 2642 "y.tab.c" /* yacc.c:1646  */
    break;

  case 146:
#line 353 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("parameter_type_list -> parameter_list\n"); }
#line 2648 "y.tab.c" /* yacc.c:1646  */
    break;

  case 147:
#line 354 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("parameter_type_list -> parameter_list , THREE_DOTS\n"); }
#line 2654 "y.tab.c" /* yacc.c:1646  */
    break;

  case 148:
#line 358 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("parameter_list -> parameter_declaration\n"); }
#line 2660 "y.tab.c" /* yacc.c:1646  */
    break;

  case 149:
#line 359 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("parameter_list -> parameter_list , parameter_declaration\n"); }
#line 2666 "y.tab.c" /* yacc.c:1646  */
    break;

  case 150:
#line 363 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("parameter_declaration -> declaration_specifiers declarator\n"); }
#line 2672 "y.tab.c" /* yacc.c:1646  */
    break;

  case 151:
#line 364 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("parameter_declaration -> declaration_specifiers\n"); }
#line 2678 "y.tab.c" /* yacc.c:1646  */
    break;

  case 152:
#line 368 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("identifier_list -> IDENTIFIER\n"); }
#line 2684 "y.tab.c" /* yacc.c:1646  */
    break;

  case 153:
#line 369 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("identifier_list -> identifier_list , IDENTIFIER\n"); }
#line 2690 "y.tab.c" /* yacc.c:1646  */
    break;

  case 154:
#line 373 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("type_name -> specifier_qualifier_list\n"); }
#line 2696 "y.tab.c" /* yacc.c:1646  */
    break;

  case 155:
#line 377 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("initializer -> assignment_expression\n"); }
#line 2702 "y.tab.c" /* yacc.c:1646  */
    break;

  case 156:
#line 378 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("initializer -> {initializer_list}\n"); }
#line 2708 "y.tab.c" /* yacc.c:1646  */
    break;

  case 157:
#line 379 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("initializer -> {initializer_list , }\n"); }
#line 2714 "y.tab.c" /* yacc.c:1646  */
    break;

  case 158:
#line 383 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("initializer_list -> initializer\n"); }
#line 2720 "y.tab.c" /* yacc.c:1646  */
    break;

  case 159:
#line 384 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("initializer_list -> designation initializer\n"); }
#line 2726 "y.tab.c" /* yacc.c:1646  */
    break;

  case 160:
#line 385 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("initializer_list -> initializer_list , initializer\n"); }
#line 2732 "y.tab.c" /* yacc.c:1646  */
    break;

  case 161:
#line 386 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("initializer_list -> initializer_list , designation initializer\n"); }
#line 2738 "y.tab.c" /* yacc.c:1646  */
    break;

  case 162:
#line 390 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("designation -> designator_list = \n"); }
#line 2744 "y.tab.c" /* yacc.c:1646  */
    break;

  case 163:
#line 394 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("designator_list -> designator\n"); }
#line 2750 "y.tab.c" /* yacc.c:1646  */
    break;

  case 164:
#line 395 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("designator_list -> designator_list designator\n"); }
#line 2756 "y.tab.c" /* yacc.c:1646  */
    break;

  case 165:
#line 399 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("designator -> [constant_expression]\n"); }
#line 2762 "y.tab.c" /* yacc.c:1646  */
    break;

  case 166:
#line 400 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("designator -> . IDENTIFIER\n"); }
#line 2768 "y.tab.c" /* yacc.c:1646  */
    break;

  case 167:
#line 406 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("statement -> labeled_statement\n"); }
#line 2774 "y.tab.c" /* yacc.c:1646  */
    break;

  case 168:
#line 407 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("statement -> compound_statement\n"); }
#line 2780 "y.tab.c" /* yacc.c:1646  */
    break;

  case 169:
#line 408 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("statement -> expression_statement\n"); }
#line 2786 "y.tab.c" /* yacc.c:1646  */
    break;

  case 170:
#line 409 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("statement -> selection_statement\n"); }
#line 2792 "y.tab.c" /* yacc.c:1646  */
    break;

  case 171:
#line 410 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("statement -> iteration_statement\n"); }
#line 2798 "y.tab.c" /* yacc.c:1646  */
    break;

  case 172:
#line 411 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("statement -> jump_statement\n"); }
#line 2804 "y.tab.c" /* yacc.c:1646  */
    break;

  case 173:
#line 415 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("labeled_statement -> IDENTIFIER : statement\n"); }
#line 2810 "y.tab.c" /* yacc.c:1646  */
    break;

  case 174:
#line 416 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("labeled_statement -> CASE constant_expression : statement\n"); }
#line 2816 "y.tab.c" /* yacc.c:1646  */
    break;

  case 175:
#line 417 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("labeled_statement -> DEFAULT : statement\n"); }
#line 2822 "y.tab.c" /* yacc.c:1646  */
    break;

  case 176:
#line 421 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("compound_statement -> { }\n"); }
#line 2828 "y.tab.c" /* yacc.c:1646  */
    break;

  case 177:
#line 422 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("compound_statement -> {block_item_list}\n"); }
#line 2834 "y.tab.c" /* yacc.c:1646  */
    break;

  case 178:
#line 426 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("block_item_list -> block_item\n"); }
#line 2840 "y.tab.c" /* yacc.c:1646  */
    break;

  case 179:
#line 427 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("block_item_list -> block_item_list block_item\n"); }
#line 2846 "y.tab.c" /* yacc.c:1646  */
    break;

  case 180:
#line 431 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("block_item -> declaration\n"); }
#line 2852 "y.tab.c" /* yacc.c:1646  */
    break;

  case 181:
#line 432 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("block_item -> statement\n"); }
#line 2858 "y.tab.c" /* yacc.c:1646  */
    break;

  case 182:
#line 436 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("expression_statement -> expression ;\n"); }
#line 2864 "y.tab.c" /* yacc.c:1646  */
    break;

  case 183:
#line 437 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("expression_statement -> ;\n"); }
#line 2870 "y.tab.c" /* yacc.c:1646  */
    break;

  case 184:
#line 441 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("selection_statement -> IF (expression) statement\n"); }
#line 2876 "y.tab.c" /* yacc.c:1646  */
    break;

  case 185:
#line 442 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("selection_statement -> IF (expression) statement ELSE statement\n"); }
#line 2882 "y.tab.c" /* yacc.c:1646  */
    break;

  case 186:
#line 443 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("selection_statement -> (expression) statement\n"); }
#line 2888 "y.tab.c" /* yacc.c:1646  */
    break;

  case 187:
#line 447 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("iteration_statement -> WHILE (expression) statement\n"); }
#line 2894 "y.tab.c" /* yacc.c:1646  */
    break;

  case 188:
#line 448 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("iteration_statement -> DO statement WHILE (expression) ;\n"); }
#line 2900 "y.tab.c" /* yacc.c:1646  */
    break;

  case 189:
#line 449 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("iteration_statement -> FOR (expression_opt ; expression_opt ; expression_opt) statement\n"); }
#line 2906 "y.tab.c" /* yacc.c:1646  */
    break;

  case 190:
#line 450 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("iteration_statement -> FOR (declaration expression_opt ; expression_opt) statement\n"); }
#line 2912 "y.tab.c" /* yacc.c:1646  */
    break;

  case 191:
#line 454 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("expression_opt -> expression\n"); }
#line 2918 "y.tab.c" /* yacc.c:1646  */
    break;

  case 192:
#line 455 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("expression_opt -> EPSILON {epsilon transition}\n"); }
#line 2924 "y.tab.c" /* yacc.c:1646  */
    break;

  case 193:
#line 459 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("jump_statement -> GOTO IDENTIFIER ;\n"); }
#line 2930 "y.tab.c" /* yacc.c:1646  */
    break;

  case 194:
#line 460 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("jump_statement -> CONTINUE ;\n"); }
#line 2936 "y.tab.c" /* yacc.c:1646  */
    break;

  case 195:
#line 461 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("jump_statement -> BREAK ;\n"); }
#line 2942 "y.tab.c" /* yacc.c:1646  */
    break;

  case 196:
#line 462 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("jump_statement -> RETURN expression_opt ;\n"); }
#line 2948 "y.tab.c" /* yacc.c:1646  */
    break;

  case 197:
#line 468 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("translation_unit -> external_declaration\n"); }
#line 2954 "y.tab.c" /* yacc.c:1646  */
    break;

  case 198:
#line 469 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("translation_unit -> translation_unit external_declaration\n"); }
#line 2960 "y.tab.c" /* yacc.c:1646  */
    break;

  case 199:
#line 473 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("external_declaration -> function_definition\n"); }
#line 2966 "y.tab.c" /* yacc.c:1646  */
    break;

  case 200:
#line 474 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("external_declaration -> declaration\n"); }
#line 2972 "y.tab.c" /* yacc.c:1646  */
    break;

  case 201:
#line 478 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("function_definition -> declaration_specifiers declaration compound_statement\n"); }
#line 2978 "y.tab.c" /* yacc.c:1646  */
    break;

  case 202:
#line 479 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("function_definition -> declaration_specifiers declarator declaration_list compound_statement\n"); }
#line 2984 "y.tab.c" /* yacc.c:1646  */
    break;

  case 203:
#line 483 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declaration_list -> declaration\n"); }
#line 2990 "y.tab.c" /* yacc.c:1646  */
    break;

  case 204:
#line 484 "ass4_13CS30016.y" /* yacc.c:1646  */
    { printf("declaration_list -> declaration_list delcaration\n"); }
#line 2996 "y.tab.c" /* yacc.c:1646  */
    break;


#line 3000 "y.tab.c" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 487 "ass4_13CS30016.y" /* yacc.c:1906  */


void yyerror(const char* s) {
	printf("%s\n", s);
}
