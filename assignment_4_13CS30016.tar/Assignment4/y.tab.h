/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    _SINGLECOMMENT = 258,
    _MULTICOMMENT = 259,
    AUTO = 260,
    BREAK = 261,
    CASE = 262,
    CHAR = 263,
    CONST = 264,
    CONTINUE = 265,
    DEFAULT = 266,
    DO = 267,
    DOUBLE = 268,
    ELSE = 269,
    ENUM = 270,
    EXTERN = 271,
    FLOAT = 272,
    FOR = 273,
    GOTO = 274,
    IF = 275,
    INLINE = 276,
    INT = 277,
    LONG = 278,
    REGISTER = 279,
    RESTRICT = 280,
    RETURN = 281,
    SHORT = 282,
    SIGNED = 283,
    SIZEOF = 284,
    STATIC = 285,
    STRUCT = 286,
    SWITCH = 287,
    TYPEDEF = 288,
    UNION = 289,
    UNSIGNED = 290,
    VOID = 291,
    VOLATILE = 292,
    WHILE = 293,
    _BOOL = 294,
    _COMPLEX = 295,
    _IMAGINARY = 296,
    DEFERENCER = 297,
    INCREMENT = 298,
    DECREMENT = 299,
    SHIFT_LEFT = 300,
    SHIFT_RIGHT = 301,
    LESS_EQUAL = 302,
    GREATER_EQUAL = 303,
    EQUAL_TO = 304,
    NOT_EQUAL = 305,
    AND = 306,
    OR = 307,
    THREE_DOTS = 308,
    MULT_ASSIGN = 309,
    DIV_ASSIGN = 310,
    MOD_ASSIGN = 311,
    ADD_ASSIGN = 312,
    SUB_ASSIGN = 313,
    SHIFT_LEFT_ASSIGN = 314,
    SHIFT_RIGHT_ASSIGN = 315,
    AND_ASSIGN = 316,
    XOR_ASSIGN = 317,
    OR_ASSIGN = 318,
    IDENTIFIER = 319,
    CONSTANT = 320,
    STRING_LITERAL = 321
  };
#endif
/* Tokens.  */
#define _SINGLECOMMENT 258
#define _MULTICOMMENT 259
#define AUTO 260
#define BREAK 261
#define CASE 262
#define CHAR 263
#define CONST 264
#define CONTINUE 265
#define DEFAULT 266
#define DO 267
#define DOUBLE 268
#define ELSE 269
#define ENUM 270
#define EXTERN 271
#define FLOAT 272
#define FOR 273
#define GOTO 274
#define IF 275
#define INLINE 276
#define INT 277
#define LONG 278
#define REGISTER 279
#define RESTRICT 280
#define RETURN 281
#define SHORT 282
#define SIGNED 283
#define SIZEOF 284
#define STATIC 285
#define STRUCT 286
#define SWITCH 287
#define TYPEDEF 288
#define UNION 289
#define UNSIGNED 290
#define VOID 291
#define VOLATILE 292
#define WHILE 293
#define _BOOL 294
#define _COMPLEX 295
#define _IMAGINARY 296
#define DEFERENCER 297
#define INCREMENT 298
#define DECREMENT 299
#define SHIFT_LEFT 300
#define SHIFT_RIGHT 301
#define LESS_EQUAL 302
#define GREATER_EQUAL 303
#define EQUAL_TO 304
#define NOT_EQUAL 305
#define AND 306
#define OR 307
#define THREE_DOTS 308
#define MULT_ASSIGN 309
#define DIV_ASSIGN 310
#define MOD_ASSIGN 311
#define ADD_ASSIGN 312
#define SUB_ASSIGN 313
#define SHIFT_LEFT_ASSIGN 314
#define SHIFT_RIGHT_ASSIGN 315
#define AND_ASSIGN 316
#define XOR_ASSIGN 317
#define OR_ASSIGN 318
#define IDENTIFIER 319
#define CONSTANT 320
#define STRING_LITERAL 321

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 7 "ass4_13CS30016.y" /* yacc.c:1909  */

	int t;
	float p;
	char *c;

#line 192 "y.tab.h" /* yacc.c:1909  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
