#include "y.tab.h"
#include <stdio.h>
extern int yylex();
extern char *yytext;
int main(){
	printf("\nPRINTING REDUCTIONS DONE BY THE PARSER :\n\n");
	int t = yyparse();
	if(t)
		printf("FAILURE\n");
	else
		printf("SUCCESSFUL\n");
	return 0;
}
