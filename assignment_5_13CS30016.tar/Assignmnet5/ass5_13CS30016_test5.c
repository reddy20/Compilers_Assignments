// dealing with bitwise oprations, logical operations, control constructs
// ternary operator


void main()
{
	int a, b, c;
	a = 4;
	b = 5;
	c = 6;

	int flag = 1;
	int ans1 = a << 2;
	int ans2;

	if(ans1 != 0 && ans1 < 10)
	{
		ans1 = ~ans1;
		ans1 = ans1 & ans1;
	}

	ans1 = ans1 == 0 ? ans1 + 1 : ans1 - 1;

	if(ans1 < 5)
	{
		ans1++;
	}
	else
	{
		ans2 = ans1 + ans1;
	}

	ans2++;
}