/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    _SINGLECOMMENT = 258,
    _MULTICOMMENT = 259,
    AUTO_KEYWORD = 260,
    BREAK_KEYWORD = 261,
    CASE_KEYWORD = 262,
    CHAR_KEYWORD = 263,
    CONST_KEYWORD = 264,
    CONTINUE_KEYWORD = 265,
    DEFAULT_KEYWORD = 266,
    DO_KEYWORD = 267,
    DOUBLE_KEYWORD = 268,
    ELSE_KEYWORD = 269,
    ENUM_KEYWORD = 270,
    EXTERN_KEYWORD = 271,
    FLOAT_KEYWORD = 272,
    FOR_KEYWORD = 273,
    GOTO_KEYWORD = 274,
    IF_KEYWORD = 275,
    INLINE_KEYWORD = 276,
    INT_KEYWORD = 277,
    LONG_KEYWORD = 278,
    REGISTER_KEYWORD = 279,
    RESTRICT_KEYWORD = 280,
    RETURN_KEYWORD = 281,
    SHORT_KEYWORD = 282,
    SIGNED_KEYWORD = 283,
    SIZEOF_KEYWORD = 284,
    STATIC_KEYWORD = 285,
    STRUCT_KEYWORD = 286,
    SWITCH_KEYWORD = 287,
    TYPEDEF_KEYWORD = 288,
    UNION_KEYWORD = 289,
    UNSIGNED_KEYWORD = 290,
    VOID_KEYWORD = 291,
    VOLATILE_KEYWORD = 292,
    WHILE_KEYWORD = 293,
    _BOOL_KEYWORD = 294,
    _COMPLEX_KEYWORD = 295,
    _IMAGINARY_KEYWORD = 296,
    ARROW = 297,
    INCREMENT_OP = 298,
    DECREMENT_OP = 299,
    SHIFT_LEFT = 300,
    SHIFT_RIGHT = 301,
    LESS_EQUAL = 302,
    GREATER_EQUAL = 303,
    EQUALITY_CHECK = 304,
    NOT_EQUAL = 305,
    AND_OP = 306,
    OR_OP = 307,
    ELLIPSES = 308,
    MULT_EQUAL = 309,
    DIV_EQUAL = 310,
    MOD_EQUAL = 311,
    ADD_EQUAL = 312,
    SUB_EQUAL = 313,
    SHIFT_LEFT_EQUAL = 314,
    SHIFT_RIGHT_EQUAL = 315,
    AND_EQUAL = 316,
    XOR_EQUAL = 317,
    OR_EQUAL = 318,
    STRING_LITERAL = 319,
    IDENTIFIER = 320,
    INT_CONSTANT = 321,
    FLOAT_CONSTANT = 322,
    CHAR_CONSTANT = 323,
    IFC = 324
  };
#endif
/* Tokens.  */
#define _SINGLECOMMENT 258
#define _MULTICOMMENT 259
#define AUTO_KEYWORD 260
#define BREAK_KEYWORD 261
#define CASE_KEYWORD 262
#define CHAR_KEYWORD 263
#define CONST_KEYWORD 264
#define CONTINUE_KEYWORD 265
#define DEFAULT_KEYWORD 266
#define DO_KEYWORD 267
#define DOUBLE_KEYWORD 268
#define ELSE_KEYWORD 269
#define ENUM_KEYWORD 270
#define EXTERN_KEYWORD 271
#define FLOAT_KEYWORD 272
#define FOR_KEYWORD 273
#define GOTO_KEYWORD 274
#define IF_KEYWORD 275
#define INLINE_KEYWORD 276
#define INT_KEYWORD 277
#define LONG_KEYWORD 278
#define REGISTER_KEYWORD 279
#define RESTRICT_KEYWORD 280
#define RETURN_KEYWORD 281
#define SHORT_KEYWORD 282
#define SIGNED_KEYWORD 283
#define SIZEOF_KEYWORD 284
#define STATIC_KEYWORD 285
#define STRUCT_KEYWORD 286
#define SWITCH_KEYWORD 287
#define TYPEDEF_KEYWORD 288
#define UNION_KEYWORD 289
#define UNSIGNED_KEYWORD 290
#define VOID_KEYWORD 291
#define VOLATILE_KEYWORD 292
#define WHILE_KEYWORD 293
#define _BOOL_KEYWORD 294
#define _COMPLEX_KEYWORD 295
#define _IMAGINARY_KEYWORD 296
#define ARROW 297
#define INCREMENT_OP 298
#define DECREMENT_OP 299
#define SHIFT_LEFT 300
#define SHIFT_RIGHT 301
#define LESS_EQUAL 302
#define GREATER_EQUAL 303
#define EQUALITY_CHECK 304
#define NOT_EQUAL 305
#define AND_OP 306
#define OR_OP 307
#define ELLIPSES 308
#define MULT_EQUAL 309
#define DIV_EQUAL 310
#define MOD_EQUAL 311
#define ADD_EQUAL 312
#define SUB_EQUAL 313
#define SHIFT_LEFT_EQUAL 314
#define SHIFT_RIGHT_EQUAL 315
#define AND_EQUAL 316
#define XOR_EQUAL 317
#define OR_EQUAL 318
#define STRING_LITERAL 319
#define IDENTIFIER 320
#define INT_CONSTANT 321
#define FLOAT_CONSTANT 322
#define CHAR_CONSTANT 323
#define IFC 324

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 11 "ass5_13CS30016.y" /* yacc.c:1909  */

    char charval;                           // used to represent a character value
    int intval;                             // used to represent an integer value
    double doubleval;                       // used to represent a double precision value
    string *strval;                         // pointer to string
    void* ptr;                              // used to represent a pointer
    primtype p_type;                        // an enum of various supported primitive (basic) data types
    opcode opp;                             // an enum of various supported operators
    symtype *typeinfo;                      // stores the type-expression for a variable
    symtab_entry *symdat;                   // pointer to a row (entry) in the symbol table
    exprr *exp_info;                        // stores the type, value and other various attributes of expressions and statements
    param *prm;                             // stores the name and datatype of a parameter
    vector<param*> *prm_list;               // is a list of parameters
    declr *dec_info;                        // stores the necessary attributes for declaration statements 
    vector<declr*> *ldec;                   // is a list of declarators

#line 209 "y.tab.h" /* yacc.c:1909  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
