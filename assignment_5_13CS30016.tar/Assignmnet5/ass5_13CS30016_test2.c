/* 
	TESTFILE 2 : To check the made compliler
	Name : K Rajassekhar Reddy
	Roll No. 13CS30016
*/

// This is how comments are handled 


double **function ()
{
    double **x;
    double *b, *c;

    double s = 5;

    s = s + 5.5;
    s = s * 10.0;

    *b = s;

    return a;
}

char f1(int *a)
{
    int b = 12, c = 3;

     c = c*c;
    *a = b+c;
}



int main()
{
    
    double c = 4.4, b = 6.9, *e;

    *e = b;

    int a = 5;
    f1(&a)

    return a+ b +c;

}
