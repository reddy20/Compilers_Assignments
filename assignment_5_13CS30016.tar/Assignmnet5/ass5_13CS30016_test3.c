// Dealing with various types of loops and returning pointers
// Also global variable declarations

int a, aa;
int fn(int g)
{
	g = g * g;
	return g;
}
char *fns(int a)
{
	int p, s = 0, s1 = 10;
	p = 5;
	char *ptr;
	for( ; s < 10 ; s++)
	{
		p++;
	}
	s1 = 5;
	int c1, c2;
	c1 = 5;
	c2  = 6;
	while(s1 >= 0)
	{
		s1--;
		if(a > b){
			count = count * (c1 & c2);
		}
		c1++;
		c2--;
	}
	s = 0;
	do
	{
		k = fn(s);
		s = s + 2;	
	}while(s < 10);
	return ptr;
}