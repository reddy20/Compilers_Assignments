/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* Copy the first part of user declarations.  */
#line 1 "ass5_13CS30016.y" /* yacc.c:339  */
 
#include <string>
#include <iostream>

#include "ass5_13CS30016_translator.h"
extern int yylex();
void yyerror(string s);


#line 76 "y.tab.c" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "y.tab.h".  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    _SINGLECOMMENT = 258,
    _MULTICOMMENT = 259,
    AUTO_KEYWORD = 260,
    BREAK_KEYWORD = 261,
    CASE_KEYWORD = 262,
    CHAR_KEYWORD = 263,
    CONST_KEYWORD = 264,
    CONTINUE_KEYWORD = 265,
    DEFAULT_KEYWORD = 266,
    DO_KEYWORD = 267,
    DOUBLE_KEYWORD = 268,
    ELSE_KEYWORD = 269,
    ENUM_KEYWORD = 270,
    EXTERN_KEYWORD = 271,
    FLOAT_KEYWORD = 272,
    FOR_KEYWORD = 273,
    GOTO_KEYWORD = 274,
    IF_KEYWORD = 275,
    INLINE_KEYWORD = 276,
    INT_KEYWORD = 277,
    LONG_KEYWORD = 278,
    REGISTER_KEYWORD = 279,
    RESTRICT_KEYWORD = 280,
    RETURN_KEYWORD = 281,
    SHORT_KEYWORD = 282,
    SIGNED_KEYWORD = 283,
    SIZEOF_KEYWORD = 284,
    STATIC_KEYWORD = 285,
    STRUCT_KEYWORD = 286,
    SWITCH_KEYWORD = 287,
    TYPEDEF_KEYWORD = 288,
    UNION_KEYWORD = 289,
    UNSIGNED_KEYWORD = 290,
    VOID_KEYWORD = 291,
    VOLATILE_KEYWORD = 292,
    WHILE_KEYWORD = 293,
    _BOOL_KEYWORD = 294,
    _COMPLEX_KEYWORD = 295,
    _IMAGINARY_KEYWORD = 296,
    ARROW = 297,
    INCREMENT_OP = 298,
    DECREMENT_OP = 299,
    SHIFT_LEFT = 300,
    SHIFT_RIGHT = 301,
    LESS_EQUAL = 302,
    GREATER_EQUAL = 303,
    EQUALITY_CHECK = 304,
    NOT_EQUAL = 305,
    AND_OP = 306,
    OR_OP = 307,
    ELLIPSES = 308,
    MULT_EQUAL = 309,
    DIV_EQUAL = 310,
    MOD_EQUAL = 311,
    ADD_EQUAL = 312,
    SUB_EQUAL = 313,
    SHIFT_LEFT_EQUAL = 314,
    SHIFT_RIGHT_EQUAL = 315,
    AND_EQUAL = 316,
    XOR_EQUAL = 317,
    OR_EQUAL = 318,
    STRING_LITERAL = 319,
    IDENTIFIER = 320,
    INT_CONSTANT = 321,
    FLOAT_CONSTANT = 322,
    CHAR_CONSTANT = 323,
    IFC = 324
  };
#endif
/* Tokens.  */
#define _SINGLECOMMENT 258
#define _MULTICOMMENT 259
#define AUTO_KEYWORD 260
#define BREAK_KEYWORD 261
#define CASE_KEYWORD 262
#define CHAR_KEYWORD 263
#define CONST_KEYWORD 264
#define CONTINUE_KEYWORD 265
#define DEFAULT_KEYWORD 266
#define DO_KEYWORD 267
#define DOUBLE_KEYWORD 268
#define ELSE_KEYWORD 269
#define ENUM_KEYWORD 270
#define EXTERN_KEYWORD 271
#define FLOAT_KEYWORD 272
#define FOR_KEYWORD 273
#define GOTO_KEYWORD 274
#define IF_KEYWORD 275
#define INLINE_KEYWORD 276
#define INT_KEYWORD 277
#define LONG_KEYWORD 278
#define REGISTER_KEYWORD 279
#define RESTRICT_KEYWORD 280
#define RETURN_KEYWORD 281
#define SHORT_KEYWORD 282
#define SIGNED_KEYWORD 283
#define SIZEOF_KEYWORD 284
#define STATIC_KEYWORD 285
#define STRUCT_KEYWORD 286
#define SWITCH_KEYWORD 287
#define TYPEDEF_KEYWORD 288
#define UNION_KEYWORD 289
#define UNSIGNED_KEYWORD 290
#define VOID_KEYWORD 291
#define VOLATILE_KEYWORD 292
#define WHILE_KEYWORD 293
#define _BOOL_KEYWORD 294
#define _COMPLEX_KEYWORD 295
#define _IMAGINARY_KEYWORD 296
#define ARROW 297
#define INCREMENT_OP 298
#define DECREMENT_OP 299
#define SHIFT_LEFT 300
#define SHIFT_RIGHT 301
#define LESS_EQUAL 302
#define GREATER_EQUAL 303
#define EQUALITY_CHECK 304
#define NOT_EQUAL 305
#define AND_OP 306
#define OR_OP 307
#define ELLIPSES 308
#define MULT_EQUAL 309
#define DIV_EQUAL 310
#define MOD_EQUAL 311
#define ADD_EQUAL 312
#define SUB_EQUAL 313
#define SHIFT_LEFT_EQUAL 314
#define SHIFT_RIGHT_EQUAL 315
#define AND_EQUAL 316
#define XOR_EQUAL 317
#define OR_EQUAL 318
#define STRING_LITERAL 319
#define IDENTIFIER 320
#define INT_CONSTANT 321
#define FLOAT_CONSTANT 322
#define CHAR_CONSTANT 323
#define IFC 324

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 11 "ass5_13CS30016.y" /* yacc.c:355  */

    char charval;                           // used to represent a character value
    int intval;                             // used to represent an integer value
    double doubleval;                       // used to represent a double precision value
    string *strval;                         // pointer to string
    void* ptr;                              // used to represent a pointer
    primtype p_type;                        // an enum of various supported primitive (basic) data types
    opcode opp;                             // an enum of various supported operators
    symtype *typeinfo;                      // stores the type-expression for a variable
    symtab_entry *symdat;                   // pointer to a row (entry) in the symbol table
    exprr *exp_info;                        // stores the type, value and other various attributes of expressions and statements
    param *prm;                             // stores the name and datatype of a parameter
    vector<param*> *prm_list;               // is a list of parameters
    declr *dec_info;                        // stores the necessary attributes for declaration statements 
    vector<declr*> *ldec;                   // is a list of declarators

#line 271 "y.tab.c" /* yacc.c:355  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */

/* Copy the second part of user declarations.  */

#line 286 "y.tab.c" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  50
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1202

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  94
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  69
/* YYNRULES -- Number of rules.  */
#define YYNRULES  212
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  365

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   324

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    83,     2,     2,     2,    85,    78,     2,
      70,    71,    79,    80,    77,    81,    74,    84,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    91,    93,
      86,    92,    87,    90,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    72,     2,    73,    88,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    75,    89,    76,    82,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   178,   178,   189,   206,   223,   240,   244,   250,   251,
     269,   270,   303,   304,   305,   313,   321,   325,   332,   340,
     351,   352,   360,   368,   375,   379,   386,   390,   394,   398,
     402,   406,   413,   414,   421,   422,   444,   466,   491,   492,
     514,   539,   540,   554,   570,   571,   583,   595,   607,   621,
     622,   634,   649,   650,   660,   661,   670,   671,   680,   681,
     694,   695,   709,   710,   731,   732,   773,   774,   775,   776,
     777,   778,   779,   780,   781,   782,   783,   786,   787,   790,
     801,   824,   825,   891,   895,   899,   900,   901,   905,   909,
     913,   921,   926,   935,   940,   947,   948,   949,   950,   954,
     958,   962,   966,   970,   974,   978,   982,   986,   990,   994,
     998,  1002,  1009,  1010,  1011,  1012,  1015,  1016,  1017,  1018,
    1019,  1022,  1023,  1026,  1027,  1030,  1033,  1034,  1035,  1038,
    1040,  1045,  1054,  1059,  1063,  1069,  1070,  1071,  1072,  1088,
    1092,  1093,  1096,  1097,  1101,  1105,  1109,  1113,  1119,  1120,
    1123,  1125,  1130,  1131,  1134,  1139,  1146,  1152,  1159,  1160,
    1164,  1168,  1172,  1176,  1183,  1187,  1191,  1195,  1202,  1206,
    1207,  1210,  1211,  1218,  1219,  1220,  1221,  1222,  1223,  1226,
    1230,  1234,  1241,  1245,  1252,  1257,  1266,  1271,  1274,  1279,
    1282,  1284,  1290,  1301,  1311,  1317,  1328,  1336,  1352,  1356,
    1360,  1364,  1372,  1393,  1394,  1398,  1399,  1403,  1404,  1413,
    1414,  1422,  1432
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "_SINGLECOMMENT", "_MULTICOMMENT",
  "AUTO_KEYWORD", "BREAK_KEYWORD", "CASE_KEYWORD", "CHAR_KEYWORD",
  "CONST_KEYWORD", "CONTINUE_KEYWORD", "DEFAULT_KEYWORD", "DO_KEYWORD",
  "DOUBLE_KEYWORD", "ELSE_KEYWORD", "ENUM_KEYWORD", "EXTERN_KEYWORD",
  "FLOAT_KEYWORD", "FOR_KEYWORD", "GOTO_KEYWORD", "IF_KEYWORD",
  "INLINE_KEYWORD", "INT_KEYWORD", "LONG_KEYWORD", "REGISTER_KEYWORD",
  "RESTRICT_KEYWORD", "RETURN_KEYWORD", "SHORT_KEYWORD", "SIGNED_KEYWORD",
  "SIZEOF_KEYWORD", "STATIC_KEYWORD", "STRUCT_KEYWORD", "SWITCH_KEYWORD",
  "TYPEDEF_KEYWORD", "UNION_KEYWORD", "UNSIGNED_KEYWORD", "VOID_KEYWORD",
  "VOLATILE_KEYWORD", "WHILE_KEYWORD", "_BOOL_KEYWORD", "_COMPLEX_KEYWORD",
  "_IMAGINARY_KEYWORD", "ARROW", "INCREMENT_OP", "DECREMENT_OP",
  "SHIFT_LEFT", "SHIFT_RIGHT", "LESS_EQUAL", "GREATER_EQUAL",
  "EQUALITY_CHECK", "NOT_EQUAL", "AND_OP", "OR_OP", "ELLIPSES",
  "MULT_EQUAL", "DIV_EQUAL", "MOD_EQUAL", "ADD_EQUAL", "SUB_EQUAL",
  "SHIFT_LEFT_EQUAL", "SHIFT_RIGHT_EQUAL", "AND_EQUAL", "XOR_EQUAL",
  "OR_EQUAL", "STRING_LITERAL", "IDENTIFIER", "INT_CONSTANT",
  "FLOAT_CONSTANT", "CHAR_CONSTANT", "IFC", "'('", "')'", "'['", "']'",
  "'.'", "'{'", "'}'", "','", "'&'", "'*'", "'+'", "'-'", "'~'", "'!'",
  "'/'", "'%'", "'<'", "'>'", "'^'", "'|'", "'?'", "':'", "'='", "';'",
  "$accept", "primary_expression", "postfix_expression",
  "argument_expression_list", "unary_expression", "unary_operator",
  "cast_expression", "multiplicative_expression", "additive_expression",
  "shift_expression", "relational_expression", "equality_expression",
  "and_expression", "exclusive_or_expression", "inclusive_or_expression",
  "logical_and_expression", "logical_or_expression",
  "conditional_expression", "assignment_expression", "assignment_operator",
  "expression", "constant_expression", "fn_signature", "declaration",
  "declaration_specifiers", "init_declarator_list", "init_declarator",
  "storage_class_specifier", "type_specifier", "specifier_qualifier_list",
  "enum_specifier", "enumerator_list", "enumerator",
  "enumeration_constant", "type_qualifier", "function_specifier",
  "declarator", "direct_declarator", "type_qualifier_list_opt",
  "assignment_expression_opt", "pointer", "type_qualifier_list",
  "parameter_type_list_opt", "parameter_type_list", "parameter_list",
  "parameter_declaration", "identifier_list", "type_name", "initializer",
  "initializer_list", "designation", "designator_list", "designator",
  "statement", "labeled_statement", "compound_statement",
  "block_item_list", "block_item", "expression_statement",
  "expression_opt", "selection_statement", "iteration_statement",
  "jump_statement", "translation_unit", "external_declaration",
  "function_definition", "declaration_list", "N", "M", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
      40,    41,    91,    93,    46,   123,   125,    44,    38,    42,
      43,    45,   126,    33,    47,    37,    60,    62,    94,   124,
      63,    58,    61,    59
};
# endif

#define YYPACT_NINF -291

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-291)))

#define YYTABLE_NINF -212

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    1127,  -291,  -291,  -291,  -291,     1,  -291,  -291,  -291,  -291,
    -291,  -291,  -291,  -291,  -291,  -291,  -291,  -291,  -291,  -291,
    -291,  -291,   -38,  -291,     8,  1127,  1127,  -291,  1127,  1127,
    1090,  -291,  -291,   -30,    41,   292,  -291,  -291,    28,    23,
    -291,   -49,  -291,   528,    91,   109,  -291,  -291,  -291,  -291,
    -291,  -291,    41,  -291,    37,  -291,   -18,    47,   885,    69,
      80,  -291,   105,   127,   137,   196,   913,   152,  -291,   941,
     941,  -291,   129,  -291,  -291,  -291,   565,  -291,  -291,  -291,
    -291,  -291,  -291,  -291,  -291,  -291,     9,   365,   885,  -291,
      57,   106,   150,    -1,   151,   146,   145,   147,   184,   -31,
    -291,  -291,   -44,  -291,     8,  -291,  -291,  -291,   161,  -291,
    -291,  -291,  -291,  -291,   172,  -291,  -291,    23,    28,  -291,
     800,  -291,   644,   681,    25,    91,   135,  -291,   -11,   885,
    -291,  -291,  -291,  -291,   153,  -291,   449,   449,   885,   156,
     885,  -291,   -35,   565,  -291,   885,   175,   565,  -291,  -291,
     449,    34,  1161,  -291,  1161,   179,   186,  -291,  -291,   828,
     885,   187,  -291,  -291,  -291,  -291,  -291,  -291,  -291,  -291,
    -291,  -291,  -291,   885,  -291,   885,   885,   885,   885,   885,
     885,   885,   885,   885,   885,   885,   885,   885,   885,   885,
     885,   204,   -27,   885,  -291,   165,  -291,   371,  -291,  -291,
    -291,  -291,   767,  -291,  -291,  -291,  -291,  -291,    28,   188,
    -291,   181,  -291,    77,    32,   969,   128,  -291,    24,  -291,
    -291,  -291,   449,  -291,  -291,   191,   178,  -291,   191,  -291,
     194,    79,   885,   202,  -291,  -291,  -291,  -291,   857,  -291,
    -291,    93,  -291,    15,  -291,  -291,  -291,  -291,  -291,    57,
      57,   106,   106,   150,   150,   150,   150,    -1,    -1,   151,
     146,   145,  -291,  -291,  -291,  -291,  -291,   885,   216,  -291,
     140,   800,    75,  -291,  -291,  -291,  1048,  -291,   220,   885,
      32,   214,  -291,   215,   885,  -291,  -291,   254,  -291,   222,
     231,   449,   191,   231,   767,  -291,  -291,   885,  -291,   885,
     885,   885,   250,  -291,  -291,   683,  -291,  -291,  -291,  -291,
    -291,  -291,   252,  -291,  -291,   253,   264,   885,  -291,  -291,
     266,   142,  -291,   147,  -291,   191,  -291,  -291,  -291,   800,
    -291,  -291,   885,  -291,   449,  -291,  -291,   725,  -291,   204,
     247,  -291,    95,   246,  -291,   449,  -291,  -291,   248,  -291,
     326,  -291,   885,  -291,   885,  -291,  -291,  -291,   449,   271,
    -291,  -291,  -291,   449,  -291
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,    97,   100,   126,   105,     0,    95,   104,   129,   102,
     103,    98,   127,   101,   106,    96,   107,    99,   128,   108,
     109,   110,     0,   206,     0,    83,    85,   111,    87,    89,
       0,   203,   205,   120,     0,     0,   208,   132,     0,   144,
      81,     0,    91,    93,   131,     0,    84,    86,    88,    90,
       1,   204,     0,   125,     0,   121,   123,     0,     0,     0,
       0,   212,     0,     0,     0,     0,     0,     0,   212,     0,
       0,     6,     2,     3,     4,     5,     0,   183,    26,    27,
      28,    29,    30,    31,   188,     8,    20,    32,     0,    34,
      38,    41,    44,    49,    52,    54,    56,    58,    60,    62,
      64,    77,     0,   186,     0,   187,   173,   174,   212,   184,
     175,   176,   177,   178,     0,   148,   146,   145,     0,    82,
       0,   209,     0,   151,   141,   130,     0,   116,     0,     0,
     200,     2,    32,    79,     0,   199,     0,     0,   191,     0,
       0,   201,     0,     0,    24,     0,     0,     0,    21,    22,
       0,     0,   113,   160,   115,     0,     0,    14,    15,     0,
       0,     0,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    66,     0,    23,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   189,    93,   182,     0,   133,   149,
     147,    92,     0,   161,    94,   210,   207,   158,   157,     0,
     150,   152,   154,     0,   141,   143,   140,   117,     0,   118,
     122,   124,     0,   181,   212,   190,     0,   198,   211,   202,
       0,     0,     0,     0,   179,     7,   112,   114,     0,    13,
      10,     0,    18,     0,    12,    65,    35,    36,    37,    39,
      40,    42,    43,    47,    48,    45,    46,    50,    51,    53,
      55,    57,   212,   212,   212,    78,   185,     0,     0,   164,
       0,     0,     0,   169,   156,   138,     0,   139,     0,     0,
     140,    27,   142,     0,     0,   119,   180,     0,   212,     0,
      25,     0,   211,     0,     0,    33,    11,     0,     9,     0,
       0,     0,     0,   172,   162,     0,   166,   168,   170,   153,
     155,   159,     0,   137,   134,     0,     0,   191,   212,   194,
       0,     0,    19,   211,   211,   211,   171,   163,   165,     0,
     135,   136,     0,   211,     0,   212,    16,     0,    59,    61,
       0,   167,     0,     0,   211,     0,    17,   212,     0,   212,
     193,   195,     0,   196,   191,   212,    63,   211,     0,     0,
     211,   212,   192,     0,   197
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -291,  -291,  -291,  -291,   -58,  -291,   -81,    26,    48,     0,
      44,   155,   157,   154,    46,    49,  -291,   -57,  -103,  -291,
     -63,  -115,  -291,   -19,    10,  -291,   229,  -291,    -9,    36,
    -291,   296,  -110,  -291,    -8,  -291,   -15,   305,   138,  -291,
     -13,  -104,  -291,  -291,  -291,    78,  -291,    30,  -116,    59,
    -276,  -291,    83,  -131,  -291,    -7,  -291,   164,  -291,  -290,
    -291,  -291,  -291,  -291,   321,  -291,  -291,   -77,   -65
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    85,    86,   241,    87,    88,    89,    90,    91,    92,
      93,    94,    95,    96,    97,    98,    99,   100,   101,   173,
     102,   134,    22,    23,   104,    41,    42,    25,    26,   153,
      27,    54,    55,    56,    28,    29,   195,    44,   215,   283,
      45,   117,   209,   210,   211,   212,   213,   155,   269,   270,
     271,   272,   273,   105,   106,   107,   108,   109,   110,   226,
     111,   112,   113,    30,    31,    32,   122,   191,   137
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
     132,   133,   142,   146,   204,   223,   224,   174,   144,    43,
      24,   148,   149,   151,   221,    36,   103,   203,   220,   234,
     216,  -211,   192,   114,   121,   263,   116,   333,   118,   329,
     132,   115,     3,   193,     3,    46,    47,    35,    48,    49,
      24,     3,   193,   197,   119,    52,   182,   183,    12,   194,
      12,   156,   157,   158,    53,   214,   242,    12,   229,  -211,
      18,   329,    18,   264,   357,   219,    33,   152,   154,    18,
     245,   132,   133,    37,   129,   225,    34,   228,    38,   159,
     151,   160,   231,   161,   151,   184,   185,    39,   298,    53,
     265,   286,   193,    37,   246,   247,   248,   243,    38,   203,
     285,    40,    39,   205,   200,   235,    53,    39,   220,   199,
     280,   193,   282,   127,   128,   206,   115,   132,   132,   132,
     132,   132,   132,   132,   132,   132,   132,   132,   132,   132,
     132,   132,   132,   208,   152,   154,   175,     3,   152,   154,
     130,   176,   177,   152,   154,   152,   154,   267,   277,   268,
     291,   289,   302,    12,   278,   306,   193,   295,   284,   287,
     319,   123,   135,   124,   296,    18,   348,   307,   203,   292,
     297,   136,   193,   230,    37,   138,   312,   233,   103,    38,
     132,   315,   253,   254,   255,   256,   178,   179,   236,   328,
     237,   203,   139,   274,   322,   180,   181,   299,   300,   301,
     186,   187,   203,   344,   249,   250,   115,   140,   199,   132,
     133,   217,   218,   341,   351,   320,   304,   305,   336,   337,
     150,   328,   145,   317,   188,    66,   203,   360,   251,   252,
     257,   258,   364,   189,   203,  -211,   190,   196,   325,    69,
      70,   132,   132,   198,   222,   232,   338,   339,   340,   227,
     238,   239,   244,   334,   225,   262,   343,   120,   276,   275,
      71,   131,    73,    74,    75,   290,    76,   350,   193,   342,
     345,   288,   199,   293,    78,    79,    80,    81,    82,    83,
     359,   303,   352,   362,   354,   311,   208,   313,   314,   141,
     358,   225,   316,   318,   132,   356,   363,     1,    57,    58,
       2,     3,    59,    60,    61,     4,   294,     5,     6,     7,
      62,    63,    64,     8,     9,    10,    11,    12,    65,    13,
      14,    66,    15,   326,    67,   330,   331,    16,    17,    18,
      68,    19,    20,    21,   332,    69,    70,   335,   347,   349,
     355,   353,   361,   259,   261,   323,   260,   201,   126,   324,
     125,    51,   279,   321,   310,   308,    71,    72,    73,    74,
      75,   266,    76,     0,     0,     0,     0,    35,    77,     0,
      78,    79,    80,    81,    82,    83,     1,    57,    58,     2,
       3,    59,    60,    61,     4,    84,     5,     6,     7,    62,
      63,    64,     8,     9,    10,    11,    12,    65,    13,    14,
      66,    15,     0,    67,     0,     0,    16,    17,    18,    68,
      19,    20,    21,     0,    69,    70,     0,     0,     0,   162,
     163,   164,   165,   166,   167,   168,   169,   170,   171,     0,
       0,     0,     0,     0,     0,    71,    72,    73,    74,    75,
       0,    76,     0,     0,     0,     0,    35,     0,     0,    78,
      79,    80,    81,    82,    83,    57,    58,   172,     0,    59,
      60,    61,     0,     0,    84,     0,     0,    62,    63,    64,
       0,     0,     0,     0,     0,    65,     0,     0,    66,     0,
       0,    67,     0,     0,     0,     0,     0,    68,     0,     0,
       0,     0,    69,    70,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    71,    72,    73,    74,    75,     0,    76,
       0,     0,     0,     0,    35,     0,     0,    78,    79,    80,
      81,    82,    83,     1,     0,     0,     2,     3,     0,     0,
       0,     4,    84,     5,     6,     7,     0,     0,     0,     8,
       9,    10,    11,    12,     0,    13,    14,     0,    15,     0,
       0,     0,     0,    16,    17,    18,     0,    19,    20,    21,
       0,     0,     0,     2,     3,     0,     0,     0,     4,     0,
       5,     0,     7,     0,     0,     0,     0,     9,    10,     0,
      12,     0,    13,    14,    66,     0,     0,     0,     0,     0,
      16,    17,    18,   -80,    19,    20,    21,     0,    69,    70,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     120,     0,     0,     0,     0,     0,     0,     0,     0,    71,
     131,    73,    74,    75,     0,    76,     0,     0,     0,     0,
       0,     0,     0,    78,    79,    80,    81,    82,    83,     1,
       0,     0,     2,     3,     0,     0,     0,     4,     0,     5,
       6,     7,     0,     0,     0,     8,     9,    10,    11,    12,
       0,    13,    14,     0,    15,     0,     0,     0,     0,    16,
      17,    18,     0,    19,    20,    21,     1,     0,     0,     2,
       3,     0,     0,     0,     4,     0,     5,     6,     7,     0,
       0,     0,     8,     9,    10,    11,    12,     0,    13,    14,
       0,    15,    66,     0,     0,     0,    16,    17,    18,    35,
      19,    20,    21,     0,     0,     0,    69,    70,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   207,    71,   131,    73,
      74,    75,     0,    76,    66,   267,     0,   268,   202,   327,
       0,    78,    79,    80,    81,    82,    83,     0,    69,    70,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    71,
     131,    73,    74,    75,     0,    76,    66,   267,     0,   268,
     202,   346,     0,    78,    79,    80,    81,    82,    83,     0,
      69,    70,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    66,
       0,    71,   131,    73,    74,    75,     0,    76,     0,   267,
       0,   268,   202,    69,    70,    78,    79,    80,    81,    82,
      83,     0,     0,     0,     0,     0,     0,    66,     0,     0,
       0,     0,     0,     0,    71,   131,    73,    74,    75,     0,
      76,    69,    70,     0,     0,   202,     0,     0,    78,    79,
      80,    81,    82,    83,     0,     0,    66,     0,     0,     0,
       0,     0,    71,   131,    73,    74,    75,     0,    76,   240,
      69,    70,     0,     0,     0,     0,    78,    79,    80,    81,
      82,    83,     0,     0,    66,     0,     0,     0,     0,     0,
       0,    71,   131,    73,    74,    75,     0,    76,    69,    70,
       0,     0,   294,     0,     0,    78,    79,    80,    81,    82,
      83,     0,    66,     0,     0,     0,     0,     0,     0,    71,
     131,    73,    74,    75,     0,    76,    69,    70,     0,     0,
       0,     0,     0,    78,    79,    80,    81,    82,    83,     0,
      66,     0,     0,     0,     0,     0,     0,    71,   131,    73,
      74,    75,     0,   143,    69,    70,     0,     0,     0,     0,
       0,    78,    79,    80,    81,    82,    83,     0,    66,     0,
       0,     0,     0,     0,     0,    71,   131,    73,    74,    75,
       0,   147,    69,    70,     0,     0,     0,     0,     0,    78,
      79,    80,    81,    82,    83,     0,     0,     0,     0,     0,
       0,     0,     0,    71,   131,    73,    74,    75,     0,    76,
       0,     0,     0,     0,     0,     0,     0,    78,   281,    80,
      81,    82,    83,     1,     0,     0,     2,     3,     0,     0,
       0,     4,     0,     5,     6,     7,     0,     0,     0,     8,
       9,    10,    11,    12,     0,    13,    14,     0,    15,     0,
       0,     0,     0,    16,    17,    18,     0,    19,    20,    21,
      50,     0,     0,     0,     0,     1,     0,     0,     2,     3,
       0,   309,     0,     4,     0,     5,     6,     7,     0,     0,
       0,     8,     9,    10,    11,    12,     0,    13,    14,     0,
      15,     0,     0,     0,     0,    16,    17,    18,     0,    19,
      20,    21,     1,     0,     0,     2,     3,     0,     0,     0,
       4,     0,     5,     6,     7,     0,     0,     0,     8,     9,
      10,    11,    12,     0,    13,    14,     0,    15,     0,     0,
       0,     0,    16,    17,    18,     0,    19,    20,    21,     2,
       3,     0,     0,     0,     4,     0,     5,     0,     7,     0,
       0,     0,     0,     9,    10,     0,    12,     0,    13,    14,
       0,     0,     0,     0,     0,     0,    16,    17,    18,     0,
      19,    20,    21
};

static const yytype_int16 yycheck[] =
{
      58,    58,    65,    68,   120,   136,   137,    88,    66,    24,
       0,    69,    70,    76,   129,    22,    35,   120,   128,   150,
     124,    52,    99,    38,    43,    52,    39,   317,    77,   305,
      88,    39,     9,    77,     9,    25,    26,    75,    28,    29,
      30,     9,    77,   108,    93,    75,    47,    48,    25,    93,
      25,    42,    43,    44,    65,    30,   159,    25,    93,    90,
      37,   337,    37,    90,   354,    76,    65,    76,    76,    37,
     173,   129,   129,    65,    92,   138,    75,   140,    70,    70,
     143,    72,   145,    74,   147,    86,    87,    79,    73,    65,
     193,   222,    77,    65,   175,   176,   177,   160,    70,   202,
      76,    93,    79,   122,   117,    71,    65,    79,   218,   117,
     214,    77,   215,    76,    77,   122,   124,   175,   176,   177,
     178,   179,   180,   181,   182,   183,   184,   185,   186,   187,
     188,   189,   190,   123,   143,   143,    79,     9,   147,   147,
      93,    84,    85,   152,   152,   154,   154,    72,    71,    74,
      71,   228,   267,    25,    77,   271,    77,   238,    30,   224,
     291,    70,    93,    72,    71,    37,    71,    92,   271,   232,
      77,    91,    77,   143,    65,    70,   279,   147,   197,    70,
     238,   284,   182,   183,   184,   185,    80,    81,   152,   305,
     154,   294,    65,   208,   297,    45,    46,   262,   263,   264,
      49,    50,   305,   334,   178,   179,   214,    70,   216,   267,
     267,    76,    77,   329,   345,   292,    76,    77,    76,    77,
      91,   337,    70,   288,    78,    29,   329,   358,   180,   181,
     186,   187,   363,    88,   337,    51,    89,    76,   301,    43,
      44,   299,   300,    71,    91,    70,   323,   324,   325,    93,
      71,    65,    65,   318,   317,    51,   333,    92,    77,    71,
      64,    65,    66,    67,    68,    71,    70,   344,    77,   332,
     335,    93,   280,    71,    78,    79,    80,    81,    82,    83,
     357,    65,   347,   360,   349,    65,   276,    73,    73,    93,
     355,   354,    38,    71,   352,   352,   361,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    75,    15,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    73,    32,    73,    73,    35,    36,    37,
      38,    39,    40,    41,    70,    43,    44,    71,    91,    93,
      14,    93,    71,   188,   190,   299,   189,   118,    52,   300,
      45,    30,   214,   294,   276,   272,    64,    65,    66,    67,
      68,   197,    70,    -1,    -1,    -1,    -1,    75,    76,    -1,
      78,    79,    80,    81,    82,    83,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    93,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    -1,    32,    -1,    -1,    35,    36,    37,    38,
      39,    40,    41,    -1,    43,    44,    -1,    -1,    -1,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    -1,
      -1,    -1,    -1,    -1,    -1,    64,    65,    66,    67,    68,
      -1,    70,    -1,    -1,    -1,    -1,    75,    -1,    -1,    78,
      79,    80,    81,    82,    83,     6,     7,    92,    -1,    10,
      11,    12,    -1,    -1,    93,    -1,    -1,    18,    19,    20,
      -1,    -1,    -1,    -1,    -1,    26,    -1,    -1,    29,    -1,
      -1,    32,    -1,    -1,    -1,    -1,    -1,    38,    -1,    -1,
      -1,    -1,    43,    44,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    64,    65,    66,    67,    68,    -1,    70,
      -1,    -1,    -1,    -1,    75,    -1,    -1,    78,    79,    80,
      81,    82,    83,     5,    -1,    -1,     8,     9,    -1,    -1,
      -1,    13,    93,    15,    16,    17,    -1,    -1,    -1,    21,
      22,    23,    24,    25,    -1,    27,    28,    -1,    30,    -1,
      -1,    -1,    -1,    35,    36,    37,    -1,    39,    40,    41,
      -1,    -1,    -1,     8,     9,    -1,    -1,    -1,    13,    -1,
      15,    -1,    17,    -1,    -1,    -1,    -1,    22,    23,    -1,
      25,    -1,    27,    28,    29,    -1,    -1,    -1,    -1,    -1,
      35,    36,    37,    75,    39,    40,    41,    -1,    43,    44,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      92,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    64,
      65,    66,    67,    68,    -1,    70,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    78,    79,    80,    81,    82,    83,     5,
      -1,    -1,     8,     9,    -1,    -1,    -1,    13,    -1,    15,
      16,    17,    -1,    -1,    -1,    21,    22,    23,    24,    25,
      -1,    27,    28,    -1,    30,    -1,    -1,    -1,    -1,    35,
      36,    37,    -1,    39,    40,    41,     5,    -1,    -1,     8,
       9,    -1,    -1,    -1,    13,    -1,    15,    16,    17,    -1,
      -1,    -1,    21,    22,    23,    24,    25,    -1,    27,    28,
      -1,    30,    29,    -1,    -1,    -1,    35,    36,    37,    75,
      39,    40,    41,    -1,    -1,    -1,    43,    44,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    65,    64,    65,    66,
      67,    68,    -1,    70,    29,    72,    -1,    74,    75,    76,
      -1,    78,    79,    80,    81,    82,    83,    -1,    43,    44,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    64,
      65,    66,    67,    68,    -1,    70,    29,    72,    -1,    74,
      75,    76,    -1,    78,    79,    80,    81,    82,    83,    -1,
      43,    44,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    29,
      -1,    64,    65,    66,    67,    68,    -1,    70,    -1,    72,
      -1,    74,    75,    43,    44,    78,    79,    80,    81,    82,
      83,    -1,    -1,    -1,    -1,    -1,    -1,    29,    -1,    -1,
      -1,    -1,    -1,    -1,    64,    65,    66,    67,    68,    -1,
      70,    43,    44,    -1,    -1,    75,    -1,    -1,    78,    79,
      80,    81,    82,    83,    -1,    -1,    29,    -1,    -1,    -1,
      -1,    -1,    64,    65,    66,    67,    68,    -1,    70,    71,
      43,    44,    -1,    -1,    -1,    -1,    78,    79,    80,    81,
      82,    83,    -1,    -1,    29,    -1,    -1,    -1,    -1,    -1,
      -1,    64,    65,    66,    67,    68,    -1,    70,    43,    44,
      -1,    -1,    75,    -1,    -1,    78,    79,    80,    81,    82,
      83,    -1,    29,    -1,    -1,    -1,    -1,    -1,    -1,    64,
      65,    66,    67,    68,    -1,    70,    43,    44,    -1,    -1,
      -1,    -1,    -1,    78,    79,    80,    81,    82,    83,    -1,
      29,    -1,    -1,    -1,    -1,    -1,    -1,    64,    65,    66,
      67,    68,    -1,    70,    43,    44,    -1,    -1,    -1,    -1,
      -1,    78,    79,    80,    81,    82,    83,    -1,    29,    -1,
      -1,    -1,    -1,    -1,    -1,    64,    65,    66,    67,    68,
      -1,    70,    43,    44,    -1,    -1,    -1,    -1,    -1,    78,
      79,    80,    81,    82,    83,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    64,    65,    66,    67,    68,    -1,    70,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    78,    79,    80,
      81,    82,    83,     5,    -1,    -1,     8,     9,    -1,    -1,
      -1,    13,    -1,    15,    16,    17,    -1,    -1,    -1,    21,
      22,    23,    24,    25,    -1,    27,    28,    -1,    30,    -1,
      -1,    -1,    -1,    35,    36,    37,    -1,    39,    40,    41,
       0,    -1,    -1,    -1,    -1,     5,    -1,    -1,     8,     9,
      -1,    53,    -1,    13,    -1,    15,    16,    17,    -1,    -1,
      -1,    21,    22,    23,    24,    25,    -1,    27,    28,    -1,
      30,    -1,    -1,    -1,    -1,    35,    36,    37,    -1,    39,
      40,    41,     5,    -1,    -1,     8,     9,    -1,    -1,    -1,
      13,    -1,    15,    16,    17,    -1,    -1,    -1,    21,    22,
      23,    24,    25,    -1,    27,    28,    -1,    30,    -1,    -1,
      -1,    -1,    35,    36,    37,    -1,    39,    40,    41,     8,
       9,    -1,    -1,    -1,    13,    -1,    15,    -1,    17,    -1,
      -1,    -1,    -1,    22,    23,    -1,    25,    -1,    27,    28,
      -1,    -1,    -1,    -1,    -1,    -1,    35,    36,    37,    -1,
      39,    40,    41
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     5,     8,     9,    13,    15,    16,    17,    21,    22,
      23,    24,    25,    27,    28,    30,    35,    36,    37,    39,
      40,    41,   116,   117,   118,   121,   122,   124,   128,   129,
     157,   158,   159,    65,    75,    75,   149,    65,    70,    79,
      93,   119,   120,   130,   131,   134,   118,   118,   118,   118,
       0,   158,    75,    65,   125,   126,   127,     6,     7,    10,
      11,    12,    18,    19,    20,    26,    29,    32,    38,    43,
      44,    64,    65,    66,    67,    68,    70,    76,    78,    79,
      80,    81,    82,    83,    93,    95,    96,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   107,   108,   109,   110,
     111,   112,   114,   117,   118,   147,   148,   149,   150,   151,
     152,   154,   155,   156,   130,   128,   134,   135,    77,    93,
      92,   117,   160,    70,    72,   131,   125,    76,    77,    92,
      93,    65,    98,   111,   115,    93,    91,   162,    70,    65,
      70,    93,   114,    70,    98,    70,   162,    70,    98,    98,
      91,   114,   122,   123,   128,   141,    42,    43,    44,    70,
      72,    74,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    92,   113,   100,    79,    84,    85,    80,    81,
      45,    46,    47,    48,    86,    87,    49,    50,    78,    88,
      89,   161,   161,    77,    93,   130,    76,   162,    71,   128,
     134,   120,    75,   112,   142,   117,   149,    65,   118,   136,
     137,   138,   139,   140,    30,   132,   135,    76,    77,    76,
     126,   115,    91,   147,   147,   114,   153,    93,   114,    93,
     141,   114,    70,   141,   147,    71,   123,   123,    71,    65,
      71,    97,   112,   114,    65,   112,   100,   100,   100,   101,
     101,   102,   102,   103,   103,   103,   103,   104,   104,   105,
     106,   107,    51,    52,    90,   112,   151,    72,    74,   142,
     143,   144,   145,   146,   130,    71,    77,    71,    77,   132,
     135,    79,   112,   133,    30,    76,   147,   162,    93,   161,
      71,    71,   114,    71,    75,   100,    71,    77,    73,   162,
     162,   162,   115,    65,    76,    77,   142,    92,   146,    53,
     139,    65,   112,    73,    73,   112,    38,   162,    71,   147,
     161,   143,   112,   108,   109,   114,    73,    76,   142,   144,
      73,    73,    70,   153,   162,    71,    76,    77,   161,   161,
     161,   142,   114,   161,   147,   162,    76,    91,    71,    93,
     161,   147,   162,    93,   162,    14,   111,   153,   162,   161,
     147,    71,   161,   162,   147
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    94,    95,    95,    95,    95,    95,    95,    96,    96,
      96,    96,    96,    96,    96,    96,    96,    96,    97,    97,
      98,    98,    98,    98,    98,    98,    99,    99,    99,    99,
      99,    99,   100,   100,   101,   101,   101,   101,   102,   102,
     102,   103,   103,   103,   104,   104,   104,   104,   104,   105,
     105,   105,   106,   106,   107,   107,   108,   108,   109,   109,
     110,   110,   111,   111,   112,   112,   113,   113,   113,   113,
     113,   113,   113,   113,   113,   113,   113,   114,   114,   115,
     116,   117,   117,   118,   118,   118,   118,   118,   118,   118,
     118,   119,   119,   120,   120,   121,   121,   121,   121,   122,
     122,   122,   122,   122,   122,   122,   122,   122,   122,   122,
     122,   122,   123,   123,   123,   123,   124,   124,   124,   124,
     124,   125,   125,   126,   126,   127,   128,   128,   128,   129,
     130,   130,   131,   131,   131,   131,   131,   131,   131,   131,
     132,   132,   133,   133,   134,   134,   134,   134,   135,   135,
     136,   136,   137,   137,   138,   138,   139,   139,   140,   140,
     141,   142,   142,   142,   143,   143,   143,   143,   144,   145,
     145,   146,   146,   147,   147,   147,   147,   147,   147,   148,
     148,   148,   149,   149,   150,   150,   151,   151,   152,   152,
     153,   153,   154,   154,   154,   155,   155,   155,   156,   156,
     156,   156,   156,   157,   157,   158,   158,   159,   159,   160,
     160,   161,   162
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     1,     1,     1,     1,     3,     1,     4,
       3,     4,     3,     3,     2,     2,     6,     7,     1,     3,
       1,     2,     2,     2,     2,     4,     1,     1,     1,     1,
       1,     1,     1,     4,     1,     3,     3,     3,     1,     3,
       3,     1,     3,     3,     1,     3,     3,     3,     3,     1,
       3,     3,     1,     3,     1,     3,     1,     3,     1,     6,
       1,     6,     1,     9,     1,     3,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     3,     1,
       2,     2,     3,     1,     2,     1,     2,     1,     2,     1,
       2,     1,     3,     1,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     1,     2,     1,     4,     5,     5,     6,
       2,     1,     3,     1,     3,     1,     1,     1,     1,     1,
       2,     1,     1,     3,     5,     6,     6,     5,     4,     4,
       1,     0,     1,     0,     1,     2,     2,     3,     1,     2,
       1,     0,     1,     3,     1,     3,     2,     1,     1,     3,
       1,     1,     3,     4,     1,     3,     2,     4,     2,     1,
       2,     3,     2,     1,     1,     1,     1,     1,     1,     3,
       4,     3,     3,     2,     1,     3,     1,     1,     1,     2,
       1,     0,    12,     8,     5,     8,     9,    14,     3,     2,
       2,     2,     3,     1,     2,     1,     1,     4,     2,     1,
       2,     0,     0
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 179 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr; 
            string t = (*((yyvsp[0].strval))); 
            symtab_entry *t1 = st->lookup(t);
            if(t1 != NULL)
                (yyval.exp_info)->p_type = (t1->type).p_type;
            else
                (yyval.exp_info)->p_type = none;
            (yyval.exp_info)->loc = t;
        }
#line 1838 "y.tab.c" /* yacc.c:1646  */
    break;

  case 3:
#line 190 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->loc = st->gentemp(INT);
        (yyval.exp_info)->p_type = INT;
        symval s;
        s.intval = (yyvsp[0].intval);
        qa.emit((yyval.exp_info)->loc, s, "int", OPER_ASSIGN);
        symval *t = new symval;
        if(!strcmp(gettype((yyvsp[0].intval)), "int"))
        {
            t->intval = (yyvsp[0].intval);
            t->doubleval = (double)(yyvsp[0].intval);
            t->charval = (char)(yyvsp[0].intval);
            st->lookup((yyval.exp_info)->loc)->init_val = t;    
        }
    }
#line 1859 "y.tab.c" /* yacc.c:1646  */
    break;

  case 4:
#line 207 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(DOUBLE);
        (yyval.exp_info)->p_type = DOUBLE;
        symval s;
        s.doubleval = (yyvsp[0].doubleval);
        qa.emit((yyval.exp_info)->loc, s, "double", OPER_ASSIGN);
        symval *t = new symval; 
        if(!strcmp(gettype((yyvsp[0].doubleval)), "double"))
        {
            t->doubleval = (yyvsp[0].doubleval);
            t->intval = (int)(yyvsp[0].doubleval);
            t->charval = (char)(yyvsp[0].doubleval);
            st->lookup((yyval.exp_info)->loc)->init_val = t;    
        }
    }
#line 1880 "y.tab.c" /* yacc.c:1646  */
    break;

  case 5:
#line 224 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(CHAR);
        (yyval.exp_info)->p_type = CHAR;
        symval s; 
        s.charval = (yyvsp[0].charval);
        qa.emit((yyval.exp_info)->loc, s, "char", OPER_ASSIGN);
        symval *t = new symval; 
        if(!strcmp(gettype((yyvsp[0].charval)), "char"))
        {
            t->charval = (yyvsp[0].charval);
            t->doubleval = (double)(yyvsp[0].charval);
            t->intval = (int)(yyvsp[0].charval);
            st->lookup((yyval.exp_info)->loc)->init_val = t;    
        }
    }
#line 1901 "y.tab.c" /* yacc.c:1646  */
    break;

  case 6:
#line 241 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 1909 "y.tab.c" /* yacc.c:1646  */
    break;

  case 7:
#line 245 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = (yyvsp[-1].exp_info);
        }
#line 1917 "y.tab.c" /* yacc.c:1646  */
    break;

  case 9:
#line 252 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        symtype t = st->lookup((yyvsp[-3].exp_info)->loc)->type;
        string f;
        if((yyvsp[-3].exp_info)->dim_arr == 0)
        {
            f = st->gentemp(INT);
            symval s; s.intval = 0;
            qa.emit(f,s, "int",OPER_ASSIGN);
            (yyvsp[-3].exp_info)->temp_arr_name = new string(f);
        }
        f = *((yyvsp[-3].exp_info)->temp_arr_name);
        int mult = t.alist[(yyvsp[-3].exp_info)->dim_arr]; (yyvsp[-3].exp_info)->dim_arr++;
        stringstream ss; ss<<mult; string m; ss>>m;
        qa.emit(f,f,OPER_MULTIPLY,m);
        qa.emit(f,f,OPER_PLUS,(yyvsp[-1].exp_info)->loc);
        (yyval.exp_info) = (yyvsp[-3].exp_info);
    }
#line 1939 "y.tab.c" /* yacc.c:1646  */
    break;

  case 11:
#line 271 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        string fname = (yyvsp[-3].exp_info)->loc;
        symtab *fsym = gst.lookup(fname)->nested_symtab;
        vector<param*> arglist = *((yyvsp[-1].prm_list));
        vector<symtab_entry*> paramlist = fsym->ord_sym;
        int i = 0;
        bool many = false;
        while(i < arglist.size())
        {
            if(paramlist[i]->name == "retVal")
            {
                many = true;
            }
            if(arglist[i]->type.p_type != paramlist[i]->type.p_type)
            {
                string t = st->gentemp(paramlist[i]->type.p_type);
                qa.conv2type(t,paramlist[i]->type.p_type,arglist[i]->name,arglist[i]->type.p_type);
                arglist[i]->name = t;
                arglist[i]->type.p_type = paramlist[i]->type.p_type;
            }
            qa.emit(arglist[i]->name,"",OPER_PARAM,"");
            i++;
        }
        if(!many && paramlist[arglist.size()]->name != "retval" )
        {
            
        }
        symval s;
        s.intval = (int)arglist.size();
        qa.emit(fname,s, "int",OPER_CALL);
        
    }
#line 1976 "y.tab.c" /* yacc.c:1646  */
    break;

  case 14:
#line 306 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(st->lookup((yyvsp[-1].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->p_type = (yyvsp[-1].exp_info)->p_type;
        qa.emit((yyval.exp_info)->loc,(yyvsp[-1].exp_info)->loc,OPER_ASSIGN,""); 
        qa.emit((yyvsp[-1].exp_info)->loc,(yyvsp[-1].exp_info)->loc,OPER_PLUS,"1");
    }
#line 1988 "y.tab.c" /* yacc.c:1646  */
    break;

  case 15:
#line 314 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(st->lookup((yyvsp[-1].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->p_type = (yyvsp[-1].exp_info)->p_type;
        qa.emit((yyval.exp_info)->loc,(yyvsp[-1].exp_info)->loc,OPER_ASSIGN,""); 
        qa.emit((yyvsp[-1].exp_info)->loc,(yyvsp[-1].exp_info)->loc,OPER_MINUS,"1");
    }
#line 2000 "y.tab.c" /* yacc.c:1646  */
    break;

  case 16:
#line 322 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2008 "y.tab.c" /* yacc.c:1646  */
    break;

  case 17:
#line 326 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2016 "y.tab.c" /* yacc.c:1646  */
    break;

  case 18:
#line 333 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            param *t = new param; 
            t->name = (yyvsp[0].exp_info)->loc; 
            t->type = st->lookup(t->name)->type; 
            (yyval.prm_list) = new vector<param*>; 
            (yyval.prm_list)->push_back(t);
        }
#line 2028 "y.tab.c" /* yacc.c:1646  */
    break;

  case 19:
#line 341 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            param *t = new param; 
            t->name = (yyvsp[0].exp_info)->loc; 
            t->type = st->lookup(t->name)->type; 
            (yyval.prm_list) = (yyvsp[-2].prm_list); 
            (yyval.prm_list)->push_back(t);
        }
#line 2040 "y.tab.c" /* yacc.c:1646  */
    break;

  case 21:
#line 353 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        qa.emit((yyvsp[0].exp_info)->loc,(yyvsp[0].exp_info)->loc,OPER_PLUS,"1"); 
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->p_type = (yyvsp[0].exp_info)->p_type;
        qa.emit((yyval.exp_info)->loc,(yyvsp[0].exp_info)->loc,OPER_ASSIGN,""); 
    }
#line 2052 "y.tab.c" /* yacc.c:1646  */
    break;

  case 22:
#line 361 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        qa.emit((yyvsp[0].exp_info)->loc,(yyvsp[0].exp_info)->loc,OPER_MINUS,"1");
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->p_type = (yyvsp[0].exp_info)->p_type;
        qa.emit((yyval.exp_info)->loc,(yyvsp[0].exp_info)->loc,OPER_ASSIGN,""); 
    }
#line 2064 "y.tab.c" /* yacc.c:1646  */
    break;

  case 23:
#line 369 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp();
        (yyval.exp_info)->p_type = (yyvsp[0].exp_info)->p_type;
        qa.emit((yyval.exp_info)->loc, (yyvsp[0].exp_info)->loc, (yyvsp[-1].opp), "");
    }
#line 2075 "y.tab.c" /* yacc.c:1646  */
    break;

  case 24:
#line 376 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // sizeof operator not considered as per the assignment 
        }
#line 2083 "y.tab.c" /* yacc.c:1646  */
    break;

  case 25:
#line 380 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // sizeof operator not considered as per the assignment    
        }
#line 2091 "y.tab.c" /* yacc.c:1646  */
    break;

  case 26:
#line 387 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.opp) = OPER_REF;
        }
#line 2099 "y.tab.c" /* yacc.c:1646  */
    break;

  case 27:
#line 391 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.opp) = OPER_DE_REF;
        }
#line 2107 "y.tab.c" /* yacc.c:1646  */
    break;

  case 28:
#line 395 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.opp) = OPER_UPLUS;
        }
#line 2115 "y.tab.c" /* yacc.c:1646  */
    break;

  case 29:
#line 399 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.opp) = OPER_UMINUS;
        }
#line 2123 "y.tab.c" /* yacc.c:1646  */
    break;

  case 30:
#line 403 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.opp) = OPER_COMPLEMENT;
        }
#line 2131 "y.tab.c" /* yacc.c:1646  */
    break;

  case 31:
#line 407 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.opp) = OPER_BW_NOT;
        }
#line 2139 "y.tab.c" /* yacc.c:1646  */
    break;

  case 33:
#line 415 "ass5_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 2147 "y.tab.c" /* yacc.c:1646  */
    break;

  case 35:
#line 423 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        primtype final_type = max(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type, st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);      // assigned types in enum based on their safe type-casting conditions
        (yyval.exp_info)->loc = st->gentemp(final_type); 
        (yyval.exp_info)->p_type = final_type;                                
        if(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[-2].exp_info)->loc,st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type);
            (yyvsp[-2].exp_info)->loc = t;
            st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type = final_type;
        }
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            (yyvsp[0].exp_info)->loc = t;
            st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type = final_type;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_MULTIPLY,(yyvsp[0].exp_info)->loc);
    }
#line 2173 "y.tab.c" /* yacc.c:1646  */
    break;

  case 36:
#line 445 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        primtype final_type = max(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type, st->lookup((yyvsp[0].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->loc = st->gentemp(final_type); 
        (yyval.exp_info)->p_type = final_type;
        if(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[-2].exp_info)->loc,st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type);
            st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type = final_type;
            (yyvsp[-2].exp_info)->loc = t;
        }
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            (yyvsp[0].exp_info)->loc = t;
            st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type = final_type;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_DIVIDE,(yyvsp[0].exp_info)->loc);
    }
#line 2199 "y.tab.c" /* yacc.c:1646  */
    break;

  case 37:
#line 467 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        primtype final_type = max(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type, st->lookup((yyvsp[0].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->loc = st->gentemp(final_type); 
        (yyval.exp_info)->p_type = final_type;
        if(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[-2].exp_info)->loc,st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type);
            st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type = final_type;
            (yyvsp[-2].exp_info)->loc = t;
        }
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            (yyvsp[0].exp_info)->loc = t;
            st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type = final_type;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_MODULUS,(yyvsp[0].exp_info)->loc);
    }
#line 2225 "y.tab.c" /* yacc.c:1646  */
    break;

  case 39:
#line 493 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        primtype final_type = max(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type, st->lookup((yyvsp[0].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->loc = st->gentemp(final_type); 
        (yyval.exp_info)->p_type = final_type;
        if(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[-2].exp_info)->loc,st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type);
            st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type = final_type;
            (yyvsp[-2].exp_info)->loc = t;
        }
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type = final_type;
            (yyvsp[0].exp_info)->loc = t;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_PLUS,(yyvsp[0].exp_info)->loc);
    }
#line 2251 "y.tab.c" /* yacc.c:1646  */
    break;

  case 40:
#line 515 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        primtype final_type = max(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type, st->lookup((yyvsp[0].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->loc = st->gentemp(final_type); 
        (yyval.exp_info)->p_type = final_type;
        if(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[-2].exp_info)->loc,st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type);
            st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type = final_type;
            (yyvsp[-2].exp_info)->loc = t;
        }
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != final_type)
        {
            string t = st->gentemp(final_type);
            qa.conv2type(t,final_type,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type = final_type;
            (yyvsp[0].exp_info)->loc = t;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_MINUS,(yyvsp[0].exp_info)->loc);
    }
#line 2277 "y.tab.c" /* yacc.c:1646  */
    break;

  case 42:
#line 541 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->p_type = st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type;
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != INT)
        {
            string t = st->gentemp(INT);
            qa.conv2type(t,INT,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            (yyvsp[0].exp_info)->loc = t;
            st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type = INT;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_SHIFT_LEFT,(yyvsp[0].exp_info)->loc);
    }
#line 2295 "y.tab.c" /* yacc.c:1646  */
    break;

  case 43:
#line 555 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type); 
        (yyval.exp_info)->p_type = st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type;
        if(st->lookup((yyvsp[0].exp_info)->loc)->type.p_type != INT)
        {
            string t = st->gentemp(INT);
            qa.conv2type(t,INT,(yyvsp[0].exp_info)->loc,st->lookup((yyvsp[0].exp_info)->loc)->type.p_type);
            (yyvsp[0].exp_info)->loc = t;
            st->lookup((yyvsp[-2].exp_info)->loc)->type.p_type = INT;
        }
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_SHIFT_RIGHT,(yyvsp[0].exp_info)->loc);
    }
#line 2313 "y.tab.c" /* yacc.c:1646  */
    break;

  case 45:
#line 572 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr; 
            (yyval.exp_info)->loc = st->gentemp();
            (yyval.exp_info)->p_type = BOOL; 
            qa.emit((yyval.exp_info)->loc,"1",OPER_ASSIGN,""); 
            (yyval.exp_info)->truelist = makelist(qa.nextinstr); 
            qa.emit("",(yyvsp[-2].exp_info)->loc,OPER_IF_LESS,(yyvsp[0].exp_info)->loc); 
            qa.emit((yyval.exp_info)->loc,"0",OPER_ASSIGN,"");  
            (yyval.exp_info)->falselist = makelist(qa.nextinstr); 
            qa.emit("","",OPER_GOTO,"");
        }
#line 2329 "y.tab.c" /* yacc.c:1646  */
    break;

  case 46:
#line 584 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp();
        (yyval.exp_info)->p_type = BOOL; 
        qa.emit((yyval.exp_info)->loc,"1",OPER_ASSIGN,""); 
        (yyval.exp_info)->truelist = makelist(qa.nextinstr); 
        qa.emit("",(yyvsp[-2].exp_info)->loc,OPER_IF_GREATER,(yyvsp[0].exp_info)->loc); 
        qa.emit((yyval.exp_info)->loc,"0",OPER_ASSIGN,""); 
        (yyval.exp_info)->falselist = makelist(qa.nextinstr); 
        qa.emit("","",OPER_GOTO,"");
    }
#line 2345 "y.tab.c" /* yacc.c:1646  */
    break;

  case 47:
#line 596 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr; 
            (yyval.exp_info)->loc = st->gentemp();
            (yyval.exp_info)->p_type = BOOL; 
            qa.emit((yyval.exp_info)->loc,"1",OPER_ASSIGN,""); 
            (yyval.exp_info)->truelist = makelist(qa.nextinstr); 
            qa.emit("",(yyvsp[-2].exp_info)->loc,OPER_IF_LESS_OR_EQUAL,(yyvsp[0].exp_info)->loc); 
            qa.emit((yyval.exp_info)->loc,"0",OPER_ASSIGN,"");  
            (yyval.exp_info)->falselist = makelist(qa.nextinstr); 
            qa.emit("","",OPER_GOTO,"");
        }
#line 2361 "y.tab.c" /* yacc.c:1646  */
    break;

  case 48:
#line 608 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp();
        (yyval.exp_info)->p_type = BOOL; 
        qa.emit((yyval.exp_info)->loc,"1",OPER_ASSIGN,""); 
        (yyval.exp_info)->truelist = makelist(qa.nextinstr); 
        qa.emit("",(yyvsp[-2].exp_info)->loc,OPER_IF_GREATER_OR_EQUAL,(yyvsp[0].exp_info)->loc); 
        qa.emit((yyval.exp_info)->loc,"0",OPER_ASSIGN,"");  
        (yyval.exp_info)->falselist = makelist(qa.nextinstr); 
        qa.emit("","",OPER_GOTO,"");
    }
#line 2377 "y.tab.c" /* yacc.c:1646  */
    break;

  case 50:
#line 623 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr; 
            (yyval.exp_info)->loc = st->gentemp();
            (yyval.exp_info)->p_type = BOOL; 
            qa.emit((yyval.exp_info)->loc,"1",OPER_ASSIGN,""); 
            (yyval.exp_info)->truelist = makelist(qa.nextinstr); 
            qa.emit("",(yyvsp[-2].exp_info)->loc,OPER_IF_EQUAL,(yyvsp[0].exp_info)->loc); 
            qa.emit((yyval.exp_info)->loc,"0",OPER_ASSIGN,""); 
            (yyval.exp_info)->falselist = makelist(qa.nextinstr);  
            qa.emit("","",OPER_GOTO,"");
        }
#line 2393 "y.tab.c" /* yacc.c:1646  */
    break;

  case 51:
#line 635 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp();
        (yyval.exp_info)->p_type = BOOL; 
        qa.emit((yyval.exp_info)->loc,"1",OPER_ASSIGN,""); 
        (yyval.exp_info)->truelist = makelist(qa.nextinstr); 
        qa.emit("",(yyvsp[-2].exp_info)->loc,OPER_IF_NOT_EQUAL,(yyvsp[0].exp_info)->loc); 
        qa.emit((yyval.exp_info)->loc,"0",OPER_ASSIGN,""); 
        (yyval.exp_info)->falselist = makelist(qa.nextinstr); 
        qa.emit("","",OPER_GOTO,"");
    }
#line 2409 "y.tab.c" /* yacc.c:1646  */
    break;

  case 53:
#line 651 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(); 
        (yyval.exp_info)->p_type = INT;
        qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_BW_AND,(yyvsp[0].exp_info)->loc);
    }
#line 2420 "y.tab.c" /* yacc.c:1646  */
    break;

  case 55:
#line 662 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr; 
            (yyval.exp_info)->loc = st->gentemp();
            (yyval.exp_info)->p_type = INT; 
            qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_BW_XOR,(yyvsp[0].exp_info)->loc);
        }
#line 2431 "y.tab.c" /* yacc.c:1646  */
    break;

  case 57:
#line 672 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr; 
            (yyval.exp_info)->loc = st->gentemp();
            (yyval.exp_info)->p_type = INT; 
            qa.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OPER_BW_OR,(yyvsp[0].exp_info)->loc);
        }
#line 2442 "y.tab.c" /* yacc.c:1646  */
    break;

  case 59:
#line 682 "ass5_13CS30016.y" /* yacc.c:1646  */
    {       
        qa.backpatch((yyvsp[-4].exp_info)->nextlist,qa.nextinstr);
        qa.convInt2Bool((yyvsp[-5].exp_info));
        qa.backpatch((yyvsp[0].exp_info)->nextlist, qa.nextinstr);
        qa.convInt2Bool((yyvsp[-1].exp_info));
        (yyval.exp_info) = new exprr; (yyval.exp_info)->p_type = BOOL;
        qa.backpatch((yyvsp[-5].exp_info)->truelist,(yyvsp[-2].exp_info)->instr); 
        (yyval.exp_info)->falselist = merge((yyvsp[-5].exp_info)->falselist, (yyvsp[-1].exp_info)->falselist); 
        (yyval.exp_info)->truelist = (yyvsp[-1].exp_info)->truelist; 
    }
#line 2457 "y.tab.c" /* yacc.c:1646  */
    break;

  case 61:
#line 696 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        qa.backpatch((yyvsp[-4].exp_info)->nextlist,qa.nextinstr);
        qa.convInt2Bool((yyvsp[-5].exp_info));
        qa.backpatch((yyvsp[0].exp_info)->nextlist, qa.nextinstr);
        qa.convInt2Bool((yyvsp[-1].exp_info));
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->p_type = BOOL;
        qa.backpatch((yyvsp[-5].exp_info)->falselist,(yyvsp[-2].exp_info)->instr); 
        (yyval.exp_info)->truelist = merge((yyvsp[-5].exp_info)->truelist, (yyvsp[-1].exp_info)->truelist); 
        (yyval.exp_info)->falselist = (yyvsp[-1].exp_info)->falselist; 
    }
#line 2473 "y.tab.c" /* yacc.c:1646  */
    break;

  case 63:
#line 711 "ass5_13CS30016.y" /* yacc.c:1646  */
    { 
        (yyval.exp_info) = new exprr; 
        (yyval.exp_info)->loc = st->gentemp(st->lookup((yyvsp[-4].exp_info)->loc)->type.p_type);
        (yyval.exp_info)->p_type = st->lookup((yyvsp[-4].exp_info)->loc)->type.p_type;
        qa.emit((yyval.exp_info)->loc,(yyvsp[0].exp_info)->loc,OPER_ASSIGN);
        list<int> I = makelist(qa.nextinstr);
        qa.emit("","",OPER_GOTO,"");
        qa.backpatch((yyvsp[-3].exp_info)->nextlist,qa.nextinstr);
        qa.emit((yyval.exp_info)->loc,(yyvsp[-4].exp_info)->loc, OPER_ASSIGN);
        I = merge(I,makelist(qa.nextinstr));
        qa.emit("","",OPER_GOTO,"");
        qa.backpatch((yyvsp[-7].exp_info)->nextlist, qa.nextinstr);
        qa.convInt2Bool((yyvsp[-8].exp_info));  
        qa.backpatch((yyvsp[-8].exp_info)->truelist,(yyvsp[-5].exp_info)->instr);
        qa.backpatch((yyvsp[-8].exp_info)->falselist,(yyvsp[-1].exp_info)->instr);
        qa.backpatch(I,qa.nextinstr);
    }
#line 2495 "y.tab.c" /* yacc.c:1646  */
    break;

  case 65:
#line 733 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        symtype t3 = st->lookup((yyvsp[0].exp_info)->loc)->type;
        if(t3.p_type == ARRAY)
        {
            string t = st->gentemp(t3.base_t);
            qa.emit(t,(yyvsp[0].exp_info)->loc,OPER_ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->temp_arr_name));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->p_type = t3.base_t;
        }
        symtype t1 =  st->lookup((yyvsp[-2].exp_info)->loc)->type;
        if((t1.p_type == ARRAY && t1.base_t != (yyvsp[0].exp_info)->p_type) )
        {
            string t = st->gentemp(t1.base_t);
            qa.conv2type(t,t1.base_t,(yyvsp[0].exp_info)->loc,(yyvsp[0].exp_info)->p_type);
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->p_type = t1.base_t;
        } 
        else if(t1.p_type != (yyvsp[0].exp_info)->p_type)
        {
            // cout << "im in!\n";
            // cout << "t1-typ:" << t1.p_type << endl;
            // cout << "t3-typ:" << $3->p_type << endl;
            string t = st->gentemp(t1.p_type);
            // cout << t << " " << t1.base_t << endl;
            qa.conv2type(t,t1.p_type,(yyvsp[0].exp_info)->loc,(yyvsp[0].exp_info)->p_type);
            (yyvsp[0].exp_info)->loc = t;
            (yyvsp[0].exp_info)->p_type = t1.p_type; 
            // cout << "assigned : " << t << endl;
        }
        if(t1.p_type == ARRAY)
        {
            qa.emit((yyvsp[-2].exp_info)->loc,(yyvsp[0].exp_info)->loc, OPER_ARRAY_INDEX_TO,*((yyvsp[-2].exp_info)->temp_arr_name));
        }
        else
            qa.emit((yyvsp[-2].exp_info)->loc, (yyvsp[0].exp_info)->loc,OPER_ASSIGN,"");
        (yyval.exp_info) = (yyvsp[-2].exp_info);
    }
#line 2537 "y.tab.c" /* yacc.c:1646  */
    break;

  case 80:
#line 802 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        primtype tn = (yyvsp[-1].p_type);
        declr *my_dec = (yyvsp[0].dec_info);
        int sz;
        switch(tn)
        {
            case CHAR : sz = CHAR_SIZE; break;
            case INT : sz = INT_SIZE; break;
            case DOUBLE : sz = DOUBLE_SIZE; break;
            default : sz = -1; 
        }
        symtab_entry *var = gst.lookup(my_dec->name);
        if(my_dec->p_type == FUNCTION) 
        {
            symtab_entry *retval = var->nested_symtab->lookup("retVal",my_dec->pc, tn);
            var->init_val = NULL;           
            var->offset = st->offset;
            var->size = 0;
        }
    }
#line 2562 "y.tab.c" /* yacc.c:1646  */
    break;

  case 82:
#line 826 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        primtype type_now = (yyvsp[-2].p_type);
        int size_now = -1;
        if(type_now == CHAR) size_now = CHAR_SIZE;
        if(type_now == INT)  size_now = INT_SIZE;
        if(type_now == DOUBLE)  size_now = DOUBLE_SIZE;
        vector<declr*> lst = *((yyvsp[-1].ldec));
        for(vector<declr*>::iterator it = lst.begin(); it != lst.end(); it++)
        {
            declr *my_dec = *it;
            if(my_dec->p_type == FUNCTION)
            {
                st = &(gst);                // transfer control back to the global symbol table
            }
            if(my_dec->p_type == FUNCTION)
            {
                symtab_entry *var = st->lookup(my_dec->name);
                symtab_entry *retval = var->nested_symtab->lookup("retVal",my_dec->pc, type_now);
                var->offset = st->offset;
                var->size = 0;
                var->init_val = NULL;
                continue;
            }
            symtab_entry *var = st->lookup(my_dec->name,0,type_now);
            var->nested_symtab = NULL;
            if(my_dec->alist == vector<int>() && my_dec->pc == 0) 
            {
                var->type.p_type = type_now;
                var->offset = st->offset; var->offset += size_now;
                var->size = size_now;
                if(my_dec->init_val != NULL)
                {
                    string rval = my_dec->init_val->loc;
                    qa.emit(var->name, rval,OPER_ASSIGN,"");
                    var->init_val = st->lookup(rval)->init_val;
                }
                else
                    var->init_val = NULL;
            }
            else if(my_dec->alist!=vector<int>())  
            {
                var->type.p_type = ARRAY;
                var->type.base_t = type_now;
                var->type.alist = my_dec->alist;
                var->offset = st->offset;
                int sz = size_now; vector<int> tmp = var->type.alist; int tsz = tmp.size();
                for(int i = 0; i<tsz; i++) sz *= tmp[i];
                    st->offset += sz;
                var->size = sz;
            }
            else if(my_dec->pc != 0)
            {
                var->type.p_type = PTR;
                var->type.base_t = type_now;
                var->type.pc = my_dec->pc;
                var->offset = st->offset; 
                size_now = PTR_SIZE; 
                st->offset += size_now;
                var->size = size_now;
            }
        }  
    }
#line 2629 "y.tab.c" /* yacc.c:1646  */
    break;

  case 83:
#line 892 "ass5_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 2637 "y.tab.c" /* yacc.c:1646  */
    break;

  case 84:
#line 896 "ass5_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 2645 "y.tab.c" /* yacc.c:1646  */
    break;

  case 87:
#line 902 "ass5_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 2653 "y.tab.c" /* yacc.c:1646  */
    break;

  case 88:
#line 906 "ass5_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 2661 "y.tab.c" /* yacc.c:1646  */
    break;

  case 89:
#line 910 "ass5_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 2669 "y.tab.c" /* yacc.c:1646  */
    break;

  case 90:
#line 914 "ass5_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 2677 "y.tab.c" /* yacc.c:1646  */
    break;

  case 91:
#line 922 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.ldec) = new vector<declr*>; 
            (yyval.ldec)->push_back((yyvsp[0].dec_info));
        }
#line 2686 "y.tab.c" /* yacc.c:1646  */
    break;

  case 92:
#line 927 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyvsp[-2].ldec)->push_back((yyvsp[0].dec_info)); 
            (yyval.ldec) = (yyvsp[-2].ldec);
        }
#line 2695 "y.tab.c" /* yacc.c:1646  */
    break;

  case 93:
#line 936 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.dec_info) = (yyvsp[0].dec_info); 
            (yyval.dec_info)->init_val = NULL;
        }
#line 2704 "y.tab.c" /* yacc.c:1646  */
    break;

  case 94:
#line 941 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.dec_info) = (yyvsp[-2].dec_info); 
            (yyval.dec_info)->init_val = (yyvsp[0].exp_info);
        }
#line 2713 "y.tab.c" /* yacc.c:1646  */
    break;

  case 99:
#line 955 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.p_type) = VOID;
        }
#line 2721 "y.tab.c" /* yacc.c:1646  */
    break;

  case 100:
#line 959 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.p_type) = CHAR;
        }
#line 2729 "y.tab.c" /* yacc.c:1646  */
    break;

  case 101:
#line 963 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2737 "y.tab.c" /* yacc.c:1646  */
    break;

  case 102:
#line 967 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.p_type) = INT;
        }
#line 2745 "y.tab.c" /* yacc.c:1646  */
    break;

  case 103:
#line 971 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2753 "y.tab.c" /* yacc.c:1646  */
    break;

  case 104:
#line 975 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2761 "y.tab.c" /* yacc.c:1646  */
    break;

  case 105:
#line 979 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.p_type) = DOUBLE;
        }
#line 2769 "y.tab.c" /* yacc.c:1646  */
    break;

  case 106:
#line 983 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2777 "y.tab.c" /* yacc.c:1646  */
    break;

  case 107:
#line 987 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2785 "y.tab.c" /* yacc.c:1646  */
    break;

  case 108:
#line 991 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2793 "y.tab.c" /* yacc.c:1646  */
    break;

  case 109:
#line 995 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2801 "y.tab.c" /* yacc.c:1646  */
    break;

  case 110:
#line 999 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2809 "y.tab.c" /* yacc.c:1646  */
    break;

  case 111:
#line 1003 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2817 "y.tab.c" /* yacc.c:1646  */
    break;

  case 130:
#line 1041 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.dec_info) = (yyvsp[0].dec_info); 
            (yyval.dec_info)->pc = (yyvsp[-1].intval);
        }
#line 2826 "y.tab.c" /* yacc.c:1646  */
    break;

  case 131:
#line 1046 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.dec_info) = (yyvsp[0].dec_info); 
            (yyval.dec_info)->pc = 0;
        }
#line 2835 "y.tab.c" /* yacc.c:1646  */
    break;

  case 132:
#line 1055 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.dec_info) = new declr; 
            (yyval.dec_info)->name = *((yyvsp[0].strval));
        }
#line 2844 "y.tab.c" /* yacc.c:1646  */
    break;

  case 133:
#line 1060 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2852 "y.tab.c" /* yacc.c:1646  */
    break;

  case 134:
#line 1064 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.dec_info) = (yyvsp[-4].dec_info); 
        int idx = st->lookup((yyvsp[-1].exp_info)->loc)->init_val->intval;
        (yyval.dec_info)->alist.push_back(idx);
    }
#line 2862 "y.tab.c" /* yacc.c:1646  */
    break;

  case 138:
#line 1073 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.dec_info) = (yyvsp[-3].dec_info);                                        // default bison operation
        (yyval.dec_info)->p_type = FUNCTION;
        symtab_entry *fdata = st->lookup((yyval.dec_info)->name,0,(yyval.dec_info)->p_type);
        symtab *fsym = new symtab;
        fdata->nested_symtab = fsym;

        vector<param*> plist = *((yyvsp[-1].prm_list));
        for(int i = 0;i<plist.size(); i++)
        {
            param *my_prm = plist[i];
            fsym->lookup(my_prm->name,0,my_prm->type.p_type);
        }
        st = fsym;
    }
#line 2882 "y.tab.c" /* yacc.c:1646  */
    break;

  case 144:
#line 1102 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.intval) = 1;
        }
#line 2890 "y.tab.c" /* yacc.c:1646  */
    break;

  case 145:
#line 1106 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2898 "y.tab.c" /* yacc.c:1646  */
    break;

  case 146:
#line 1110 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.intval) = 1 + (yyvsp[0].intval);
        }
#line 2906 "y.tab.c" /* yacc.c:1646  */
    break;

  case 147:
#line 1114 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2914 "y.tab.c" /* yacc.c:1646  */
    break;

  case 151:
#line 1125 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.prm_list) = new vector<param*>;
        }
#line 2922 "y.tab.c" /* yacc.c:1646  */
    break;

  case 154:
#line 1135 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.prm_list) = new vector<param*>; 
            (yyval.prm_list)->push_back((yyvsp[0].prm));
        }
#line 2931 "y.tab.c" /* yacc.c:1646  */
    break;

  case 155:
#line 1140 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyvsp[-2].prm_list)->push_back((yyvsp[0].prm)); 
            (yyval.prm_list) = (yyvsp[-2].prm_list);
        }
#line 2940 "y.tab.c" /* yacc.c:1646  */
    break;

  case 156:
#line 1147 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.prm) = new param; 
            (yyval.prm)->name = (yyvsp[0].dec_info)->name; 
            (yyval.prm)->type.p_type = (yyvsp[-1].p_type);
        }
#line 2950 "y.tab.c" /* yacc.c:1646  */
    break;

  case 157:
#line 1153 "ass5_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 2958 "y.tab.c" /* yacc.c:1646  */
    break;

  case 161:
#line 1169 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = (yyvsp[0].exp_info);
        }
#line 2966 "y.tab.c" /* yacc.c:1646  */
    break;

  case 162:
#line 1173 "ass5_13CS30016.y" /* yacc.c:1646  */
    {  
            // not used
        }
#line 2974 "y.tab.c" /* yacc.c:1646  */
    break;

  case 163:
#line 1177 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2982 "y.tab.c" /* yacc.c:1646  */
    break;

  case 164:
#line 1184 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2990 "y.tab.c" /* yacc.c:1646  */
    break;

  case 165:
#line 1188 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 2998 "y.tab.c" /* yacc.c:1646  */
    break;

  case 166:
#line 1192 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3006 "y.tab.c" /* yacc.c:1646  */
    break;

  case 167:
#line 1196 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3014 "y.tab.c" /* yacc.c:1646  */
    break;

  case 179:
#line 1227 "ass5_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3022 "y.tab.c" /* yacc.c:1646  */
    break;

  case 180:
#line 1231 "ass5_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3030 "y.tab.c" /* yacc.c:1646  */
    break;

  case 181:
#line 1235 "ass5_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3038 "y.tab.c" /* yacc.c:1646  */
    break;

  case 182:
#line 1242 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = (yyvsp[-1].exp_info);
    }
#line 3046 "y.tab.c" /* yacc.c:1646  */
    break;

  case 183:
#line 1246 "ass5_13CS30016.y" /* yacc.c:1646  */
    {

        }
#line 3054 "y.tab.c" /* yacc.c:1646  */
    break;

  case 184:
#line 1253 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = (yyvsp[0].exp_info); 
            qa.backpatch((yyvsp[0].exp_info)->nextlist, qa.nextinstr);
        }
#line 3063 "y.tab.c" /* yacc.c:1646  */
    break;

  case 185:
#line 1258 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr;
        qa.backpatch((yyvsp[-2].exp_info)->nextlist, (yyvsp[-1].exp_info)->instr);
        (yyval.exp_info)->nextlist = (yyvsp[0].exp_info)->nextlist;
        (yyval.exp_info)->p_type = (yyvsp[0].exp_info)->p_type;
    }
#line 3074 "y.tab.c" /* yacc.c:1646  */
    break;

  case 186:
#line 1267 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr;
            // $$->p_type = $1->p_type;
        }
#line 3083 "y.tab.c" /* yacc.c:1646  */
    break;

  case 188:
#line 1275 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr;
            (yyval.exp_info)->p_type = none;
        }
#line 3092 "y.tab.c" /* yacc.c:1646  */
    break;

  case 191:
#line 1284 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            (yyval.exp_info) = new exprr;
            (yyval.exp_info)->p_type = none;
        }
#line 3101 "y.tab.c" /* yacc.c:1646  */
    break;

  case 192:
#line 1291 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        qa.backpatch((yyvsp[-8].exp_info)->nextlist,qa.nextinstr);
        qa.convInt2Bool((yyvsp[-9].exp_info));
        qa.backpatch((yyvsp[-9].exp_info)->truelist,(yyvsp[-6].exp_info)->instr);
        qa.backpatch((yyvsp[-9].exp_info)->falselist,(yyvsp[-2].exp_info)->instr);
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->nextlist = merge((yyvsp[-5].exp_info)->nextlist,(yyvsp[-4].exp_info)->nextlist);        
        (yyval.exp_info)->nextlist = merge((yyval.exp_info)->nextlist,(yyvsp[-1].exp_info)->nextlist);   
        (yyval.exp_info)->nextlist = merge((yyval.exp_info)->nextlist,(yyvsp[0].exp_info)->nextlist);           
    }
#line 3116 "y.tab.c" /* yacc.c:1646  */
    break;

  case 193:
#line 1302 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        qa.backpatch((yyvsp[-4].exp_info)->nextlist,qa.nextinstr);
        qa.convInt2Bool((yyvsp[-5].exp_info));
        qa.backpatch((yyvsp[-5].exp_info)->truelist,(yyvsp[-2].exp_info)->instr);
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->nextlist = merge((yyvsp[-1].exp_info)->nextlist,(yyvsp[0].exp_info)->nextlist);        
        (yyval.exp_info)->nextlist = merge((yyval.exp_info)->nextlist,(yyvsp[-5].exp_info)->falselist);           
    }
#line 3129 "y.tab.c" /* yacc.c:1646  */
    break;

  case 194:
#line 1312 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3137 "y.tab.c" /* yacc.c:1646  */
    break;

  case 195:
#line 1318 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        qa.emit("","",OPER_GOTO,"");
        qa.backpatch(makelist(qa.nextinstr-1),(yyvsp[-6].exp_info)->instr);    
        qa.backpatch((yyvsp[-3].exp_info)->nextlist,qa.nextinstr);
        qa.convInt2Bool((yyvsp[-4].exp_info));
        qa.backpatch((yyvsp[-4].exp_info)->truelist,(yyvsp[-1].exp_info)->instr);
        qa.backpatch((yyvsp[0].exp_info)->nextlist,(yyvsp[-6].exp_info)->instr);    
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->nextlist = (yyvsp[-4].exp_info)->falselist;        
    }
#line 3152 "y.tab.c" /* yacc.c:1646  */
    break;

  case 196:
#line 1329 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        qa.convInt2Bool((yyvsp[-2].exp_info));
        qa.backpatch((yyvsp[-2].exp_info)->truelist,(yyvsp[-7].exp_info)->instr);
        qa.backpatch((yyvsp[-6].exp_info)->nextlist,(yyvsp[-5].exp_info)->instr);
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->nextlist = (yyvsp[-2].exp_info)->falselist;
    }
#line 3164 "y.tab.c" /* yacc.c:1646  */
    break;

  case 197:
#line 1337 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        qa.emit("","",OPER_GOTO,"");
        qa.backpatch(makelist(qa.nextinstr-1), (yyvsp[-5].exp_info)->instr );
        qa.backpatch((yyvsp[-7].exp_info)->nextlist,qa.nextinstr);
        qa.convInt2Bool((yyvsp[-8].exp_info));
        qa.backpatch((yyvsp[-8].exp_info)->truelist,(yyvsp[-1].exp_info)->instr);
        qa.backpatch((yyvsp[0].exp_info)->nextlist,(yyvsp[-5].exp_info)->instr);
        qa.backpatch((yyvsp[-3].exp_info)->nextlist,(yyvsp[-9].exp_info)->instr);
        (yyval.exp_info) = new exprr;
        (yyval.exp_info)->nextlist = (yyvsp[-8].exp_info)->falselist;
    }
#line 3180 "y.tab.c" /* yacc.c:1646  */
    break;

  case 198:
#line 1353 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3188 "y.tab.c" /* yacc.c:1646  */
    break;

  case 199:
#line 1357 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3196 "y.tab.c" /* yacc.c:1646  */
    break;

  case 200:
#line 1361 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
            // not used
        }
#line 3204 "y.tab.c" /* yacc.c:1646  */
    break;

  case 201:
#line 1365 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new exprr;
        if(st->lookup("retVal")->type.p_type == VOID)
        {
            qa.emit("","",OPER_RETURN,"");
        }
    }
#line 3216 "y.tab.c" /* yacc.c:1646  */
    break;

  case 202:
#line 1373 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        if(st->lookup("retVal")->type.p_type == st->lookup((yyvsp[-1].exp_info)->loc)->type.p_type)
        {
            qa.emit((yyvsp[-1].exp_info)->loc,"",OPER_RETURN,"");
        }
        else
        {
            primtype ret_typ = st->lookup("retVal")->type.p_type;
            string t = st->gentemp(ret_typ);
            qa.conv2type(t,ret_typ,(yyvsp[-1].exp_info)->loc,st->lookup((yyvsp[-1].exp_info)->loc)->type.p_type);
            st->lookup("retVal")->type.p_type = st->lookup((yyvsp[-1].exp_info)->loc)->type.p_type;
            qa.emit(t,"",OPER_RETURN,"");
        }
        (yyval.exp_info) = new exprr;
    }
#line 3236 "y.tab.c" /* yacc.c:1646  */
    break;

  case 208:
#line 1405 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        // function's symbol table is removed and global symbol table becomes the current symbol table
        st = &(gst);
    }
#line 3245 "y.tab.c" /* yacc.c:1646  */
    break;

  case 211:
#line 1422 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) =  new exprr;  
        (yyval.exp_info)->nextlist = makelist(qa.nextinstr); 
        qa.emit("","",OPER_GOTO,"");
    }
#line 3255 "y.tab.c" /* yacc.c:1646  */
    break;

  case 212:
#line 1432 "ass5_13CS30016.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) =  new exprr; 
        (yyval.exp_info)->instr = qa.nextinstr;
    }
#line 3264 "y.tab.c" /* yacc.c:1646  */
    break;


#line 3268 "y.tab.c" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 1438 "ass5_13CS30016.y" /* yacc.c:1906  */


void yyerror(string s)                  // Function that is invoked when reporting an error in parsing (exception conditions)
{
    std::cout << s << std::endl;
}
