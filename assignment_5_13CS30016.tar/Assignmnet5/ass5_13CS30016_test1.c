int fsum(int a, int b)     // function handling with parameters
{
	int k = a + b + 3;
	return k - b * 6;	// precedence rules
}
char fn(char a)
{
	char z1;
	z1 = 36;
	return a + z1;
}
double fnd()
{
	double d1 = 5.00;
	double d2 = d1 + 1.0;
	double d3 = d1 * d2 + 4;  // precedence rules
	return d3;
}
void ff()
{
	// does not do anything
}
void main()
{
	int k1;
	k1 = fsum(4, 6);
	ff();
	double d;
	d = fnd();
	char c;
	c = fn(k1);			// type conversion
}