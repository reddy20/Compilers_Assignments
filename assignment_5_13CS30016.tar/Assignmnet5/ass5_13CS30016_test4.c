// Dealing with arrays

double fn(int l)
{
	int i = 19, ***x, a[10], **c;
	

	double d1, f;
	char c;
	
	a[1] = 1;
	
	i = a[4];

	// i = a[5][5];
	d = i * 3.33;


	return d;
}