#ifndef ASS5_13CS30016_TRANSLATOR_H
#define ASS5_13CS30016_TRANSLATOR_H

#include <bits/stdc++.h>

using namespace std;

// sizes of the various supported datatypes given in the assignment (for the given architecture)

#define CHAR_SIZE    1              
#define INT_SIZE     4
#define DOUBLE_SIZE  8
#define PTR_SIZE     4

enum opcode {                       // Enum that encodes that various operators allowed by the grammar

//Binary Arithmetic Instructions
OPER_PLUS = 1,
OPER_MINUS,
OPER_MULTIPLY,
OPER_DIVIDE,
OPER_MODULUS,
OPER_SHIFT_LEFT,
OPER_SHIFT_RIGHT,
OPER_BW_OR,
OPER_BW_AND,
OPER_BW_XOR,
OPER_LOGIC_AND,
OPER_LOGIC_OR,
OPER_LESS,
OPER_GREATER,
OPER_LESS_EQUAL,
OPER_GREATER_EQUAL,
OPER_EQUAL,
OPER_NOT_EQUAL,

//Unary  Instructions
OPER_UMINUS,
OPER_UPLUS,
OPER_COMPLEMENT,
OPER_BW_NOT,

//Unconditional Jump
OPER_GOTO,

//Conditional Jump
OPER_IF_LESS,
OPER_IF_GREATER,
OPER_IF_LESS_OR_EQUAL,
OPER_IF_GREATER_OR_EQUAL,
OPER_IF_EQUAL,
OPER_IF_NOT_EQUAL,
OPER_IF_EXPRESSION,
OPER_IF_NOT_EXPRESSION,

//Copy Assignment Instruction
OPER_ASSIGN,

// type conversions supported by the architecture 
OPER_C2I,
OPER_C2D,
OPER_I2C,
OPER_I2D,
OPER_D2C,
OPER_D2I,

// Function handling
OPER_PARAM,
OPER_CALL,
OPER_RETURN,

//Array Indexing Opcodes
OPER_ARRAY_INDEX_FROM,
OPER_ARRAY_INDEX_TO,

//Address and Pointer Assignment Instructions
OPER_REF,
OPER_DE_REF,
OPER_POINTER_ASSIGNMENT

};

enum primtype{                        // Enum of all the supported primitive types by the grammar
    none = 0,
    VOID,
    BOOL,
    CHAR,
    INT,
    DOUBLE,
    ARRAY,
    PTR,
    FUNCTION
};

// The grammar given supports only 3 data-types (char, int, double) + void + pointers 
// [symval stores all the possible data-types and hence can be used to store the value of a variable generically]

class symval{
public:
    char charval;
    int intval;
    double doubleval;
    void* pval;
};

// exprr : class that stores the various possible attributes of expressions and statements

class exprr;                       

// quad : a class which stores each quad entry (ie. each quad line) (Three Address Code Format =>  result = arg1 [op] arg2)
// print function : to print this particular quad

class quad{                                                             
public:
    opcode op;
    string arg1, arg2, result;
    void print(int quad_no);          
};

// the list of quads that will finally represent the program (encoded in m/c independent code (TAC Form))
// vector data structure used to represent the list of quads
// nextinstr : stores the quad number of the next instruction

class q_array{
public:
    vector<quad> array;                                                           
    int nextinstr;                                                                
    q_array();
    ~q_array();
    void emit(string res, string arg1, opcode op, string arg2 = "");                // overloaded : used to insert the Three Address Code into the quad 
    void backpatch(list<int> a, int index);                                         // saves the 'index' as the target of all dangling goto's present in list 'a' 
    void emit(string res, symval s, const char *type, opcode op);                   // overloaded : used to insert the Three Address Code into the quad (based on need the required one is used)
    void convInt2Bool(exprr* res);                                                  // a function to simplify convert from int to bool 
    void conv2type(exprr*t, exprr*res, primtype p_type);                            // two generic functions that can be used to convert from any type to any type
    void conv2type(string t,primtype bt, string f, primtype from);                  // provided that conversion is supported by the architecture targeted
};

// symtype : class stores the type that is used by the variable. It encompasses the entire 'type-expression' of the variable/expression it is used by.
// alist : is used to store the type information in list form (like for arrays - the various dimensions)
// compute_width : computes the width occupied by the given type-expression

class symtype
{
public:
    primtype p_type;
    primtype base_t;
    vector<int> alist;
    int pc;
    int compute_witdh();
};

/*   exprr (stores)
 *       - truelist and falselist for boolean expressions
 *       - nextlist for statements
 *       - instr for augmented variable M
 *       - loc : the variable/name used in the symbol table for the expression
 *       - p_type : type of the expression
 *       - dim_arr & temp_arr_name : used for working with arrays
 */

class exprr{                                                   
public:
    list<int> truelist, falselist, nextlist;
    int instr;
    string loc;
    primtype p_type;
    int dim_arr;                                                   // used to determine the dimention of array being parsed
    string *temp_arr_name;
    exprr();
    ~exprr();
};

// symtab : data-structure for storing the symbol-table for the program

class symtab;                                        

// symtab_entry : corresponds to a single entry of the symbol table
// stores the 'NAME', 'TYPE', 'INITIAL-VALUE', SIZE', 'OFFSET' and 'LINK_TO_NESTED_TABLE' for each entry in the symbol table

class symtab_entry                                   
{
public:
    string name;
    int size, offset;
    symtype type;
    symval *init_val;
    symtab *nested_symtab;
    symtab_entry();
    ~symtab_entry();
};

// symtab : data-structure for storing the symbol-table for the program
// maintains a map as the internal data-structure for implementing the symbol table (a map for variable names with the symbol table entries they correspond to)
// ord_sym : to get an ordered list the pointer is inserted every time a new variable is added
// offset : value used to directly access individual entries in the symbol table
// lookup : it is a function with default parameters that searches the symbol tab;e entry for the given variable name. If found, it return a pointer
// to the corresponding symbol table entry, else returns NULL
// gentemp : is used to create temporaries. Maintains a static variable to keep track of the temporaries it has generates. Always generates a new unique one.
// printsymtab : to print the entire symbol table corresponding to the entered function name. If 'global' is written, it refers to the gobal symbol table. 

class symtab{                                                                   
public: 
    map<string,symtab_entry*> _symtab;                                                           
    vector<symtab_entry*> ord_sym;                                                               
    int offset;
    symtab();
    ~symtab();
    // symtab_entry* getdata(string name);
    symtab_entry* lookup(string var,int pc = 0, primtype bt = INT);
    string gentemp(primtype bt = INT);
    void printsymtab(const char *fn_name);
};

/* declarations (declr)
 *       - name : to store the name
 *       - pc & alist : used for handling with array declarations and storing the indexes (dimensions) of the array
 *       - init_val : points to the initial values (at the time of declaration) of the various variables
 *       - p_type : declaration type
 */

class declr
{
public:
    string name;                                                            // to store name
    int pc;     // to store number of pounters
    exprr *init_val;         // to store th in itial valie
    vector<int> alist; // to store the list of indexes in case of an array declaration
    primtype p_type;  // type info
    declr();
    declr(string id, primtype bt);
    ~declr();
    vector<int> getArrList();
};

// param : stores the name and type for a parameter of a function

class param
{
public:
    string name;
    symtype type;
};

list<int> makelist(int index);                  // makes an empty list with only 1 entry (ie. given by index)
list<int> merge(list<int> a, list<int> b);      // merges the lists given to it as parameters and returns pointer to the merged list
char *gettype(int arg);                         // overloaded function which returns (as a string) the type of variable given as argument to it.
char *gettype(char arg);
char *gettype(double arg);

extern int line_cnt;                            // global counter of line numbers of the user entered code. Important for providing debugging information to the user
extern q_array qa;                              // the global quad array maintained by the compiler for the given program
extern symtab gst;                              // the global symbol table of a program
extern symtab *st;                              // pointer to the 'current' symbol table

#endif /* ASS5_13CS30016_TRANSLATOR_H */
